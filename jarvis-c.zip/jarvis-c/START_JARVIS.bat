@echo off
setlocal enabledelayedexpansion
title JARVIS AI Launcher

:: 1. Automatically switch to the script's directory (project root)
cd /d "%~dp0"

echo ======================================================================
echo                JARVIS AI -- ADVANCED DESKTOP ASSISTANT
echo ======================================================================
echo Project Root: %CD%

:: 2. Check for duplicate running instances of JARVIS AI
tasklist /FI "WINDOWTITLE eq JARVIS AI*" 2>NUL | find /I /N "python" >NUL
if "%ERRORLEVEL%"=="0" (
    echo [NOTICE] An active JARVIS AI window is already running.
    echo Bringing existing JARVIS window to focus...
    timeout /t 3 >nul
    exit /b 0
)

:: 3. Identify and select Python interpreter (Virtualenv -> System Python)
set PYTHON_EXE=

if exist "%~dp0.venv\Scripts\python.exe" (
    set "PYTHON_EXE=%~dp0.venv\Scripts\python.exe"
    echo Using Virtual Environment: .venv
) else if exist "%~dp0venv\Scripts\python.exe" (
    set "PYTHON_EXE=%~dp0venv\Scripts\python.exe"
    echo Using Virtual Environment: venv
) else if exist "C:\Program Files\Python314\python.exe" (
    set "PYTHON_EXE=C:\Program Files\Python314\python.exe"
    echo Using System Python 3.14
) else (
    where python >nul 2>&1
    if "%ERRORLEVEL%"=="0" (
        set "PYTHON_EXE=python"
        echo Using System PATH Python
    )
)

if "%PYTHON_EXE%"=="" (
    echo [ERROR] Python interpreter could not be found!
    echo Please install Python 3.12+ from python.org or ensure it is added to your PATH.
    echo.
    pause
    exit /b 1
)

:: 4. Verify core dependencies
"%PYTHON_EXE%" -c "import PySide6, groq, psutil, httpx, sounddevice, pyttsx3" >nul 2>&1
if "%ERRORLEVEL%" NEQ "0" (
    echo [WARNING] Missing one or more required dependencies.
    echo Attempting automatic dependency installation from requirements.txt...
    "%PYTHON_EXE%" -m pip install -r "%~dp0requirements.txt"
    if "%ERRORLEVEL%" NEQ "0" (
        echo [ERROR] Dependency installation failed.
        echo Please run: pip install -r requirements.txt
        echo.
        pause
        exit /b 1
    )
)

:: 5. Launch JARVIS AI Desktop Application
echo Launching JARVIS AI Desktop Application...
"%PYTHON_EXE%" "%~dp0main.py"
set EXIT_CODE=%ERRORLEVEL%

if %EXIT_CODE% NEQ 0 (
    echo.
    echo ======================================================================
    echo [ERROR] JARVIS AI terminated with exit code %EXIT_CODE%.
    echo Please inspect 'startup.log' for details.
    echo ======================================================================
    pause
    exit /b %EXIT_CODE%
)

exit /b 0
