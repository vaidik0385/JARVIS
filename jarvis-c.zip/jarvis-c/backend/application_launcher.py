"""
JARVIS AI — Safe Windows Application Launcher & Command Registry
Executes verified local Windows applications, system utilities, and encoded browser searches.
Features:
- Dynamic detection of installed application paths (Registry, %ProgramFiles%, %LocalAppData%, PATH)
- Safe argument-list subprocess execution with startupinfo desktop binding
- Strict security allowlist preventing arbitrary command execution
- Confirmation gating for sensitive/destructive operations
- Unified dispatch for UI buttons, natural language commands, and voice automation
"""

import os
import shutil
import subprocess
import webbrowser
import urllib.parse
import ctypes
from typing import Tuple, Optional, Dict, List, Any
from PySide6.QtCore import QObject, Signal

class SafeAppRegistry:
    """Strict allowlist of verified Windows tools and web portals."""

    SAFE_COMMANDS = {
        "calculator": {
            "name": "Calculator",
            "desc": "Windows Calculator",
            "search_keys": ["calc.exe", "calc"],
            "static_paths": [
                r"C:\Windows\System32\calc.exe",
                r"C:\Windows\calc.exe"
            ]
        },
        "notepad": {
            "name": "Notepad",
            "desc": "Windows Notepad Text Editor",
            "search_keys": ["notepad.exe", "notepad"],
            "static_paths": [
                r"C:\Windows\System32\notepad.exe",
                r"C:\Windows\notepad.exe"
            ]
        },
        "explorer": {
            "name": "File Explorer",
            "desc": "Windows File Explorer",
            "search_keys": ["explorer.exe", "explorer"],
            "static_paths": [
                r"C:\Windows\explorer.exe",
                r"C:\Windows\System32\explorer.exe"
            ]
        },
        "settings": {
            "name": "Windows Settings",
            "desc": "Windows Settings Control Hub",
            "protocol": "ms-settings:"
        },
        "task_manager": {
            "name": "Task Manager",
            "desc": "Windows Task Manager Process Monitor",
            "search_keys": ["taskmgr.exe", "taskmgr"],
            "static_paths": [
                r"C:\Windows\System32\taskmgr.exe",
                r"C:\Windows\taskmgr.exe"
            ]
        },
        "taskmanager": {
            "name": "Task Manager",
            "desc": "Windows Task Manager Process Monitor",
            "search_keys": ["taskmgr.exe", "taskmgr"],
            "static_paths": [
                r"C:\Windows\System32\taskmgr.exe",
                r"C:\Windows\taskmgr.exe"
            ]
        },
        "cmd": {
            "name": "Command Prompt",
            "desc": "Windows Command Prompt Shell",
            "search_keys": ["cmd.exe", "cmd"],
            "static_paths": [
                r"C:\Windows\System32\cmd.exe"
            ]
        },
        "vscode": {
            "name": "Visual Studio Code",
            "desc": "Visual Studio Code Editor",
            "search_keys": ["code.cmd", "code.exe", "code"],
            "static_paths": [
                os.path.expandvars(r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe"),
                os.path.expandvars(r"%LOCALAPPDATA%\Programs\Microsoft VS Code\bin\code.cmd"),
                r"C:\Program Files\Microsoft VS Code\Code.exe",
                r"C:\Program Files (x86)\Microsoft VS Code\Code.exe"
            ]
        },
        "chrome": {
            "name": "Google Chrome",
            "desc": "Google Chrome Web Browser",
            "search_keys": ["chrome.exe", "chrome"],
            "static_paths": [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
            ],
            "fallback_url": "https://www.google.com/"
        },
        "whatsapp": {
            "name": "WhatsApp",
            "desc": "WhatsApp Messaging Application",
            "protocol": "whatsapp:",
            "static_paths": [
                os.path.expandvars(r"%LOCALAPPDATA%\WhatsApp\WhatsApp.exe")
            ],
            "fallback_url": "https://web.whatsapp.com/"
        }
    }

    SAFE_URLS = {
        "youtube": ("YouTube", "https://www.youtube.com/"),
        "google": ("Google Search", "https://www.google.com/"),
        "linkedin": ("LinkedIn", "https://www.linkedin.com/"),
        "whatsapp": ("WhatsApp Web", "https://web.whatsapp.com/"),
        "github": ("GitHub", "https://github.com/"),
        "gmail": ("Gmail", "https://mail.google.com/"),
        "chatgpt": ("ChatGPT", "https://chatgpt.com/"),
        "chrome": ("Google Chrome Web", "https://www.google.com/")
    }


class ApplicationLauncher(QObject):
    action_completed = Signal(str, bool, str)            # action_name, success, message
    confirmation_requested = Signal(str, str, object)    # title, message, callback

    def __init__(self, parent: Optional[QObject] = None, dry_run: bool = False):
        super().__init__(parent)
        self.dry_run = dry_run
        self._cached_paths: Dict[str, str] = {}

    def resolve_executable_path(self, app_key: str) -> Optional[str]:
        """Dynamically locates installed executable path using multiple discovery mechanisms."""
        key = app_key.lower().strip()
        if key in self._cached_paths:
            cached = self._cached_paths[key]
            if os.path.exists(cached):
                return cached

        if key not in SafeAppRegistry.SAFE_COMMANDS:
            return None

        info = SafeAppRegistry.SAFE_COMMANDS[key]

        # 1. Check known static installation paths
        for p in info.get("static_paths", []):
            if p and os.path.exists(p):
                self._cached_paths[key] = p
                return p

        # 2. Check system PATH
        for s in info.get("search_keys", []):
            found = shutil.which(s)
            if found and os.path.exists(found):
                self._cached_paths[key] = found
                return found

        # 3. Check Windows Registry App Paths (HKLM & HKCU)
        try:
            import winreg
            search_exe = info.get("search_keys", [f"{key}.exe"])[0]
            reg_paths = [
                (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{search_exe}"),
                (winreg.HKEY_CURRENT_USER, rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{search_exe}")
            ]
            for hkey, subkey in reg_paths:
                try:
                    with winreg.OpenKey(hkey, subkey) as rk:
                        val, _ = winreg.QueryValueEx(rk, "")
                        if val and os.path.exists(val):
                            self._cached_paths[key] = val
                            return val
                except OSError:
                    pass
        except Exception:
            pass

        return None

    def launch(self, action_id: str, prompt_confirmation: bool = True) -> Tuple[bool, str]:
        """Unified dispatcher invoked by UI action buttons, natural commands, and voice triggers."""
        key = action_id.lower().strip()

        if key == "lock":
            return self.lock_workstation(prompt_confirmation=prompt_confirmation)
        elif key in SafeAppRegistry.SAFE_COMMANDS:
            return self.launch_app(key)
        elif key in SafeAppRegistry.SAFE_URLS:
            return self.open_web_portal(key)
        else:
            return self.launch_app(key)

    def parse_and_execute_command(self, command_text: str) -> Tuple[bool, str]:
        """Dispatches natural language and voice commands to the verified tool router."""
        from backend.tool_router import ToolRouter
        router = ToolRouter(self)
        res = router.try_direct_intent(command_text)
        if res is not None:
            return res

        msg = f"No direct automation matching '{command_text}'. Try 'open calculator', 'open notepad', 'launch chrome', or 'open whatsapp'."
        self.action_completed.emit("Command Dispatcher", False, msg)
        return False, msg

    def launch_app(self, app_key: str, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Launches a local Windows application from the safe registry."""
        is_dry = self.dry_run if dry_run is None else dry_run
        key = app_key.lower().strip()

        if key not in SafeAppRegistry.SAFE_COMMANDS:
            msg = f"Application '{app_key}' is not in the safe allowlist."
            self.action_completed.emit(app_key, False, msg)
            return False, msg

        info = SafeAppRegistry.SAFE_COMMANDS[key]
        name = info["name"]

        # Dry run validation
        if is_dry:
            msg = f"[Dry Run Verified] '{name}' validated in safe command registry."
            self.action_completed.emit(name, True, msg)
            return True, msg

        # Special handler delegation for rich tools
        if key in ("vscode", "code"):
            return self.launch_vscode(dry_run=is_dry)
        elif key == "whatsapp":
            return self.launch_whatsapp(dry_run=is_dry)
        elif key == "explorer":
            return self.open_file_explorer(dry_run=is_dry)

        # Windows physical interactive desktop startupinfo
        si = subprocess.STARTUPINFO()
        try:
            si.lpDesktop = "winsta0\\default"
        except Exception:
            pass

        # Protocol launch (e.g. ms-settings:)
        if "protocol" in info and key == "settings":
            try:
                subprocess.Popen(["cmd.exe", "/c", "start", info["protocol"]], startupinfo=si)
                msg = f"{name} opened successfully."
                self.action_completed.emit(name, True, msg)
                return True, msg
            except Exception as e:
                err_msg = f"Failed to open {name}: {e}"
                self.action_completed.emit(name, False, err_msg)
                return False, err_msg

        # Resolve executable path on disk
        exe_path = self.resolve_executable_path(key)

        # Fallback handling for Chrome / WhatsApp
        if not exe_path:
            if key == "whatsapp":
                # Try opening Windows Store App protocol; fallback to WhatsApp Web
                try:
                    subprocess.Popen(["cmd.exe", "/c", "start", "whatsapp:"], startupinfo=si)
                    msg = "WhatsApp application launched."
                    self.action_completed.emit(name, True, msg)
                    return True, msg
                except Exception:
                    return self.open_web_portal("whatsapp", dry_run=is_dry)

            if key == "chrome":
                return self.open_web_portal("chrome", dry_run=is_dry)

            msg = f"{name} is not installed or could not be found on your system."
            self.action_completed.emit(name, False, msg)
            return False, msg

        # Launch using subprocess argument list with shell=False
        try:
            if exe_path.lower().endswith(".cmd") or exe_path.lower().endswith(".bat"):
                subprocess.Popen([exe_path], shell=True, startupinfo=si)
            else:
                subprocess.Popen([exe_path], shell=False, startupinfo=si)

            msg = f"{name} launched successfully."
            self.action_completed.emit(name, True, msg)
            return True, msg

        except Exception as e:
            err_msg = f"Failed to launch {name}: {e}"
            self.action_completed.emit(name, False, err_msg)
            return False, err_msg

    def is_chrome_default_browser(self) -> Tuple[bool, str]:
        """Detects whether Google Chrome is set as the Windows default HTTP browser."""
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as key:
                progid, _ = winreg.QueryValueEx(key, "ProgId")
                if "chrome" in progid.lower():
                    return True, "Google Chrome is configured as your Windows default browser."
                else:
                    return False, f"Current Windows default browser is '{progid}'. You can select Chrome in Windows Settings -> Default Apps."
        except Exception:
            chrome_path = self.resolve_executable_path("chrome")
            if chrome_path:
                return True, "Google Chrome is installed on your system."
            return False, "Could not verify default browser from registry."

    def open_url_in_chrome(self, url: str, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """
        Reliably opens a URL in Google Chrome (default browser), or system default if Chrome unavailable.
        Uses single-instance delegation to avoid duplicate Chrome processes.
        """
        is_dry = self.dry_run if dry_run is None else dry_run
        url = url.strip()
        if not url.startswith("http://") and not url.startswith("https://"):
            url = f"https://{url}"

        if is_dry:
            msg = f"[Dry Run Verified] URL '{url}' validated for Chrome browser opening."
            self.action_completed.emit("Web Browser", True, msg)
            return True, msg

        si = subprocess.STARTUPINFO()
        try:
            si.lpDesktop = "winsta0\\default"
        except Exception:
            pass

        # 1. Direct Chrome launch (Chrome IPC routes URL to active window tab without duplicate processes)
        chrome_exe = self.resolve_executable_path("chrome")
        if chrome_exe and os.path.exists(chrome_exe):
            try:
                subprocess.Popen([chrome_exe, url], shell=False, startupinfo=si)
                msg = f"Opened {url} in Google Chrome."
                self.action_completed.emit("Google Chrome", True, msg)
                return True, msg
            except Exception:
                pass

        # 2. Windows os.startfile fallback
        try:
            os.startfile(url)
            msg = f"Opened {url} in Windows default browser."
            self.action_completed.emit("Web Browser", True, msg)
            return True, msg
        except Exception:
            pass

        # 3. Python webbrowser fallback
        try:
            opened = webbrowser.open(url)
            msg = f"Opened {url}."
            self.action_completed.emit("Web Browser", opened, msg)
            return opened, msg
        except Exception as e:
            err_msg = f"Failed to open URL '{url}': {e}"
            self.action_completed.emit("Web Browser", False, err_msg)
            return False, err_msg

    def open_web_portal(self, portal_key: str, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Opens a verified web portal in the default or detected Chrome browser."""
        key = portal_key.lower().strip()

        if key not in SafeAppRegistry.SAFE_URLS:
            msg = f"Web portal '{portal_key}' is not in the verified list."
            self.action_completed.emit(portal_key, False, msg)
            return False, msg

        name, url = SafeAppRegistry.SAFE_URLS[key]
        return self.open_url_in_chrome(url, dry_run=dry_run)

    def open_custom_website(self, url: str, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Safely opens an arbitrary user-specified web URL."""
        return self.open_url_in_chrome(url, dry_run=dry_run)

    def search_google(self, query: str, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Executes a Google web search in Chrome."""
        query = query.strip()
        if not query:
            return False, "Search query cannot be empty."

        encoded = urllib.parse.quote_plus(query)
        url = f"https://www.google.com/search?q={encoded}"
        return self.open_url_in_chrome(url, dry_run=dry_run)

    def search_youtube(self, query: str, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Executes a YouTube video search in Chrome."""
        query = query.strip()
        if not query:
            return False, "Search query cannot be empty."

        encoded = urllib.parse.quote_plus(query)
        url = f"https://www.youtube.com/results?search_query={encoded}"
        return self.open_url_in_chrome(url, dry_run=dry_run)

    def launch_vscode(self, folder_path: Optional[str] = None, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Launches Visual Studio Code, optionally opening a requested directory."""
        is_dry = self.dry_run if dry_run is None else dry_run
        if is_dry:
            msg = f"[Dry Run Verified] VS Code launch validated (folder: '{folder_path or 'Workspace'}')."
            self.action_completed.emit("Visual Studio Code", True, msg)
            return True, msg

        exe_path = self.resolve_executable_path("vscode")
        if not exe_path:
            msg = "Visual Studio Code is not installed or could not be found."
            self.action_completed.emit("Visual Studio Code", False, msg)
            return False, msg

        si = subprocess.STARTUPINFO()
        try:
            si.lpDesktop = "winsta0\\default"
        except Exception:
            pass

        cmd = [exe_path]
        if folder_path and os.path.exists(folder_path):
            cmd.append(os.path.normpath(folder_path))

        try:
            if exe_path.lower().endswith((".cmd", ".bat")):
                subprocess.Popen(cmd, shell=True, startupinfo=si)
            else:
                subprocess.Popen(cmd, shell=False, startupinfo=si)
            folder_str = f" in folder '{folder_path}'" if folder_path else ""
            msg = f"Visual Studio Code launched{folder_str}."
            self.action_completed.emit("Visual Studio Code", True, msg)
            return True, msg
        except Exception as e:
            err_msg = f"Failed to launch VS Code: {e}"
            self.action_completed.emit("Visual Studio Code", False, err_msg)
            return False, err_msg

    def open_file_explorer(self, folder_path: Optional[str] = None, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Opens Windows File Explorer, optionally navigated to a target folder."""
        is_dry = self.dry_run if dry_run is None else dry_run
        if is_dry:
            msg = f"[Dry Run Verified] File Explorer launch validated (path: '{folder_path or 'Default'}')."
            self.action_completed.emit("File Explorer", True, msg)
            return True, msg

        si = subprocess.STARTUPINFO()
        try:
            si.lpDesktop = "winsta0\\default"
        except Exception:
            pass

        cmd = ["explorer.exe"]
        target_name = "File Explorer"
        if folder_path and os.path.exists(folder_path):
            cmd.append(os.path.normpath(folder_path))
            target_name = f"File Explorer ({folder_path})"

        try:
            subprocess.Popen(cmd, shell=False, startupinfo=si)
            msg = f"Opened {target_name}."
            self.action_completed.emit("File Explorer", True, msg)
            return True, msg
        except Exception as e:
            err_msg = f"Failed to open File Explorer: {e}"
            self.action_completed.emit("File Explorer", False, err_msg)
            return False, err_msg

    def launch_whatsapp(self, dry_run: Optional[bool] = None) -> Tuple[bool, str]:
        """Launches WhatsApp Desktop application, falling back to WhatsApp Web in Chrome."""
        is_dry = self.dry_run if dry_run is None else dry_run
        if is_dry:
            msg = "[Dry Run Verified] WhatsApp Desktop / Web launch validated."
            self.action_completed.emit("WhatsApp", True, msg)
            return True, msg

        # 1. Try Windows Store / Protocol activation
        try:
            os.startfile("whatsapp:")
            msg = "WhatsApp Desktop launched."
            self.action_completed.emit("WhatsApp Desktop", True, msg)
            return True, msg
        except Exception:
            pass

        # 2. Try desktop executable
        exe_path = self.resolve_executable_path("whatsapp")
        if exe_path and os.path.exists(exe_path):
            try:
                si = subprocess.STARTUPINFO()
                si.lpDesktop = "winsta0\\default"
                subprocess.Popen([exe_path], shell=False, startupinfo=si)
                msg = "WhatsApp Desktop launched."
                self.action_completed.emit("WhatsApp Desktop", True, msg)
                return True, msg
            except Exception:
                pass

        # 3. Fallback to WhatsApp Web in Chrome
        return self.open_url_in_chrome("https://web.whatsapp.com/", dry_run=is_dry)

    def lock_workstation(self, prompt_confirmation: bool = True) -> Tuple[bool, str]:
        """Locks the Windows desktop session with user confirmation."""
        if prompt_confirmation:
            self.confirmation_requested.emit(
                "Confirm Security Action",
                "Are you sure you want JARVIS to lock your Windows workstation?",
                lambda: self._execute_lock()
            )
            return True, "Awaiting user confirmation to lock workstation..."
        else:
            return self._execute_lock()

    def _execute_lock(self) -> Tuple[bool, str]:
        if self.dry_run:
            msg = "[Dry Run Verified] Workstation lock action validated."
            self.action_completed.emit("Lock Workstation", True, msg)
            return True, msg

        try:
            ctypes.windll.user32.LockWorkStation()
            msg = "Windows Workstation locked successfully."
            self.action_completed.emit("Lock Workstation", True, msg)
            return True, msg
        except Exception as e:
            err_msg = f"Failed to lock workstation: {e}"
            self.action_completed.emit("Lock Workstation", False, err_msg)
            return False, err_msg
