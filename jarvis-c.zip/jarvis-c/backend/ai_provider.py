"""
JARVIS AI — Groq AI Provider Service
Handles official Groq client connections, real-time response streaming,
model fallbacks, connection testing, and error classification.
"""

import re
from typing import List, Dict, Generator, Any, Optional, Tuple
from groq import (
    Groq, APIError, AuthenticationError, RateLimitError,
    APITimeoutError, APIConnectionError, NotFoundError
)

from backend.config import config

class GroqProvider:
    def __init__(self):
        self._client: Optional[Groq] = None
        self._last_key: str = ""

    def _get_client(self, api_key: Optional[str] = None) -> Groq:
        """Gets or re-creates the cached Groq client when API key changes."""
        key = (api_key or config.groq_api_key or "").strip()
        if not key or key in ("your_groq_api_key_here", "gsk_your_groq_api_key_here"):
            raise AuthenticationError("Groq API key is not configured. Please add your key to .env or in Settings.")

        if self._client is None or key != self._last_key:
            self._client = Groq(api_key=key, timeout=20.0, max_retries=1)
            self._last_key = key

        return self._client

    def get_client(self, api_key: Optional[str] = None) -> Groq:
        """Public accessor for official Groq client."""
        return self._get_client(api_key)

    def test_connection(self, api_key: Optional[str] = None) -> Tuple[bool, str]:
        """
        Validates API credentials by querying active models from Groq Cloud.
        Verifies that configured GROQ_MODEL or supported open models are available.
        """
        try:
            client = self._get_client(api_key)
            models = client.models.list()
            model_ids = [m.id for m in models.data]
            count = len(model_ids)

            # Check if active model is available
            active_model = config.groq_model
            model_note = f"'{active_model}' active" if active_model in model_ids else f"{count} models available"
            return True, f"Connection verified. Groq API is responsive ({model_note})."
        except AuthenticationError:
            return False, "Authentication failed: Invalid Groq API Key."
        except RateLimitError:
            return False, "Rate limit reached: Your Groq account is currently rate-limited."
        except APIConnectionError:
            return False, "Connection error: Unable to reach Groq Cloud servers. Check your internet connection."
        except Exception as e:
            return False, f"Groq test failed: {self._sanitize_error(e)}"

    def stream_chat(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        temperature: float = 0.5,
        max_tokens: int = 2048
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Streams response tokens from Groq API.
        Attempts configured GROQ_MODEL (config.groq_model), then fallback model (config.ai_fallback_model),
        then high-availability standard models (openai/gpt-oss-120b, openai/gpt-oss-20b, qwen/qwen3.8-27b).
        Yields dict with {"type": "content", "delta": text} or {"type": "tool_delta", "tool_call": ...}
        """
        client = self._get_client()

        # Models candidate sequence
        candidates = [
            config.groq_model,
            config.ai_fallback_model,
            "openai/gpt-oss-120b",
            "openai/gpt-oss-20b",
            "qwen/qwen3.8-27b",
            "llama-3.3-70b-versatile",
            "llama-3.1-8b-instant"
        ]
        # De-duplicate while preserving order
        models_to_try = []
        for m in candidates:
            if m and m not in models_to_try:
                models_to_try.append(m)

        last_error = None
        for model in models_to_try:
            try:
                kwargs = {
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "stream": True
                }
                if tools:
                    kwargs["tools"] = tools
                    kwargs["tool_choice"] = "auto"

                stream = client.chat.completions.create(**kwargs)

                has_yielded = False
                # Stream chunks
                for chunk in stream:
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if not delta:
                        continue

                    # Text content token
                    if delta.content:
                        has_yielded = True
                        yield {"type": "content", "delta": delta.content, "model": model}

                    # Tool call delta
                    if delta.tool_calls:
                        has_yielded = True
                        for tc in delta.tool_calls:
                            yield {"type": "tool_delta", "tool_call": tc, "model": model}

                # If content was streamed successfully, stop trying fallbacks
                if has_yielded:
                    return

            except AuthenticationError as e:
                # Key error is fatal, don't retry models
                raise AuthenticationError("Invalid Groq API Key. Please verify your credentials in .env or Settings.") from e

            except (NotFoundError, APIError, APIConnectionError, APITimeoutError) as e:
                last_error = e
                # Try next model if model not found or rate limited on specific model
                err_str = str(e).lower()
                if "model" in err_str or "not found" in err_str or "rate limit" in err_str or "404" in err_str:
                    continue
                else:
                    raise

        # If all candidates failed
        if last_error:
            raise last_error

    def _sanitize_error(self, e: Exception) -> str:
        """Sanitizes exceptions to prevent accidental leakage of API credentials."""
        msg = str(e)
        msg = re.sub(r'gsk_[A-Za-z0-9_-]{12,}', 'gsk_[REDACTED]', msg)
        msg = re.sub(r'AIzaSy[A-Za-z0-9_-]{12,}', 'AIzaSy[REDACTED]', msg)
        key = config.groq_api_key
        if key and len(key) > 8:
            msg = msg.replace(key, "gsk_[REDACTED]")
        return msg

