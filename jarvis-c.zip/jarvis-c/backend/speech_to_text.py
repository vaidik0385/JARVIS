"""
JARVIS AI — Mode A Speech-to-Text & Audio Dictation
Records microphone audio using sounddevice, computes real-time RMS audio levels,
and transcribes speech to text via Groq Whisper (whisper-large-v3-turbo).
Zero-disk footprint (uses in-memory WAV buffer).
"""

import io
import math
import numpy as np
from typing import Optional, List
from PySide6.QtCore import QObject, Signal, QThread
import sounddevice as sd
import soundfile as sf
from groq import Groq, AuthenticationError, RateLimitError, APIError

from backend.config import config

SAMPLE_RATE = 16000
CHANNELS = 1

class TranscribeWorker(QThread):
    transcription_ready = Signal(str)
    transcription_failed = Signal(str)

    def __init__(self, audio_data: np.ndarray, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.audio_data = audio_data

    def run(self):
        try:
            key = config.groq_api_key
            if not key:
                self.transcription_failed.emit("Groq API key required for Whisper speech recognition. Please configure in Settings.")
                return

            # Check for non-empty audio
            if len(self.audio_data) < SAMPLE_RATE * 0.4:
                self.transcription_failed.emit("Recording too short. Please speak clearly into the microphone.")
                return

            # Check audio amplitude / silence
            rms = np.sqrt(np.mean(self.audio_data ** 2))
            if rms < 0.005:
                self.transcription_failed.emit("No audible voice detected. Please check your microphone volume.")
                return

            # Encode numpy float array to in-memory WAV buffer
            wav_buf = io.BytesIO()
            sf.write(wav_buf, self.audio_data, SAMPLE_RATE, format="WAV", subtype="PCM_16")
            wav_buf.seek(0)

            # Call Groq Whisper API
            client = Groq(api_key=key, timeout=25.0)
            model_name = config.whisper_model or "whisper-large-v3-turbo"

            # Support Hindi, English, and Hinglish automatic language recognition
            transcription = client.audio.transcriptions.create(
                file=("speech.wav", wav_buf.read(), "audio/wav"),
                model=model_name,
                response_format="json",
                temperature=0.0
            )

            text = transcription.text.strip() if hasattr(transcription, "text") else str(transcription).strip()
            if text:
                self.transcription_ready.emit(text)
            else:
                self.transcription_failed.emit("Could not decipher speech. Please try again.")

        except AuthenticationError:
            self.transcription_failed.emit("Invalid Groq API Key. Please verify credentials in Settings.")
        except RateLimitError:
            self.transcription_failed.emit("Groq Whisper rate limit exceeded. Please wait a moment.")
        except APIError as e:
            self.transcription_failed.emit(f"Whisper transcription error: {e}")
        except Exception as e:
            self.transcription_failed.emit(f"Audio processing error: {e}")


class SpeechToTextService(QObject):
    recording_started = Signal()
    recording_stopped = Signal()
    audio_level_updated = Signal(float)  # 0.0 to 1.0 for visual waves
    transcription_completed = Signal(str)
    transcription_error = Signal(str)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._stream: Optional[sd.InputStream] = None
        self._audio_chunks: List[np.ndarray] = []
        self._is_recording = False
        self._transcribe_worker: Optional[TranscribeWorker] = None

    def start_recording(self) -> bool:
        """Starts capturing audio frames from the default system microphone."""
        if self._is_recording:
            return True

        self._audio_chunks.clear()

        try:
            self._stream = sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype="float32",
                callback=self._audio_callback,
                blocksize=1024
            )
            self._stream.start()
            self._is_recording = True
            self.recording_started.emit()
            return True

        except Exception as e:
            self.transcription_error.emit(f"Microphone access error: {e}")
            self._is_recording = False
            return False

    def stop_recording(self):
        """Stops microphone stream and triggers transcription."""
        if not self._is_recording:
            return

        self._is_recording = False
        self.recording_stopped.emit()

        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None

        if not self._audio_chunks:
            self.transcription_error.emit("No audio recorded.")
            return

        # Concatenate audio chunks
        full_audio = np.concatenate(self._audio_chunks, axis=0)
        self._audio_chunks.clear()

        # Launch transcription worker
        self._transcribe_worker = TranscribeWorker(full_audio, parent=self)
        self._transcribe_worker.transcription_ready.connect(self.transcription_completed.emit)
        self._transcribe_worker.transcription_failed.connect(self.transcription_error.emit)
        self._transcribe_worker.start()

    def _audio_callback(self, indata, frames, time_info, status):
        if status:
            pass
        if self._is_recording:
            chunk = indata.copy()
            self._audio_chunks.append(chunk)

            # Compute RMS amplitude for UI reactivity
            rms = np.sqrt(np.mean(chunk ** 2))
            level = max(0.0, min(1.0, float(rms * 12.0)))
            self.audio_level_updated.emit(level)
