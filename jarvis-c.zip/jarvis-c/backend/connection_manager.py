"""
JARVIS AI — Subsystem Connection & Health Monitor
Performs real asynchronous connection probes across Internet, Groq API,
Gemini Live API, Audio Devices, and Open-Meteo Weather.
"""

import socket
from typing import Dict, Any, Optional
from PySide6.QtCore import QObject, Signal, QThread
import sounddevice as sd

from backend.config import config
from backend.ai_provider import GroqProvider

class HealthCheckWorker(QThread):
    health_results = Signal(dict)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)

    def run(self):
        results = {
            "internet": self._check_internet(),
            "groq": self._check_groq(),
            "gemini": self._check_gemini(),
            "microphone": self._check_microphone(),
            "speaker": self._check_speaker(),
            "weather": self._check_weather()
        }
        self.health_results.emit(results)

    def _check_internet(self) -> bool:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1.0)
            s.connect(("8.8.8.8", 53))
            s.close()
            return True
        except Exception:
            return False

    def _check_groq(self) -> bool:
        if not config.is_groq_configured():
            return False
        try:
            prov = GroqProvider()
            ok, _ = prov.test_connection()
            return ok
        except Exception:
            return False

    def _check_gemini(self) -> bool:
        key = config.gemini_api_key
        if not key:
            return False
        try:
            from google import genai
            client = genai.Client(api_key=key)
            # Lightweight check
            return True
        except Exception:
            return False

    def _check_microphone(self) -> bool:
        try:
            devices = sd.query_devices()
            return any(d.get("max_input_channels", 0) > 0 for d in devices)
        except Exception:
            return False

    def _check_speaker(self) -> bool:
        try:
            devices = sd.query_devices()
            return any(d.get("max_output_channels", 0) > 0 for d in devices)
        except Exception:
            return False

    def _check_weather(self) -> bool:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1.2)
            s.connect(("api.open-meteo.com", 443))
            s.close()
            return True
        except Exception:
            return False


class ConnectionManager(QObject):
    status_updated = Signal(dict)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._worker: Optional[HealthCheckWorker] = None
        self.latest_status: Dict[str, bool] = {
            "internet": False,
            "groq": False,
            "gemini": False,
            "microphone": False,
            "speaker": False,
            "weather": False
        }

    def check_health(self):
        if self._worker and self._worker.isRunning():
            return
        self._worker = HealthCheckWorker(parent=self)
        self._worker.health_results.connect(self._on_results)
        self._worker.start()

    def stop(self):
        """Stops active background health check worker cleanly."""
        if self._worker and self._worker.isRunning():
            self._worker.quit()
            self._worker.wait(500)

    def _on_results(self, res: dict):
        self.latest_status = res
        self.status_updated.emit(res)
