"""
JARVIS AI — High-Fidelity Conversational Live Voice Engine
Real-time full-duplex conversational voice channel (ChatGPT Voice / Gemini Live paradigm).
Features:
- Low-latency microphone streaming (16kHz PCM via sounddevice)
- Real-time RMS amplitude visualizer feeding glowing Voice Orb & dynamic Waveforms
- Energy-based Voice Activity Detection (VAD) with intelligent silence detection (~850ms)
- Conversational Barge-In: user speech automatically interrupts assistant playback
- Fast Whisper speech recognition via Groq Cloud (whisper-large-v3-turbo)
- Direct desktop tool execution for spoken commands ("open calculator", "whatsapp kholo")
- Expressive conversational reasoning via Groq reasoning models (English, Hindi, Hinglish)
- Natural spoken Windows SAPI5 voice delivery with hands-free continuous dialogue loops
"""

import io
import time
import datetime
import numpy as np
from typing import Optional, List, Dict, Any
from PySide6.QtCore import QObject, Signal, QThread, QTimer
import sounddevice as sd
import soundfile as sf
from groq import Groq

from backend.config import config
from backend.text_to_speech import TextToSpeechService

SAMPLE_RATE = 16000
CHANNELS = 1
BLOCK_SIZE = 1024  # 64ms per audio buffer block

LIVE_VOICE_SYSTEM_PROMPT = """You are JARVIS AI in a real-time live voice call.
Speak naturally, warmly, and concisely like a smart AI companion (similar to ChatGPT Voice or Gemini Live).

CRITICAL SPOKEN VOICE RULES:
1. Speak conversationally in 1 to 2 crisp, natural sentences (under 35 words).
2. NEVER use markdown, bullet points, asterisks, formatting, emojis, or code blocks.
3. Automatically match the user's language:
   - If user speaks Hindi (हिंदी): respond in natural conversational Hindi.
   - If user speaks Hinglish: respond in natural spoken Hinglish.
   - If user speaks English: respond in articulate modern English.
4. Address the user respectfully (Sir / Vaidik).
5. When asked about time, weather, or system status, use the provided live context.
"""

class VoiceTurnWorker(QThread):
    user_transcribed = Signal(str)
    assistant_replied = Signal(str, str)  # user_text, assistant_spoken_text
    turn_failed = Signal(str)

    def __init__(
        self,
        audio_data: np.ndarray,
        api_key: str,
        ai_model: str,
        whisper_model: str,
        system_context: str = "",
        conversation_history: Optional[List[Dict[str, str]]] = None,
        tool_router: Optional[Any] = None,
        parent: Optional[QObject] = None
    ):
        super().__init__(parent)
        self.audio_data = audio_data
        self.api_key = api_key
        self.ai_model = ai_model
        self.whisper_model = whisper_model
        self.system_context = system_context
        self.history = conversation_history or []
        self.tool_router = tool_router

    def run(self):
        try:
            if not self.api_key:
                self.turn_failed.emit("Groq API key not configured. Please check Settings.")
                return

            # 1. Transcribe captured user utterance via Groq Whisper
            wav_buf = io.BytesIO()
            sf.write(wav_buf, self.audio_data, SAMPLE_RATE, format="WAV", subtype="PCM_16")
            wav_buf.seek(0)

            client = Groq(api_key=self.api_key, timeout=20.0)
            transcription = client.audio.transcriptions.create(
                file=("live_speech.wav", wav_buf.read(), "audio/wav"),
                model=self.whisper_model or "whisper-large-v3-turbo",
                response_format="json",
                temperature=0.0
            )

            user_text = transcription.text.strip() if hasattr(transcription, "text") else str(transcription).strip()
            # Filter noise / hallucinations on empty audio
            if not user_text or user_text in (".", "...", "!", "?", "Thank you.", "Bye."):
                self.turn_failed.emit("No clear speech detected.")
                return

            self.user_transcribed.emit(user_text)

            # 2. Check Direct Intent Execution (e.g. "open calculator", "whatsapp kholo")
            if self.tool_router:
                intent_res = self.tool_router.try_direct_intent(user_text)
                if intent_res is not None:
                    success, msg = intent_res
                    if success:
                        spoken_confirm = self._generate_tool_confirmation(user_text, msg)
                        self.assistant_replied.emit(user_text, spoken_confirm)
                        return

            # 3. Conversational AI Reasoning via Groq Cloud
            messages = [{"role": "system", "content": LIVE_VOICE_SYSTEM_PROMPT}]
            if self.system_context:
                messages.append({
                    "role": "system",
                    "content": f"[Live Telemetry & Environmental Context]\n{self.system_context}"
                })

            # Append last 4 conversational turns for fast conversational continuity
            for turn in self.history[-4:]:
                messages.append(turn)

            messages.append({"role": "user", "content": user_text})

            res = client.chat.completions.create(
                model=self.ai_model,
                messages=messages,
                max_tokens=500,
                temperature=0.6
            )

            choice = res.choices[0]
            ai_text = ""
            if choice.message.content:
                ai_text = choice.message.content.strip()
            elif hasattr(choice.message, "reasoning") and choice.message.reasoning:
                ai_text = choice.message.reasoning.strip()

            # Clean markdown formatting so TTS sounds completely natural
            clean_reply = self._clean_spoken_text(ai_text)
            if not clean_reply:
                clean_reply = "I'm online and listening, Sir. How can I help you?"

            self.assistant_replied.emit(user_text, clean_reply)

        except Exception as e:
            self.turn_failed.emit(f"Voice processing error: {e}")

    @staticmethod
    def _generate_tool_confirmation(user_text: str, action_msg: str) -> str:
        t = user_text.lower()
        if "calc" in t:
            return "Opening Calculator now, Sir."
        elif "notepad" in t:
            return "Opening Notepad for you, Sir."
        elif "whatsapp" in t:
            return "Opening WhatsApp for you now, Sir."
        elif "chrome" in t or "browser" in t:
            return "Opening Google Chrome, Sir."
        elif "youtube" in t:
            return "Launching YouTube now, Sir."
        elif "explorer" in t or "file" in t:
            return "Opening File Explorer, Sir."
        elif "lock" in t:
            return "Locking your workstation now, Sir."
        else:
            return f"Executing that now, Sir. {action_msg}"

    @staticmethod
    def _clean_spoken_text(text: str) -> str:
        import re
        # Remove asterisks, hashtags, backticks, emojis, URLs
        text = re.sub(r"[\*#_~`\[\]\(\)]", " ", text)
        text = re.sub(r"https?://\S+", "", text)
        text = " ".join(text.split()).strip()
        return text


class LiveVoiceManager(QObject):
    state_changed = Signal(str)            # "listening", "thinking", "speaking", "muted", "idle"
    amplitude_updated = Signal(float)      # 0.0 to 1.0 for visual orb & waveform
    transcript_received = Signal(str, str) # speaker ("USER" | "JARVIS" | "SYSTEM"), text
    error_occurred = Signal(str)
    session_status = Signal(str)

    # Audio VAD thresholds
    VAD_SPEECH_THRESHOLD = 0.016
    VAD_SILENCE_BLOCKS_TARGET = 13         # ~830ms of silence finishes an utterance
    VAD_BARGEIN_THRESHOLD = 0.038          # user speaking loudly over assistant

    def __init__(
        self,
        tts_service: TextToSpeechService,
        tool_router: Optional[Any] = None,
        parent: Optional[QObject] = None
    ):
        super().__init__(parent)
        self.tts = tts_service
        self.tool_router = tool_router

        self._is_active = False
        self._is_muted = False
        self._state = "idle"
        self._stream: Optional[sd.InputStream] = None

        # VAD & buffering state
        self._speech_chunks: List[np.ndarray] = []
        self._is_user_speaking = False
        self._silence_blocks = 0
        self._bargein_counter = 0

        # Conversation history & context
        self._history: List[Dict[str, str]] = []
        self._system_context = ""
        self._active_worker: Optional[VoiceTurnWorker] = None

        # Connect TTS events
        self.tts.speaking_started.connect(self._on_speech_started)
        self.tts.speaking_finished.connect(self._on_speech_finished)

    def set_system_context(self, context: str):
        """Passes real-time weather and hardware telemetry to live voice reasoning."""
        self._system_context = context

    def is_active(self) -> bool:
        return self._is_active

    def start_session(self):
        """Starts real-time live voice conversation loop."""
        if self._is_active:
            return

        key = config.groq_api_key
        if not key:
            self._set_state("idle")
            msg = "Groq API key required for live voice. Please configure in Settings."
            self.session_status.emit(msg)
            self.transcript_received.emit("SYSTEM", msg)
            return

        try:
            self._speech_chunks.clear()
            self._is_user_speaking = False
            self._silence_blocks = 0
            self._bargein_counter = 0

            # Open continuous audio input stream
            self._stream = sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype="float32",
                callback=self._audio_callback,
                blocksize=BLOCK_SIZE
            )
            self._stream.start()
            self._is_active = True
            self._set_state("speaking")

            # Greet user with time-adaptive natural opening
            hour = datetime.datetime.now().hour
            if hour < 12:
                greeting = "Good morning, Sir. Live voice channel active. I am listening."
            elif hour < 17:
                greeting = "Good afternoon, Sir. Live voice channel active. How may I assist you?"
            else:
                greeting = "Good evening, Sir. Live voice channel active. How can I help you today?"

            self.transcript_received.emit("JARVIS", greeting)
            self.tts.speak(greeting)

        except Exception as e:
            self.error_occurred.emit(f"Microphone error during live session: {e}")
            self.stop_session()

    def stop_session(self):
        """Stops live voice session, cleans up workers and releases audio hardware."""
        self._is_active = False
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None

        if self._active_worker and self._active_worker.isRunning():
            self._active_worker.terminate()
            self._active_worker = None

        self.tts.stop()
        self._speech_chunks.clear()
        self._is_user_speaking = False
        self._set_state("idle")

    def toggle_mute(self) -> bool:
        self._is_muted = not self._is_muted
        if self._is_muted:
            self._set_state("muted")
            self._speech_chunks.clear()
            self._is_user_speaking = False
        else:
            self._set_state("listening")
        return self._is_muted

    def interrupt(self):
        """Immediately interrupts assistant speech, cancels pending work, and returns to listening."""
        self.tts.stop()
        if self._active_worker and self._active_worker.isRunning():
            self._active_worker.terminate()
            self._active_worker = None

        self._speech_chunks.clear()
        self._is_user_speaking = False
        self._silence_blocks = 0
        self._set_state("listening")
        self.transcript_received.emit("SYSTEM", "Assistant interrupted. Listening to you...")

    def _audio_callback(self, indata, frames, time_info, status):
        if not self._is_active or self._is_muted:
            return

        # Compute audio RMS
        rms = float(np.sqrt(np.mean(indata ** 2)))
        amplitude = max(0.05, min(1.0, float(rms * 15.0)))
        self.amplitude_updated.emit(amplitude)

        # 1. Conversational Barge-In Check (interrupt assistant if user starts speaking)
        if self._state == "speaking":
            if rms > self.VAD_BARGEIN_THRESHOLD:
                self._bargein_counter += 1
                if self._bargein_counter >= 3:  # ~190ms of loud voice
                    self._bargein_counter = 0
                    QTimer.singleShot(0, self.interrupt)
            else:
                self._bargein_counter = max(0, self._bargein_counter - 1)
            return

        # 2. Voice Activity Detection & Chunk Collection (while in "listening" state)
        if self._state == "listening":
            if rms >= self.VAD_SPEECH_THRESHOLD:
                if not self._is_user_speaking:
                    self._is_user_speaking = True
                    self._speech_chunks.clear()

                self._speech_chunks.append(indata.copy())
                self._silence_blocks = 0

            else:
                if self._is_user_speaking:
                    self._speech_chunks.append(indata.copy())
                    self._silence_blocks += 1

                    # Check if silence timeout reached
                    if self._silence_blocks >= self.VAD_SILENCE_BLOCKS_TARGET:
                        total_samples = len(self._speech_chunks) * BLOCK_SIZE
                        duration_sec = total_samples / SAMPLE_RATE

                        if duration_sec >= 0.5:
                            # Captured complete utterance!
                            captured_data = np.concatenate(self._speech_chunks, axis=0)
                            self._speech_chunks.clear()
                            self._is_user_speaking = False
                            self._silence_blocks = 0
                            # Schedule worker dispatch on Qt event loop
                            QTimer.singleShot(0, lambda: self._process_captured_speech(captured_data))
                        else:
                            # Too short to be voice (click/noise)
                            self._speech_chunks.clear()
                            self._is_user_speaking = False
                            self._silence_blocks = 0

    def _process_captured_speech(self, audio_data: np.ndarray):
        if not self._is_active or self._state == "muted":
            return

        self._set_state("thinking")
        self.transcript_received.emit("USER", "Listening and thinking...")

        # Spawn non-blocking background worker
        self._active_worker = VoiceTurnWorker(
            audio_data=audio_data,
            api_key=config.groq_api_key,
            ai_model=config.ai_model,
            whisper_model=config.whisper_model or "whisper-large-v3-turbo",
            system_context=self._system_context,
            conversation_history=self._history,
            tool_router=self.tool_router,
            parent=self
        )
        self._active_worker.user_transcribed.connect(self._on_user_transcribed)
        self._active_worker.assistant_replied.connect(self._on_assistant_replied)
        self._active_worker.turn_failed.connect(self._on_turn_failed)
        self._active_worker.start()

    def _on_user_transcribed(self, user_text: str):
        self.transcript_received.emit("USER", user_text)

    def _on_assistant_replied(self, user_text: str, assistant_text: str):
        # Update conversation context
        self._history.append({"role": "user", "content": user_text})
        self._history.append({"role": "assistant", "content": assistant_text})
        if len(self._history) > 10:
            self._history = self._history[-10:]

        self.transcript_received.emit("JARVIS", assistant_text)
        self._set_state("speaking")
        self.tts.speak(assistant_text)

    def _on_turn_failed(self, reason: str):
        # Revert back to listening smoothly
        self._set_state("listening")

    def _set_state(self, state: str):
        self._state = state
        self.state_changed.emit(state)

    def _on_speech_started(self, text: str):
        if self._is_active and not self._is_muted:
            self._set_state("speaking")

    def _on_speech_finished(self):
        if self._is_active and not self._is_muted:
            self._set_state("listening")
