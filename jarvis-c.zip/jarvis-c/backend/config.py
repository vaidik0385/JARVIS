"""
JARVIS AI — Secure Configuration & Credential Manager
Loads environment variables from .env and integrates with Windows Credential Manager
via keyring for secure, encrypted on-disk storage.
"""

import os
import re
from pathlib import Path
from typing import Optional, Dict
from dotenv import load_dotenv, set_key

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"
SERVICE_NAME = "JARVIS_AI"

# Keyring support
try:
    import keyring
    HAS_KEYRING = True
except ImportError:
    HAS_KEYRING = False


class Config:
    def __init__(self):
        self.reload()

    def reload(self):
        """Reload configuration from .env and Windows Credential Manager."""
        if ENV_PATH.exists():
            load_dotenv(dotenv_path=ENV_PATH, override=True)
        else:
            load_dotenv(override=True)

        self.groq_api_key = self._get_secret("GROQ_API_KEY")
        self.gemini_api_key = self._get_secret("GEMINI_API_KEY")
        self.coingecko_api_key = self._get_secret("COINGECKO_API_KEY")
        self.alphavantage_api_key = self._get_secret("ALPHAVANTAGE_API_KEY")
        self.tavily_api_key = self._get_secret("TAVILY_API_KEY")

        # GROQ_MODEL takes precedence, fallback to AI_MODEL, default to llama-3.3-70b-versatile
        self.groq_model = (
            os.getenv("GROQ_MODEL") or 
            os.getenv("AI_MODEL") or 
            "llama-3.3-70b-versatile"
        ).strip()
        self.ai_model = self.groq_model
        self.ai_fallback_model = os.getenv("AI_FALLBACK_MODEL", "llama-3.1-8b-instant").strip()
        self.whisper_model = os.getenv("WHISPER_MODEL", "whisper-large-v3-turbo").strip()

        self.weather_location = os.getenv("WEATHER_LOCATION", "New Delhi").strip()
        self.tts_voice_rate = int(os.getenv("TTS_VOICE_RATE", "180"))
        self.tts_volume = float(os.getenv("TTS_VOLUME", "1.0"))

    def _get_secret(self, key_name: str) -> str:
        """
        Fetch secret prioritizing .env file, then falling back to Windows Credential Manager.
        Filters out default placeholder strings.
        """
        val = os.getenv(key_name, "").strip()

        # Check for placeholder string
        if val in ("your_groq_api_key_here", "your_gemini_api_key_here", "gsk_your_groq_api_key_here"):
            val = ""

        # If not found in .env, check Windows Credential Manager
        if not val and HAS_KEYRING:
            try:
                secret = keyring.get_password(SERVICE_NAME, key_name)
                if secret and secret.strip():
                    val = secret.strip()
            except Exception:
                pass

        return val

    def set_secret(self, key_name: str, value: str, save_to_env: bool = True) -> bool:
        """
        Securely save secret to Windows Credential Manager and to .env file.
        Updates in-memory state immediately.
        """
        value = value.strip()
        success = True

        # 1. Save to .env file
        if save_to_env:
            try:
                if not ENV_PATH.exists():
                    ENV_PATH.touch(mode=0o600)
                set_key(str(ENV_PATH), key_name, value)
            except Exception as e:
                print(f"[Config] Warning: .env write failed: {e}")
                success = False

        # 2. Save to Windows Credential Manager
        if HAS_KEYRING:
            try:
                if value:
                    keyring.set_password(SERVICE_NAME, key_name, value)
                else:
                    try:
                        keyring.delete_password(SERVICE_NAME, key_name)
                    except Exception:
                        pass
            except Exception as e:
                print(f"[Config] Warning: Keyring write failed: {e}")
                success = False

        # 3. Update active environment and instance attribute
        os.environ[key_name] = value
        if key_name == "GROQ_API_KEY":
            self.groq_api_key = value
        elif key_name == "GEMINI_API_KEY":
            self.gemini_api_key = value
        elif key_name == "COINGECKO_API_KEY":
            self.coingecko_api_key = value
        elif key_name == "ALPHAVANTAGE_API_KEY":
            self.alphavantage_api_key = value
        elif key_name == "TAVILY_API_KEY":
            self.tavily_api_key = value

        return success

    def set_model(self, model_name: str) -> bool:
        """Sets active Groq model in .env and runtime."""
        model_name = model_name.strip()
        if not model_name:
            return False
        self.groq_model = model_name
        self.ai_model = model_name
        os.environ["GROQ_MODEL"] = model_name
        os.environ["AI_MODEL"] = model_name
        try:
            if not ENV_PATH.exists():
                ENV_PATH.touch(mode=0o600)
            set_key(str(ENV_PATH), "GROQ_MODEL", model_name)
            set_key(str(ENV_PATH), "AI_MODEL", model_name)
            return True
        except Exception:
            return False

    def is_groq_configured(self) -> bool:
        """Returns True if a non-placeholder Groq API key is present."""
        return bool(self.groq_api_key and len(self.groq_api_key) > 10 and self.groq_api_key.startswith("gsk_"))

    @staticmethod
    def mask_key(key: Optional[str]) -> str:
        """Safely masks an API key for UI display without leaking credentials."""
        if not key or len(key) < 8 or key in ("your_groq_api_key_here", "your_gemini_api_key_here"):
            return "Not Configured"
        if key.startswith("gsk_"):
            return f"gsk_•••••••••••••••••••••••••••••{key[-4:]}"
        return f"{key[:4]}••••••••••••••••••••{key[-4:]}"


# Global singleton instance
config = Config()

