"""
JARVIS AI — Text-to-Speech (TTS) Service
Asynchronous non-blocking speech synthesis utilizing Windows SAPI5 via pyttsx3.
Supports immediate interruption, rate control, volume adjustment, and voice switching.
"""

import re
import queue
from typing import Optional, List, Dict
from PySide6.QtCore import QObject, Signal, QThread
import pyttsx3

from backend.config import config

class TTSWorker(QThread):
    speech_started = Signal(str)
    speech_finished = Signal()
    speech_error = Signal(str)

    def __init__(self, voice_id: Optional[str] = None, rate: int = 180, volume: float = 1.0, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.voice_id = voice_id
        self.rate = rate
        self.volume = volume
        self._queue = queue.Queue()
        self._running = True
        self._engine = None

    def speak(self, text: str):
        # Strip markdown syntax before speaking
        clean_text = self._clean_markdown(text)
        if clean_text:
            self._queue.put(clean_text)

    def stop_current(self):
        # Empty queue
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break
        if self._engine:
            try:
                self._engine.stop()
            except Exception:
                pass
        self.speech_finished.emit()

    def run(self):
        # Initialize COM library for worker thread on Windows
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except Exception:
            pass

        # Initialize TTS engine in worker thread
        try:
            self._engine = pyttsx3.init()
            if self.voice_id:
                self._engine.setProperty("voice", self.voice_id)
            self._engine.setProperty("rate", self.rate)
            self._engine.setProperty("volume", self.volume)
        except Exception as e:
            self.speech_error.emit(f"TTS initialization failed: {e}")
            return

        try:
            while self._running:
                try:
                    text = self._queue.get(timeout=0.3)
                except queue.Empty:
                    continue

                if not text or not self._running:
                    continue

                try:
                    self.speech_started.emit(text)
                    self._engine.say(text)
                    self._engine.runAndWait()
                    self.speech_finished.emit()
                except Exception as e:
                    self.speech_error.emit(f"Speech synthesis error: {e}")
                    self.speech_finished.emit()
        finally:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass

    def shutdown(self):
        self._running = False
        self.stop_current()
        self.wait(1000)

    @staticmethod
    def _clean_markdown(text: str) -> str:
        # Remove code blocks
        text = re.sub(r"```[\s\S]*?```", " Code block omitted. ", text)
        # Remove inline code
        text = re.sub(r"`([^`]+)`", r"\1", text)
        # Remove markdown headers and bullets
        text = re.sub(r"[#*_\-~>]", " ", text)
        # Remove URLs
        text = re.sub(r"https?://\S+", "", text)
        return " ".join(text.split()).strip()


class TextToSpeechService(QObject):
    speaking_started = Signal(str)
    speaking_finished = Signal()

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._worker: Optional[TTSWorker] = None
        self._current_voice_id: Optional[str] = None
        self._rate = config.tts_voice_rate or 180
        self._volume = config.tts_volume or 1.0

        self._start_worker()

    def _start_worker(self):
        self._worker = TTSWorker(
            voice_id=self._current_voice_id,
            rate=self._rate,
            volume=self._volume,
            parent=self
        )
        self._worker.speech_started.connect(self.speaking_started.emit)
        self._worker.speech_finished.connect(self.speaking_finished.emit)
        self._worker.start()

    def speak(self, text: str):
        if self._worker and self._worker.isRunning():
            self._worker.speak(text)

    def stop(self):
        if self._worker:
            self._worker.stop_current()

    def set_rate(self, rate: int):
        self._rate = rate
        if self._worker and self._worker._engine:
            try:
                self._worker._engine.setProperty("rate", rate)
            except Exception:
                pass

    def set_voice(self, voice_id: str):
        self._current_voice_id = voice_id
        if self._worker:
            self._worker.shutdown()
            self._start_worker()

    def get_available_voices(self) -> List[Dict[str, str]]:
        voices = []
        try:
            eng = pyttsx3.init()
            for v in eng.getProperty("voices"):
                voices.append({
                    "id": v.id,
                    "name": v.name,
                    "languages": v.languages
                })
            eng.stop()
        except Exception:
            pass
        return voices

    def get_current_voice(self) -> str:
        """Returns the current voice identifier or default descriptor."""
        return self._current_voice_id or "Windows SAPI5 Default"

    def shutdown(self):
        if self._worker:
            self._worker.shutdown()
