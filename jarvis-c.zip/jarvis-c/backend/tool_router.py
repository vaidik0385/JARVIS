"""
JARVIS AI — Intelligent Tool Router & Multi-Source Information Dispatcher
Routes user queries into deterministic tool executions and live real-time contexts.
Supports:
1. Fast Direct Intent Matching (< 50ms) for desktop automation (English, Hindi, Hinglish)
2. Automated Intent Analysis & Live Context Retrieval (Weather, Crypto, Stocks, Web Search)
3. Multi-Tool Calling: Combines multiple tool results into a unified AI reasoning context
4. OpenAI/Groq Compatible JSON Schema Tool Definitions
"""

import re
from typing import Dict, Any, Optional, Tuple, List
from PySide6.QtCore import QObject, Signal

from backend.application_launcher import ApplicationLauncher
from backend.search_service import WebSearchService
from backend.crypto_service import CryptoMarketService
from backend.stock_service import StockMarketService, INDIAN_EQUITY_MAP
from backend.weather_service import WeatherService, fetch_weather_report, format_weather_context
from backend.windows_hardware import WindowsHardwareController

class ToolRouter(QObject):
    tool_executed = Signal(str, bool, str)  # tool_name, success, message

    def __init__(
        self,
        launcher: ApplicationLauncher,
        search_service: Optional[WebSearchService] = None,
        crypto_service: Optional[CryptoMarketService] = None,
        stock_service: Optional[StockMarketService] = None,
        weather_service: Optional[WeatherService] = None,
        hardware_controller: Optional[WindowsHardwareController] = None,
        parent: Optional[QObject] = None
    ):
        super().__init__(parent)
        self.launcher = launcher
        self.search_service = search_service or WebSearchService(self)
        self.crypto_service = crypto_service or CryptoMarketService(self)
        self.stock_service = stock_service or StockMarketService(self)
        self.weather_service = weather_service or WeatherService(self)
        self.hardware = hardware_controller or WindowsHardwareController(self)

    def try_direct_intent(self, text: str) -> Optional[Tuple[bool, str]]:
        """
        Fast-path matcher for direct local desktop automations, Windows hardware controls,
        application launching, default Chrome website opening, and Indian market lookups.
        Bypasses cloud latency for instant execution.
        """
        raw = text.strip()
        # Strip common assistant prefixes like "Jarvis,", "Hey Jarvis,", "Please"
        t = re.sub(r"^(?:hey\s+|hi\s+|hello\s+)?jarvis[,:\s]*", "", raw, flags=re.IGNORECASE).strip().lower()

        # -------------------------------------------------------------
        # 1. REAL WINDOWS HARDWARE: DISPLAY BRIGHTNESS CONTROL
        # -------------------------------------------------------------
        # Set exact brightness: "set brightness to 70 percent", "brightness 70%"
        b_set_match = re.search(r"(?:set\s+)?brightness\s+(?:to\s+)?(\d{1,3})\s*(?:percent|%)?", t) or re.search(r"^brightness\s+(\d{1,3})$", t)
        if b_set_match:
            try:
                val = int(b_set_match.group(1))
                return self.hardware.set_brightness(val)
            except ValueError:
                pass

        # Increase brightness: "increase brightness", "brightness badhao", "raise brightness"
        if any(w in t for w in ("increase brightness", "raise brightness", "brightness increase", "brightness badhao", "brightness up", "more brightness")):
            return self.hardware.increase_brightness(10)

        # Decrease brightness: "decrease brightness", "lower brightness", "dim brightness", "brightness kam karo"
        if any(w in t for w in ("decrease brightness", "lower brightness", "dim brightness", "brightness decrease", "brightness kam karo", "brightness down", "less brightness")):
            return self.hardware.decrease_brightness(10)

        # -------------------------------------------------------------
        # 2. REAL WINDOWS HARDWARE: MASTER AUDIO VOLUME CONTROL
        # -------------------------------------------------------------
        # Set exact volume: "set volume to 50 percent", "volume 50%"
        v_set_match = re.search(r"(?:set\s+)?volume\s+(?:to\s+)?(\d{1,3})\s*(?:percent|%)?", t) or re.search(r"^volume\s+(\d{1,3})$", t)
        if v_set_match:
            try:
                val = int(v_set_match.group(1))
                return self.hardware.set_volume(val)
            except ValueError:
                pass

        # Mute / Unmute: "mute my laptop", "mute", "unmute"
        if any(t == w or t.startswith(w + " ") for w in ("unmute", "un-mute", "unmute audio", "unmute volume", "aawaz chalu karo")):
            return self.hardware.set_mute(False)
        if any(t == w or t.startswith(w + " ") for w in ("mute", "mute my laptop", "mute audio", "mute laptop", "mute volume", "aawaz band karo", "silent")):
            return self.hardware.set_mute(True)

        # Increase volume: "increase volume", "volume badhao", "aawaz badhao"
        if any(w in t for w in ("increase volume", "raise volume", "volume increase", "volume badhao", "aawaz badhao", "volume up", "louder")):
            return self.hardware.increase_volume(10)

        # Decrease volume: "decrease volume", "lower volume", "volume decrease", "volume kam karo", "aawaz kam karo"
        if any(w in t for w in ("decrease volume", "lower volume", "volume decrease", "volume kam karo", "aawaz kam karo", "volume down", "quieter")):
            return self.hardware.decrease_volume(10)

        # -------------------------------------------------------------
        # 3. WEBSITES & SEARCHES IN DEFAULT GOOGLE CHROME
        # -------------------------------------------------------------
        # YouTube Search: "search youtube for ...", "open youtube and search for ..."
        yt_search_match = (
            re.search(r"(?:open\s+youtube\s+and\s+search\s+for|search\s+youtube\s+for|search\s+on\s+youtube\s+for)\s+(.+)", t) or
            re.search(r"(?:search|dhoondo|khojo)\s+(?:on\s+youtube|youtube\s+par|youtube\s+pe)\s+for\s+(.+)", t) or
            re.search(r"(?:search|dhoondo|khojo)\s+(.+)\s+(?:on\s+youtube|youtube\s+par|youtube\s+pe)", t) or
            re.search(r"youtube\s+(?:pe|par)\s+(.+)\s+(?:search\s+karo|chalao|dhoondo)", t)
        )
        if yt_search_match:
            query = yt_search_match.group(1).strip()
            return self.launcher.search_youtube(query)

        # Google Search: "open chrome and search for ...", "search google for ..."
        g_search_match = (
            re.search(r"(?:open\s+chrome\s+and\s+search\s+for|search\s+google\s+for|search\s+on\s+google\s+for)\s+(.+)", t) or
            re.search(r"(?:search|dhoondo|khojo)\s+(?:on\s+google|google\s+par|google\s+pe)\s+for\s+(.+)", t) or
            re.search(r"(?:search|dhoondo|khojo)\s+(.+)\s+(?:on\s+google|google\s+par|google\s+pe)", t) or
            re.search(r"google\s+(?:pe|par)\s+(.+)\s+(?:search\s+karo|dhoondo)", t)
        )
        if g_search_match:
            query = g_search_match.group(1).strip()
            return self.launcher.search_google(query)

        # -------------------------------------------------------------
        # 4. WINDOWS APPLICATIONS (VS Code, File Explorer, WhatsApp, etc.)
        # -------------------------------------------------------------
        # VS Code with optional folder: "open vs code in C:\...", "open vs code"
        vscode_folder_match = re.search(r"open\s+(?:vs\s*code|vscode|code)\s+in\s+(.+)", t)
        if vscode_folder_match:
            folder = vscode_folder_match.group(1).strip()
            return self.launcher.launch_vscode(folder_path=folder)

        if any(w in t for w in ("vs code", "vscode", "visual studio code", "code editor")):
            if any(w in t for w in ("open", "kholo", "launch", "chalao", "start")):
                return self.launcher.launch_vscode()

        # File Explorer with optional folder: "open file explorer in C:\...", "open folder C:\...", "open file explorer"
        explorer_folder_match = re.search(r"open\s+(?:file\s+explorer|folder)\s+(?:in\s+)?([a-zA-Z]:\\[^\s]+)", t)
        if explorer_folder_match:
            folder = explorer_folder_match.group(1).strip()
            return self.launcher.open_file_explorer(folder_path=folder)

        if any(w in t for w in ("file explorer", "explorer", "my computer", "files kholo", "open files")):
            return self.launcher.open_file_explorer()

        # WhatsApp Web vs WhatsApp Desktop
        if "whatsapp web" in t and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.open_web_portal("whatsapp")

        if "whatsapp" in t and any(w in t for w in ("open", "kholo", "launch", "start", "chalao")):
            return self.launcher.launch_whatsapp()

        # Notepad: "open notepad", "notepad kholo"
        if any(w in t for w in ("notepad", "note pad")) and any(w in t for w in ("open", "kholo", "launch", "chalao", "start")):
            return self.launcher.launch("notepad")

        # Calculator: "open calculator", "calc", "calculator kholo"
        if any(w in t for w in ("calculator", "calc", "hisaab")) and any(w in t for w in ("open", "kholo", "launch", "chalao", "start")):
            return self.launcher.launch("calculator")

        # Task Manager: "open task manager", "taskmgr"
        if any(w in t for w in ("task manager", "taskmanager", "taskmgr")) and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.launch("task_manager")

        # Windows Settings: "open settings", "settings kholo"
        if "settings" in t and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.launch("settings")

        # Command Prompt
        if any(w in t for w in ("command prompt", "open cmd", "terminal kholo", "cmd")):
            return self.launcher.launch("cmd")

        # Google Chrome app launch
        if any(w in t for w in ("chrome", "google chrome")) and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.launch("chrome")

        # -------------------------------------------------------------
        # 5. WEBSITES IN CHROME (Exact Portals & Arbitrary URLs)
        # -------------------------------------------------------------
        # Google Home: "open google"
        if "google" in t and any(w in t for w in ("open", "kholo", "start")) and not any(w in t for w in ("search", "dhoondo")):
            return self.launcher.open_web_portal("google")

        # YouTube Home: "open youtube"
        if "youtube" in t and any(w in t for w in ("open", "kholo", "chalao", "start", "launch")):
            return self.launcher.open_web_portal("youtube")

        # LinkedIn: "open linkedin", "open linkedin in chrome"
        if "linkedin" in t and any(w in t for w in ("open", "kholo", "chalao", "start", "launch")):
            return self.launcher.open_web_portal("linkedin")

        # GitHub: "open github"
        if "github" in t and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.open_web_portal("github")

        # Gmail: "open gmail"
        if "gmail" in t and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.open_web_portal("gmail")

        # ChatGPT: "open chatgpt"
        if "chatgpt" in t and any(w in t for w in ("open", "kholo", "launch", "start")):
            return self.launcher.open_web_portal("chatgpt")

        # Arbitrary website URL: "open website https://...", "open reddit.com", "open cricbuzz.com"
        url_match = re.search(r"open\s+(?:website\s+)?(https?://\S+|[\w\-]+(?:\.[\w\-]+)+\.(?:com|org|net|in|io|edu|gov|co|ai)(?:/\S*)?)", t)
        if url_match:
            target_url = url_match.group(1).strip()
            return self.launcher.open_custom_website(target_url)

        # -------------------------------------------------------------
        # 6. DIRECT INDIAN MARKET LOOKUPS (FAST PATH)
        # -------------------------------------------------------------
        # Crypto in INR: "what is bitcoin price in inr", "bitcoin price in inr", "crypto in inr"
        if ("inr" in t or "rupee" in t or "₹" in t or "indian" in t) and any(w in t for w in ("bitcoin", "btc", "ethereum", "eth", "solana", "sol", "crypto")):
            coins = ["bitcoin"]
            if "eth" in t or "ethereum" in t:
                coins.append("ethereum")
            if "sol" in t or "solana" in t:
                coins.append("solana")
            c_data = self.crypto_service.get_prices(coins)
            return True, self.crypto_service.format_crypto_context(c_data)

        # Indian Stock Market / Indices: "what is nifty 50 value", "nifty 50", "sensex value", "reliance share price"
        for alias in ("nifty 50", "nifty50", "nifty", "sensex", "bank nifty", "banknifty", "reliance", "tcs", "infosys", "hdfc bank", "icici bank"):
            if alias in t and any(w in t for w in ("what", "price", "value", "rate", "quote", "share", "stock", "kya", "batao", "chal raha")):
                q_data = self.stock_service.get_quote(alias)
                return True, self.stock_service.format_stock_context(q_data)

        # 7. Lock Workstation: "lock laptop", "lock workstation"
        if any(w in t for w in ("lock laptop", "lock workstation", "laptop lock karo", "screen lock karo", "pc lock karo")):
            return self.launcher.lock_workstation(prompt_confirmation=True)

        return None

    def retrieve_context_for_query(self, prompt: str) -> Optional[str]:
        """
        Determines whether the query requires live real-time information from:
        - Weather API (Open-Meteo)
        - Crypto Market API (CoinGecko)
        - Stock Market API (Yahoo Finance)
        - Real-time Web Search (DuckDuckGo / Tavily)
        Supports multi-tool combination when prompt touches multiple categories.
        """
        t = prompt.lower().strip()
        contexts: List[str] = []

        # 1. Weather Check
        if any(w in t for w in ("weather", "temperature", "mausam", "forecast")) and not any(w in t for w in ("explained", "what is weather")):
            city = "New Delhi"
            city_match = re.search(r"(?:in|of|for|pe|at)\s+([a-zA-Z\s]+)", t)
            if city_match:
                extracted = city_match.group(1).strip().rstrip("?.,")
                if extracted and extracted not in ("celsius", "fahrenheit", "today", "now", "delhi", "mumbai", "india"):
                    city = extracted.title()
                elif "delhi" in extracted:
                    city = "Delhi"
                elif "mumbai" in extracted:
                    city = "Mumbai"

            try:
                w_report = fetch_weather_report(city)
                contexts.append(format_weather_context(w_report))
            except Exception:
                pass

        # 2. Crypto Check
        crypto_keywords = ("bitcoin", "btc", "ethereum", "eth", "solana", "sol", "crypto", "cryptocurrency", "doge", "dogecoin", "xrp", "ripple")
        if any(w in t for w in crypto_keywords):
            detected_coins = []
            for c in ("bitcoin", "ethereum", "solana", "xrp", "dogecoin"):
                if c in t or (c == "bitcoin" and "btc" in t) or (c == "ethereum" and "eth" in t) or (c == "solana" and "sol" in t):
                    detected_coins.append(c)

            if not detected_coins:
                detected_coins = ["bitcoin", "ethereum", "solana"]

            try:
                c_data = self.crypto_service.get_prices(detected_coins)
                contexts.append(self.crypto_service.format_crypto_context(c_data))
            except Exception:
                pass

        # 3. Stock Check (Indian Equities, Indices & US Tech)
        detected_sym = None
        # Check Indian equities first
        for name, info in INDIAN_EQUITY_MAP.items():
            if re.search(rf"\b{name}\b", t):
                detected_sym = info[0]
                break

        if not detected_sym:
            stock_tickers = {
                "apple": "AAPL", "aapl": "AAPL",
                "microsoft": "MSFT", "msft": "MSFT",
                "google": "GOOGL", "googl": "GOOGL",
                "tesla": "TSLA", "tsla": "TSLA",
                "nvidia": "NVDA", "nvda": "NVDA",
                "amazon": "AMZN", "amzn": "AMZN",
                "meta": "META", "facebook": "META"
            }
            for name, sym in stock_tickers.items():
                if re.search(rf"\b{name}\b", t):
                    detected_sym = sym
                    break

        if detected_sym:
            try:
                s_data = self.stock_service.get_quote(detected_sym)
                contexts.append(self.stock_service.format_stock_context(s_data))
            except Exception:
                pass

        # 4. Web Search Check (Breaking news, current events, sports scores, recent facts)
        search_triggers = (
            "news today", "latest news", "breaking news", "who won",
            "cricket score", "match score", "current affairs", "what happened in",
            "latest version", "release date of", "who is the current"
        )
        if any(trig in t for trig in search_triggers) or (
            any(w in t for w in ("news", "today", "yesterday", "latest")) and
            not any(w in t for w in ("explain", "how to", "write a code", "python code", "create a function"))
        ):
            q = re.sub(r"^(?:jarvis|can you tell me|what is|search|who won)\s+", "", t).strip().rstrip("?.,")
            if len(q) > 4:
                try:
                    search_results = self.search_service.search(q, max_results=4)
                    if search_results:
                        contexts.append(self.search_service.format_search_context(search_results))
                except Exception:
                    pass

        if contexts:
            return "\n\n".join(contexts)
        return None

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Tuple[bool, str]:
        """Formal structured tool dispatcher for AI function calling."""
        tool = tool_name.lower().strip()

        if tool == "get_weather":
            city = arguments.get("location", "New Delhi")
            w = fetch_weather_report(city)
            formatted = format_weather_context(w)
            self.tool_executed.emit(tool_name, True, f"Weather for {city}")
            return True, formatted

        elif tool == "get_crypto_price":
            symbols = arguments.get("symbols", ["bitcoin", "ethereum"])
            c = self.crypto_service.get_prices(symbols)
            formatted = self.crypto_service.format_crypto_context(c)
            self.tool_executed.emit(tool_name, True, f"Crypto prices for {symbols}")
            return True, formatted

        elif tool == "get_stock_quote":
            sym = arguments.get("symbol", "AAPL")
            s = self.stock_service.get_quote(sym)
            formatted = self.stock_service.format_stock_context(s)
            self.tool_executed.emit(tool_name, True, f"Stock quote for {sym}")
            return True, formatted

        elif tool == "search_web":
            query = arguments.get("query", "")
            res = self.search_service.search(query, max_results=4)
            formatted = self.search_service.format_search_context(res)
            self.tool_executed.emit(tool_name, True, f"Web search for '{query}'")
            return True, formatted

        elif tool == "launch_application":
            app = arguments.get("app_name", "").lower()
            return self.launcher.launch(app)

        elif tool == "open_web_portal":
            portal = arguments.get("portal_name", "").lower()
            return self.launcher.open_web_portal(portal)

        elif tool == "search_google":
            query = arguments.get("query", "")
            return self.launcher.search_google(query)

        elif tool == "search_youtube":
            query = arguments.get("query", "")
            return self.launcher.search_youtube(query)

        elif tool == "lock_workstation":
            return self.launcher.lock_workstation(prompt_confirmation=True)

        msg = f"Unknown tool: '{tool_name}'"
        self.tool_executed.emit(tool_name, False, msg)
        return False, msg

    @staticmethod
    def get_tool_definitions() -> list:
        """JSON-schema definitions compatible with Groq / OpenAI tool calling."""
        return [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Fetch real-time atmospheric weather metrics, temperature, feels-like, and forecasts for any city from Open-Meteo.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "location": {"type": "string", "description": "City or location name (e.g., 'New Delhi', 'Mumbai', 'London', 'Tokyo')"}
                        },
                        "required": ["location"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "get_crypto_price",
                    "description": "Fetch authentic cryptocurrency market prices, 24-hour changes, and market caps in USD and INR from CoinGecko.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "symbols": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Cryptocurrency names or symbols (e.g. ['bitcoin', 'ethereum', 'solana', 'xrp'])"
                            }
                        },
                        "required": ["symbols"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "get_stock_quote",
                    "description": "Fetch stock market equity quotes, previous close, daily price changes, and exchange data from Yahoo Finance.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "symbol": {"type": "string", "description": "Stock ticker symbol (e.g., 'AAPL', 'MSFT', 'TSLA', 'NVDA')"}
                        },
                        "required": ["symbol"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "search_web",
                    "description": "Search the live web for recent news, sports scores, current events, and facts using DuckDuckGo.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Search query keywords"}
                        },
                        "required": ["query"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "launch_application",
                    "description": "Launch verified Windows desktop applications (Calculator, Notepad, File Explorer, Chrome, VS Code, Task Manager, WhatsApp, Settings).",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "app_name": {
                                "type": "string",
                                "enum": ["calculator", "notepad", "explorer", "chrome", "vscode", "task_manager", "settings", "cmd", "whatsapp"],
                                "description": "Identifier of the application to launch"
                            }
                        },
                        "required": ["app_name"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "lock_workstation",
                    "description": "Lock the Windows desktop session for workstation security (prompts user for confirmation).",
                    "parameters": {
                        "type": "object",
                        "properties": {}
                    }
                }
            }
        ]
