"""
JARVIS AI — Real Hardware Telemetry & System Information Service
Collects authentic laptop hardware metrics (CPU, RAM, Disk, Battery, System, Uptime)
via psutil and Windows APIs without blocking the Qt GUI thread.
"""

import os
import platform
import time
from typing import Optional
from dataclasses import dataclass
from PySide6.QtCore import QThread, Signal, QObject
import psutil

from services.frontend_interfaces import SystemMetrics

@dataclass
class ExtendedSystemMetrics(SystemMetrics):
    cpu_cores_physical: int = 4
    cpu_cores_logical: int = 8
    cpu_freq_mhz: float = 0.0
    ram_available_gb: float = 0.0
    disk_total_gb: float = 0.0
    disk_used_gb: float = 0.0
    disk_free_gb: float = 0.0
    battery_secs_left: Optional[int] = None
    os_name: str = "Windows"
    os_release: str = "11"
    computer_name: str = "JARVIS-HOST"
    processor_name: str = "Intel Core"
    uptime_str: str = "0h 0m"


class SystemMonitorWorker(QThread):
    metrics_ready = Signal(object)  # ExtendedSystemMetrics

    def __init__(self, poll_interval_ms: int = 2000, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._interval_s = poll_interval_ms / 1000.0
        self._running = True

        # Static system hardware metadata (computed once)
        self._os_name = f"{platform.system()} {platform.release()}"
        self._node_name = platform.node()
        self._proc_name = platform.processor() or "Multi-core Processor"
        self._phys_cores = psutil.cpu_count(logical=False) or 4
        self._log_cores = psutil.cpu_count(logical=True) or 8

    def run(self):
        # Prime psutil cpu measurement
        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass

        while self._running:
            try:
                metrics = self._gather_metrics()
                self.metrics_ready.emit(metrics)
            except Exception as e:
                print(f"[SystemMonitor] Error collecting telemetry: {e}")

            # Responsive sleep in small slices
            step = 0.2
            elapsed = 0.0
            while self._running and elapsed < self._interval_s:
                self.msleep(int(step * 1000))
                elapsed += step

    def stop(self):
        self._running = False
        self.wait(1000)

    def _gather_metrics(self) -> ExtendedSystemMetrics:
        # CPU
        cpu_pct = psutil.cpu_percent(interval=None)
        freq_info = psutil.cpu_freq()
        cpu_freq = freq_info.current if freq_info else 0.0

        # Memory
        vm = psutil.virtual_memory()
        ram_pct = vm.percent
        ram_used = round(vm.used / (1024 ** 3), 1)
        ram_total = round(vm.total / (1024 ** 3), 1)
        ram_avail = round(vm.available / (1024 ** 3), 1)

        # Storage (Drive C:)
        drive_path = os.path.splitdrive(os.getcwd())[0] or "C:"
        if not drive_path.endswith("\\"):
            drive_path += "\\"
        try:
            disk = psutil.disk_usage(drive_path)
            disk_pct = disk.percent
            disk_total = round(disk.total / (1024 ** 3), 1)
            disk_used = round(disk.used / (1024 ** 3), 1)
            disk_free = round(disk.free / (1024 ** 3), 1)
        except Exception:
            disk_pct = 50.0
            disk_total = 500.0
            disk_used = 250.0
            disk_free = 250.0

        # Battery
        battery_pct = 100
        is_charging = True
        health = "AC Powered"
        secs_left = None
        try:
            battery = psutil.sensors_battery()
            if battery is not None:
                battery_pct = int(battery.percent)
                is_charging = bool(battery.power_plugged)
                secs_left = battery.secsleft if battery.secsleft != psutil.POWER_TIME_UNLIMITED else None
                health = "Charging" if is_charging else "Discharging"
            else:
                health = "Desktop AC"
        except Exception:
            pass

        # Uptime
        boot_ts = psutil.boot_time()
        uptime_secs = int(time.time() - boot_ts)
        hours = uptime_secs // 3600
        mins = (uptime_secs % 3600) // 60
        uptime_str = f"{hours}h {mins}m"

        return ExtendedSystemMetrics(
            cpu_percent=cpu_pct,
            ram_percent=ram_pct,
            ram_used_gb=ram_used,
            ram_total_gb=ram_total,
            disk_percent=disk_pct,
            battery_percent=battery_pct,
            is_charging=is_charging,
            battery_health=health,
            cpu_cores_physical=self._phys_cores,
            cpu_cores_logical=self._log_cores,
            cpu_freq_mhz=cpu_freq,
            ram_available_gb=ram_avail,
            disk_total_gb=disk_total,
            disk_used_gb=disk_used,
            disk_free_gb=disk_free,
            battery_secs_left=secs_left,
            os_name=self._os_name,
            os_release=platform.release(),
            computer_name=self._node_name,
            processor_name=self._proc_name,
            uptime_str=uptime_str
        )

    # Backward compatibility alias
    _collect_metrics = _gather_metrics
