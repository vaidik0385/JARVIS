"""
JARVIS AI — SQLite Conversation Database
Manages persistent conversation sessions, messages, timestamps, and full-text search.
Thread-safe, uses WAL mode for high performance.
"""

import sqlite3
import uuid
import json
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Dict, Any

from services.frontend_interfaces import ChatMessage, ConversationMeta

BASE_DIR = Path(__file__).resolve().parent.parent
DB_DIR = BASE_DIR / "data"
DB_PATH = DB_DIR / "jarvis.db"

class Database:
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=10.0)
        conn.row_factory = sqlite3.Row
        # Performance PRAGMAs
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    metadata TEXT,
                    FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id);
                CREATE INDEX IF NOT EXISTS idx_conv_updated ON conversations(updated_at DESC);
            """)

            # Seed welcome sample conversation if database is newly initialized
            cur = conn.execute("SELECT COUNT(*) as cnt FROM conversations")
            if cur.fetchone()["cnt"] == 0:
                self._seed_default_conversations(conn)

    def _seed_default_conversations(self, conn: sqlite3.Connection):
        now_iso = datetime.now().isoformat()
        now_ts = datetime.now().strftime("%I:%M %p")
        cid = str(uuid.uuid4())[:8]

        conn.execute(
            "INSERT INTO conversations (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (cid, "Welcome to JARVIS AI", now_iso, now_iso)
        )
        msg_id = str(uuid.uuid4())[:8]
        welcome_text = (
            "**Welcome to JARVIS AI Desktop Assistant.**\n\n"
            "I am your intelligent personal desktop companion powered by Groq and Windows system telemetry. "
            "I can assist you with system monitoring, application automation, voice dictation, and technical reasoning.\n\n"
            "```python\n# JARVIS AI System Initialized\nstatus = jarvis.diagnostics.run_self_check()\nprint(f'System Status: {status.state}')\n```\n\n"
            "How may I assist you today, Sir?"
        )
        conn.execute(
            "INSERT INTO messages (id, conversation_id, role, content, timestamp, metadata) VALUES (?, ?, ?, ?, ?, ?)",
            (msg_id, cid, "assistant", welcome_text, now_ts, json.dumps({"source": "system_init"}))
        )

    def get_all_conversations(self) -> List[ConversationMeta]:
        with self._get_connection() as conn:
            query = """
                SELECT c.id, c.title, c.created_at, c.updated_at, COUNT(m.id) as msg_count
                FROM conversations c
                LEFT JOIN messages m ON c.id = m.conversation_id
                GROUP BY c.id
                ORDER BY c.updated_at DESC
            """
            rows = conn.execute(query).fetchall()
            return [
                ConversationMeta(
                    id=row["id"],
                    title=row["title"],
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                    message_count=row["msg_count"]
                )
                for row in rows
            ]

    def create_conversation(self, title: str = "New Chat") -> str:
        cid = str(uuid.uuid4())[:8]
        now = datetime.now().isoformat()
        with self._get_connection() as conn:
            conn.execute(
                "INSERT INTO conversations (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
                (cid, title, now, now)
            )
        return cid

    def get_conversation_messages(self, cid: str) -> List[ChatMessage]:
        with self._get_connection() as conn:
            rows = conn.execute(
                "SELECT id, role, content, timestamp, metadata FROM messages WHERE conversation_id = ? ORDER BY rowid ASC",
                (cid,)
            ).fetchall()

            messages = []
            for r in rows:
                meta = {}
                if r["metadata"]:
                    try:
                        meta = json.loads(r["metadata"])
                    except Exception:
                        pass
                messages.append(ChatMessage(
                    id=r["id"],
                    role=r["role"],
                    content=r["content"],
                    timestamp=r["timestamp"],
                    metadata=meta
                ))
            return messages

    def add_message(self, cid: str, role: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> ChatMessage:
        msg_id = str(uuid.uuid4())[:8]
        now_ts = datetime.now().strftime("%I:%M %p")
        now_iso = datetime.now().isoformat()
        meta_str = json.dumps(metadata or {})

        with self._get_connection() as conn:
            # Ensure conversation exists
            conv = conn.execute("SELECT title FROM conversations WHERE id = ?", (cid,)).fetchone()
            if not conv:
                conn.execute(
                    "INSERT INTO conversations (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
                    (cid, "New Chat", now_iso, now_iso)
                )
                title = "New Chat"
            else:
                title = conv["title"]

            # Insert message
            conn.execute(
                "INSERT INTO messages (id, conversation_id, role, content, timestamp, metadata) VALUES (?, ?, ?, ?, ?, ?)",
                (msg_id, cid, role, content, now_ts, meta_str)
            )

            # Auto-title conversation on first user prompt if still default
            if role == "user" and title in ("New Chat", "New Conversation", "Untitled Conversation"):
                snippet = content.strip().split("\n")[0][:28]
                new_title = snippet + ("..." if len(content.strip().split("\n")[0]) > 28 else "")
                conn.execute(
                    "UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?",
                    (new_title, now_iso, cid)
                )
            else:
                conn.execute(
                    "UPDATE conversations SET updated_at = ? WHERE id = ?",
                    (now_iso, cid)
                )

        return ChatMessage(id=msg_id, role=role, content=content, timestamp=now_ts, metadata=metadata)

    def update_title(self, cid: str, new_title: str):
        now_iso = datetime.now().isoformat()
        with self._get_connection() as conn:
            conn.execute(
                "UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?",
                (new_title, now_iso, cid)
            )

    def delete_conversation(self, cid: str) -> bool:
        with self._get_connection() as conn:
            cur = conn.execute("DELETE FROM conversations WHERE id = ?", (cid,))
            return cur.rowcount > 0

    def clear_messages(self, cid: str):
        now_iso = datetime.now().isoformat()
        with self._get_connection() as conn:
            conn.execute("DELETE FROM messages WHERE conversation_id = ?", (cid,))
            conn.execute("UPDATE conversations SET updated_at = ? WHERE id = ?", (now_iso, cid))

    def search_conversations(self, query: str) -> List[ConversationMeta]:
        query_pattern = f"%{query.strip().lower()}%"
        with self._get_connection() as conn:
            sql = """
                SELECT DISTINCT c.id, c.title, c.created_at, c.updated_at,
                       (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id) as msg_count
                FROM conversations c
                LEFT JOIN messages m ON c.id = m.conversation_id
                WHERE LOWER(c.title) LIKE ? OR LOWER(m.content) LIKE ?
                ORDER BY c.updated_at DESC
            """
            rows = conn.execute(sql, (query_pattern, query_pattern)).fetchall()
            return [
                ConversationMeta(
                    id=row["id"],
                    title=row["title"],
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                    message_count=row["msg_count"]
                )
                for row in rows
            ]

# Global singleton instance
db = Database()
