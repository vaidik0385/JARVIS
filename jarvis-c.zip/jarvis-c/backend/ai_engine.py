"""
JARVIS AI — Conversational Reasoning Engine
Asynchronous Qt Worker orchestrating multi-turn context assembly,
system prompt configuration (English / Hindi / Hinglish matching),
live real-time tool grounding (Web Search, Weather, Crypto, Stocks),
Groq streaming response delivery, and real-time interruption.
"""

import json
from typing import List, Dict, Optional, Any
from PySide6.QtCore import QThread, Signal, QObject

from backend.ai_provider import GroqProvider
from backend.config import config
from services.frontend_interfaces import ChatMessage

SYSTEM_PROMPT = """You are JARVIS AI, an advanced, highly intelligent Windows desktop personal assistant.
Your capabilities:
1. Natural language reasoning, computer science and programming, mathematics, science, education, finance, and system diagnostics.
2. Multilingual fluency in English, Hindi (हिंदी), and Hinglish (mixed Hindi-English in Latin script).
3. Always automatically match the language and conversational register of the user:
   - If user asks in Hindi (e.g., "कंप्यूटर का क्या हाल है?"), respond in natural Hindi.
   - If user asks in Hinglish (e.g., "Bhai weather kaisa hai aur bitcoin ka kya rate hai?"), respond in clean, natural Hinglish.
   - If user asks in English, respond in articulate, modern English.
4. Keep answers concise, direct, helpful, and technically accurate.
5. Format code blocks using standard markdown with the exact programming language identifier (e.g., ```python, ```bash, ```javascript).
6. When live telemetry, weather, crypto, or web search data is provided in context, cite the verified real-time numbers accurately.
7. Be polite, confident, and professional, addressing the user respectfully (e.g. 'Sir' or by name if provided).
"""

class ChatStreamWorker(QThread):
    chunk_received = Signal(str)
    stream_finished = Signal(str)  # full response
    stream_error = Signal(str)
    tool_requested = Signal(str, dict)  # tool_name, args

    def __init__(
        self,
        provider: GroqProvider,
        prompt: str,
        conversation_history: List[ChatMessage],
        system_context: str = "",
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_router: Optional[Any] = None,
        parent: Optional[QObject] = None
    ):
        super().__init__(parent)
        self.provider = provider
        self.prompt = prompt
        self.history = conversation_history
        self.system_context = system_context
        self.tools = tools
        self.tool_router = tool_router
        self._is_stopped = False

    def stop(self):
        self._is_stopped = True

    def run(self):
        try:
            # 1. Assemble messages payload
            messages: List[Dict[str, Any]] = [{"role": "system", "content": SYSTEM_PROMPT}]

            # 2. Hardware telemetry context
            if self.system_context:
                messages.append({
                    "role": "system",
                    "content": f"[Live Telemetry & Diagnostics Context]\n{self.system_context}"
                })

            # 3. Dynamic Tool Grounding (Weather, Crypto, Stocks, Web Search)
            if self.tool_router:
                try:
                    tool_context = self.tool_router.retrieve_context_for_query(self.prompt)
                    if tool_context:
                        messages.append({
                            "role": "system",
                            "content": (
                                f"[Verified Live Data Context]\n{tool_context}\n\n"
                                "Instructions: Incorporate the verified real-time numbers, sources, and citations "
                                "into your answer accurately. Clearly distinguish verified data from general explanations."
                            )
                        })
                except Exception:
                    pass

            # 4. Append historical context (last 12 turns)
            recent_turns = self.history[-12:] if len(self.history) > 12 else self.history
            for msg in recent_turns:
                if msg.role in ("user", "assistant") and msg.content:
                    messages.append({"role": msg.role, "content": msg.content})

            # 5. Append current user prompt
            messages.append({"role": "user", "content": self.prompt})

            # 6. Stream completion from Groq Cloud
            full_content = []
            pending_tool_calls: Dict[int, Dict[str, Any]] = {}

            stream_gen = self.provider.stream_chat(
                messages=messages,
                tools=self.tools,
                temperature=0.5
            )

            for item in stream_gen:
                if self._is_stopped:
                    break

                item_type = item.get("type")
                if item_type == "content":
                    token = item.get("delta", "")
                    full_content.append(token)
                    self.chunk_received.emit(token)

                elif item_type == "tool_delta":
                    tc = item.get("tool_call")
                    if tc:
                        idx = getattr(tc, "index", 0)
                        if idx not in pending_tool_calls:
                            pending_tool_calls[idx] = {
                                "id": getattr(tc, "id", f"call_{idx}"),
                                "name": "",
                                "arguments": ""
                            }
                        fn = getattr(tc, "function", None)
                        if fn:
                            if hasattr(fn, "name") and fn.name:
                                pending_tool_calls[idx]["name"] = fn.name
                            if hasattr(fn, "arguments") and fn.arguments:
                                pending_tool_calls[idx]["arguments"] += fn.arguments

            # 7. Execute structured tool calls if emitted by the model
            if pending_tool_calls and self.tool_router and not self._is_stopped:
                for idx, tcall in pending_tool_calls.items():
                    tname = tcall["name"]
                    raw_args = tcall["arguments"]
                    try:
                        args = json.loads(raw_args) if raw_args else {}
                    except Exception:
                        args = {}

                    success, tool_output = self.tool_router.execute_tool(tname, args)

                    # Append tool response and request continuation
                    messages.append({
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [{
                            "id": tcall["id"],
                            "type": "function",
                            "function": {"name": tname, "arguments": raw_args}
                        }]
                    })
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tcall["id"],
                        "name": tname,
                        "content": tool_output
                    })

                # Stream the final synthesized answer after tool executions
                follow_up_gen = self.provider.stream_chat(
                    messages=messages,
                    temperature=0.5
                )
                for item in follow_up_gen:
                    if self._is_stopped:
                        break
                    if item.get("type") == "content":
                        token = item.get("delta", "")
                        full_content.append(token)
                        self.chunk_received.emit(token)

            complete_text = "".join(full_content)
            self.stream_finished.emit(complete_text)

        except Exception as e:
            sanitized = self.provider._sanitize_error(e)
            self.stream_error.emit(sanitized)


class AIEngine(QObject):
    chunk_received = Signal(str)
    response_completed = Signal(str)
    error_occurred = Signal(str)
    thinking_started = Signal()
    thinking_finished = Signal()

    def __init__(self, tool_router: Optional[Any] = None, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.provider = GroqProvider()
        self.tool_router = tool_router
        self._active_worker: Optional[ChatStreamWorker] = None
        self._last_prompt: str = ""
        self._last_history: List[ChatMessage] = []
        self._last_sys_context: str = ""

    def set_tool_router(self, router: Any):
        self.tool_router = router

    def send_prompt(
        self,
        prompt: str,
        conversation_history: List[ChatMessage],
        system_context: str = "",
        tools: Optional[List[Dict[str, Any]]] = None
    ):
        """Dispatches an asynchronous streaming AI query."""
        self.stop_generation()

        self._last_prompt = prompt
        self._last_history = conversation_history
        self._last_sys_context = system_context

        self.thinking_started.emit()
        self._active_worker = ChatStreamWorker(
            provider=self.provider,
            prompt=prompt,
            conversation_history=conversation_history,
            system_context=system_context,
            tools=tools,
            tool_router=self.tool_router,
            parent=self
        )
        self._active_worker.chunk_received.connect(self.chunk_received.emit)
        self._active_worker.stream_finished.connect(self._on_finished)
        self._active_worker.stream_error.connect(self._on_error)
        self._active_worker.start()

    def stop_generation(self):
        """Interrupts and terminates current AI generation."""
        if self._active_worker and self._active_worker.isRunning():
            self._active_worker.stop()
            self._active_worker.wait(400)
            self._active_worker = None
        self.thinking_finished.emit()

    def retry_last(self):
        """Re-dispatches the last user prompt."""
        if self._last_prompt:
            self.send_prompt(
                self._last_prompt,
                self._last_history,
                self._last_sys_context
            )

    def _on_finished(self, text: str):
        self.thinking_finished.emit()
        self.response_completed.emit(text)

    def _on_error(self, err: str):
        self.thinking_finished.emit()
        self.error_occurred.emit(err)
