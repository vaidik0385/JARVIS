"""
JARVIS AI — Real-Time Web Search Service
Provides authentic live web information, news, and factual search queries.
Utilizes DuckDuckGo (ddgs) as a zero-cost, high-reliability primary provider
with optional support for Tavily API if configured in .env.
Includes in-memory TTL caching and citation extraction.
"""

import time
from typing import List, Dict, Optional, Any
from PySide6.QtCore import QObject, Signal, QThread
from ddgs import DDGS
import httpx

from backend.config import config

class SearchResult:
    def __init__(self, title: str, snippet: str, url: str, source: str = "Web"):
        self.title = title
        self.snippet = snippet
        self.url = url
        self.source = source

    def to_dict(self) -> Dict[str, str]:
        return {
            "title": self.title,
            "snippet": self.snippet,
            "url": self.url,
            "source": self.source
        }

class WebSearchService(QObject):
    search_completed = Signal(str, list)   # query, list of SearchResult
    search_error = Signal(str, str)        # query, error message

    def __init__(self, parent: Optional[QObject] = None, cache_ttl_seconds: int = 300):
        super().__init__(parent)
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._cache_ttl = cache_ttl_seconds

    def search(self, query: str, max_results: int = 5) -> List[Dict[str, str]]:
        """
        Synchronous search query returning structured citations.
        Checks in-memory cache first to eliminate duplicate requests.
        """
        q = query.strip()
        if not q:
            return []

        # Check cache
        cache_key = q.lower()
        now = time.time()
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if now - entry["timestamp"] < self._cache_ttl:
                return entry["results"]

        results: List[Dict[str, str]] = []

        # 1. Try Tavily API if key configured
        if config.tavily_api_key:
            try:
                tav_res = self._search_tavily(q, max_results)
                if tav_res:
                    self._cache[cache_key] = {"results": tav_res, "timestamp": now}
                    self.search_completed.emit(q, tav_res)
                    return tav_res
            except Exception:
                pass

        # 2. Primary Zero-Cost Provider: DuckDuckGo (ddgs)
        try:
            with DDGS(timeout=8) as ddgs_client:
                raw_results = list(ddgs_client.text(q, max_results=max_results))
                for item in raw_results:
                    title = item.get("title", "").strip()
                    snippet = item.get("body", "").strip()
                    url = item.get("href", "").strip()
                    if title and url:
                        results.append({
                            "title": title,
                            "snippet": snippet,
                            "url": url,
                            "source": "DuckDuckGo"
                        })

                if results:
                    self._cache[cache_key] = {"results": results, "timestamp": now}
                    self.search_completed.emit(q, results)
                    return results

        except Exception as e:
            err_msg = f"Web search failed: {e}"
            self.search_error.emit(q, err_msg)

        return results

    def _search_tavily(self, query: str, max_results: int) -> List[Dict[str, str]]:
        url = "https://api.tavily.com/search"
        payload = {
            "api_key": config.tavily_api_key,
            "query": query,
            "max_results": max_results,
            "search_depth": "basic"
        }
        with httpx.Client(timeout=8.0) as client:
            resp = client.post(url, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                results = []
                for item in data.get("results", []):
                    results.append({
                        "title": item.get("title", ""),
                        "snippet": item.get("content", ""),
                        "url": item.get("url", ""),
                        "source": "Tavily"
                    })
                return results
        return []

    def format_search_context(self, results: List[Dict[str, str]]) -> str:
        """Formats search citations for LLM reasoning prompt."""
        if not results:
            return "No web search results available."

        lines = ["[Live Web Search Results & Verified Citations]"]
        for idx, r in enumerate(results, start=1):
            lines.append(f"[{idx}] {r['title']}")
            lines.append(f"    Source: {r['url']}")
            lines.append(f"    Snippet: {r['snippet']}")
        return "\n".join(lines)


class SearchWorker(QThread):
    results_ready = Signal(list)
    search_failed = Signal(str)

    def __init__(self, search_service: WebSearchService, query: str, max_results: int = 5, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.service = search_service
        self.query = query
        self.max_results = max_results

    def run(self):
        try:
            res = self.service.search(self.query, self.max_results)
            self.results_ready.emit(res)
        except Exception as e:
            self.search_failed.emit(str(e))
