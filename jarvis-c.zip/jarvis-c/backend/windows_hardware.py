"""
JARVIS AI — Real Windows Hardware Controller
Provides direct control over physical Windows subsystems:
1. Display Brightness Control (via screen_brightness_control & WMI fallback)
2. Master Audio Volume Control & Output Device Detection (via Pycaw & Core Audio COM)
All operations interface directly with genuine Windows OS APIs.
"""

import sys
from typing import Tuple, Optional, Dict, Any
from PySide6.QtCore import QObject, Signal

class WindowsHardwareController(QObject):
    volume_changed = Signal(int, bool)        # volume_percent (0-100), is_muted
    brightness_changed = Signal(int)          # brightness_percent (0-100)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._sbc_available = False
        self._pycaw_available = False
        self._check_availability()

    def _check_availability(self):
        try:
            import screen_brightness_control as sbc
            self._sbc_available = True
        except ImportError:
            self._sbc_available = False

        try:
            from pycaw.pycaw import AudioUtilities
            self._pycaw_available = True
        except ImportError:
            self._pycaw_available = False

    # -------------------------------------------------------------
    # REAL WINDOWS DISPLAY BRIGHTNESS CONTROL
    # -------------------------------------------------------------

    def get_brightness(self) -> Tuple[bool, int, str]:
        """
        Reads genuine physical display brightness percentage.
        Returns: (success, brightness_percent, status_message)
        """
        try:
            import screen_brightness_control as sbc
            val = sbc.get_brightness()
            if isinstance(val, list) and len(val) > 0:
                current = int(val[0])
                return True, current, f"Current display brightness is {current}%."
            elif isinstance(val, (int, float)):
                current = int(val)
                return True, current, f"Current display brightness is {current}%."
        except Exception as e:
            pass

        # WMI Fallback for Windows laptops
        try:
            import wmi
            w = wmi.WMI(namespace='wmi')
            monitors = w.WmiMonitorBrightness()
            if monitors and len(monitors) > 0:
                current = int(monitors[0].CurrentBrightness)
                return True, current, f"Current display brightness is {current}%."
        except Exception:
            pass

        return False, 50, "Hardware display brightness control is not supported on this monitor or display driver."

    def set_brightness(self, percent: int) -> Tuple[bool, str]:
        """
        Sets physical display brightness to exact percentage (0-100).
        """
        target = max(0, min(100, int(percent)))
        try:
            import screen_brightness_control as sbc
            sbc.set_brightness(target)
            self.brightness_changed.emit(target)
            return True, f"Display brightness set to {target}%."
        except Exception as e:
            pass

        # WMI Fallback
        try:
            import wmi
            w = wmi.WMI(namespace='wmi')
            methods = w.WmiMonitorBrightnessMethods()
            if methods and len(methods) > 0:
                methods[0].WmiSetBrightness(target, 0)
                self.brightness_changed.emit(target)
                return True, f"Display brightness set to {target}%."
        except Exception as e:
            return False, f"Could not set display brightness: {e}"

        return False, "Hardware display brightness control is not supported on this display."

    def increase_brightness(self, delta: int = 10) -> Tuple[bool, str]:
        """Increases display brightness by delta percentage points."""
        ok, current, msg = self.get_brightness()
        if not ok:
            return False, msg
        new_val = min(100, current + delta)
        return self.set_brightness(new_val)

    def decrease_brightness(self, delta: int = 10) -> Tuple[bool, str]:
        """Decreases display brightness by delta percentage points."""
        ok, current, msg = self.get_brightness()
        if not ok:
            return False, msg
        new_val = max(0, current - delta)
        return self.set_brightness(new_val)

    # -------------------------------------------------------------
    # REAL WINDOWS MASTER AUDIO VOLUME CONTROL
    # -------------------------------------------------------------

    def _get_audio_endpoint(self):
        """Helper to get pycaw speaker endpoint volume with proper COM initialization."""
        import comtypes
        comtypes.CoInitialize()
        from pycaw.pycaw import AudioUtilities
        speakers = AudioUtilities.GetSpeakers()
        if not speakers:
            raise RuntimeError("No active audio output device detected.")
        volume = speakers.EndpointVolume
        return speakers, volume

    def get_volume(self) -> Tuple[bool, int, bool, str]:
        """
        Reads actual Windows master audio volume.
        Returns: (success, volume_percent, is_muted, device_name)
        """
        try:
            speakers, volume = self._get_audio_endpoint()
            scalar = float(volume.GetMasterVolumeLevelScalar())
            percent = int(round(scalar * 100))
            is_muted = bool(volume.GetMute())
            device_name = getattr(speakers, 'FriendlyName', 'Default Audio Device')
            return True, percent, is_muted, device_name
        except Exception as e:
            return False, 50, False, f"Audio error: {e}"
        finally:
            try:
                import comtypes
                comtypes.CoUninitialize()
            except Exception:
                pass

    def set_volume(self, percent: int) -> Tuple[bool, str]:
        """
        Sets master audio output volume to exact percentage (0-100).
        """
        target = max(0, min(100, int(percent)))
        scalar = target / 100.0
        try:
            speakers, volume = self._get_audio_endpoint()
            volume.SetMasterVolumeLevelScalar(scalar, None)
            is_muted = bool(volume.GetMute())
            self.volume_changed.emit(target, is_muted)
            return True, f"Windows system volume set to {target}%."
        except Exception as e:
            return False, f"Could not adjust master volume: {e}"
        finally:
            try:
                import comtypes
                comtypes.CoUninitialize()
            except Exception:
                pass

    def increase_volume(self, delta: int = 10) -> Tuple[bool, str]:
        """Increases master audio volume by delta percent."""
        ok, current, is_muted, _ = self.get_volume()
        if not ok:
            return False, "Could not determine current volume."
        new_val = min(100, current + delta)
        # Automatically unmute if increasing volume
        if is_muted:
            self.set_mute(False)
        return self.set_volume(new_val)

    def decrease_volume(self, delta: int = 10) -> Tuple[bool, str]:
        """Decreases master audio volume by delta percent."""
        ok, current, is_muted, _ = self.get_volume()
        if not ok:
            return False, "Could not determine current volume."
        new_val = max(0, current - delta)
        return self.set_volume(new_val)

    def set_mute(self, mute: bool) -> Tuple[bool, str]:
        """Mutes or unmutes the Windows master audio output."""
        try:
            speakers, volume = self._get_audio_endpoint()
            volume.SetMute(1 if mute else 0, None)
            scalar = float(volume.GetMasterVolumeLevelScalar())
            percent = int(round(scalar * 100))
            self.volume_changed.emit(percent, mute)
            status_text = "muted" if mute else "unmuted"
            return True, f"Windows audio has been {status_text}."
        except Exception as e:
            return False, f"Could not toggle mute state: {e}"
        finally:
            try:
                import comtypes
                comtypes.CoUninitialize()
            except Exception:
                pass

    def toggle_mute(self) -> Tuple[bool, str]:
        """Toggles mute state."""
        ok, _, is_muted, _ = self.get_volume()
        if not ok:
            return False, "Could not determine audio status."
        return self.set_mute(not is_muted)
