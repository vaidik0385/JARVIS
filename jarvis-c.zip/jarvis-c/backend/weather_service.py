"""
JARVIS AI — Real Weather & Atmospheric Telemetry Service (Open-Meteo)
Provides authentic live weather metrics, feels-like temperatures, hourly & daily
forecasts, sunrise/sunset, and rain probabilities without requiring paid API keys.
Uses Open-Meteo Forecast and Geocoding APIs with WMO weather code mapping.
"""

import json
import urllib.parse
import datetime
from typing import Optional, Tuple, Dict, Any
import httpx
from PySide6.QtCore import QObject, Signal, QThread

from backend.config import config
from services.frontend_interfaces import WeatherData

# WMO Weather interpretation codes (WW)
WMO_CODE_MAP = {
    0: ("Clear Sky", "weather"),
    1: ("Mainly Clear", "weather"),
    2: ("Partly Cloudy", "weather"),
    3: ("Overcast", "weather"),
    45: ("Foggy", "weather"),
    48: ("Depositing Rime Fog", "weather"),
    51: ("Light Drizzle", "weather"),
    53: ("Moderate Drizzle", "weather"),
    55: ("Dense Drizzle", "weather"),
    61: ("Slight Rain", "weather"),
    63: ("Moderate Rain", "weather"),
    65: ("Heavy Rain", "weather"),
    71: ("Slight Snow", "weather"),
    73: ("Moderate Snow", "weather"),
    75: ("Heavy Snow", "weather"),
    80: ("Rain Showers", "weather"),
    81: ("Heavy Rain Showers", "weather"),
    82: ("Violent Rain Showers", "weather"),
    95: ("Thunderstorm", "weather"),
    96: ("Thunderstorm with Hail", "weather"),
}

def geocode_city(city_name: str) -> Tuple[Optional[float], Optional[float], str]:
    """Resolves a human city name to latitude, longitude, and formatted country label."""
    encoded = urllib.parse.quote(city_name.strip())
    url = f"https://geocoding-api.open-meteo.com/v1/search?name={encoded}&count=1&language=en&format=json"
    headers = {"User-Agent": "JARVIS-AI-Assistant/2.4"}
    try:
        with httpx.Client(timeout=8.0) as client:
            resp = client.get(url, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                results = data.get("results", [])
                if results:
                    item = results[0]
                    name = item.get("name", city_name)
                    country = item.get("country", "")
                    full_label = f"{name}, {country}" if country else name
                    return float(item["latitude"]), float(item["longitude"]), full_label
    except Exception:
        pass
    return None, None, city_name


def fetch_weather_report(city_name: str = "New Delhi") -> Dict[str, Any]:
    """
    Synchronously fetches full weather metrics from Open-Meteo via httpx.
    Includes feels-like, humidity, wind, rain probability, sunrise/sunset, and daily forecast.
    """
    lat, lon, resolved_name = geocode_city(city_name)
    if lat is None or lon is None:
        return {"error": f"Could not find coordinates for city: '{city_name}'", "location": city_name}

    url = (
        f"https://api.open-meteo.com/v1/forecast?"
        f"latitude={lat}&longitude={lon}&"
        f"current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,weather_code,wind_speed_10m&"
        f"daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max&"
        f"timezone=auto"
    )

    try:
        headers = {"User-Agent": "JARVIS-AI-Assistant/2.4"}
        with httpx.Client(timeout=8.0) as client:
            resp = client.get(url, headers=headers)
            if resp.status_code != 200:
                return {"error": f"Weather API error (HTTP {resp.status_code})", "location": resolved_name}
            data = resp.json()

        current = data.get("current", {})
        daily = data.get("daily", {})

        temp = float(current.get("temperature_2m", 0.0))
        feels_like = float(current.get("apparent_temperature", temp))
        humidity = int(current.get("relative_humidity_2m", 0))
        wind = float(current.get("wind_speed_10m", 0.0))
        rain_prob = int(current.get("precipitation_probability", 0))
        wmo_code = int(current.get("weather_code", 0))

        cond_desc, icon_name = WMO_CODE_MAP.get(wmo_code, ("Clear", "weather"))

        # Daily metrics
        daily_max = daily.get("temperature_2m_max", [temp])[0] if daily.get("temperature_2m_max") else temp
        daily_min = daily.get("temperature_2m_min", [temp])[0] if daily.get("temperature_2m_min") else temp
        sunrise = daily.get("sunrise", ["N/A"])[0].split("T")[-1] if daily.get("sunrise") else "N/A"
        sunset = daily.get("sunset", ["N/A"])[0].split("T")[-1] if daily.get("sunset") else "N/A"

        return {
            "location": resolved_name,
            "temperature_c": round(temp, 1),
            "feels_like_c": round(feels_like, 1),
            "condition": cond_desc,
            "humidity_percent": humidity,
            "wind_speed_kmh": round(wind, 1),
            "rain_probability": rain_prob,
            "daily_max_c": round(daily_max, 1),
            "daily_min_c": round(daily_min, 1),
            "sunrise": sunrise,
            "sunset": sunset,
            "icon_name": icon_name,
            "source": "Open-Meteo",
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    except Exception as e:
        return {"error": f"Weather service network error: {e}", "location": resolved_name}


def format_weather_context(weather: Dict[str, Any]) -> str:
    """Formats weather report for AI reasoning context."""
    if "error" in weather:
        return weather["error"]

    return (
        f"[Verified Real-time Weather — Source: Open-Meteo ({weather['timestamp']})]\n"
        f"- Location: {weather['location']}\n"
        f"- Current Temperature: {weather['temperature_c']}°C (Feels like: {weather['feels_like_c']}°C)\n"
        f"- Condition: {weather['condition']}\n"
        f"- Relative Humidity: {weather['humidity_percent']}%\n"
        f"- Wind Speed: {weather['wind_speed_kmh']} km/h\n"
        f"- Rain Probability: {weather['rain_probability']}%\n"
        f"- Today's Forecast: High {weather['daily_max_c']}°C / Low {weather['daily_min_c']}°C\n"
        f"- Sun Schedule: Sunrise at {weather['sunrise']}, Sunset at {weather['sunset']}"
    )


class WeatherWorker(QThread):
    weather_ready = Signal(object)  # WeatherData
    weather_failed = Signal(str)

    def __init__(self, location: Optional[str] = None, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.location = location or config.weather_location or "New Delhi"

    def run(self):
        try:
            report = fetch_weather_report(self.location)
            if "error" in report:
                self.weather_failed.emit(report["error"])
                return

            weather_data = WeatherData(
                location=report["location"],
                temperature_c=report["temperature_c"],
                condition=report["condition"],
                humidity_percent=report["humidity_percent"],
                wind_speed_kmh=report["wind_speed_kmh"],
                icon_name=report["icon_name"],
                is_connected=True,
                source="Open-Meteo"
            )
            self.weather_ready.emit(weather_data)

        except Exception as e:
            self.weather_failed.emit(f"Weather query failed: {e}")


class WeatherService(QObject):
    weather_updated = Signal(object)
    weather_error = Signal(str)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._worker: Optional[WeatherWorker] = None
        self.cached_weather: Optional[WeatherData] = None

    def refresh(self, location: Optional[str] = None):
        if self._worker and self._worker.isRunning():
            return
        loc = location or config.weather_location or "New Delhi"
        self._worker = WeatherWorker(location=loc, parent=self)
        self._worker.weather_ready.connect(self._on_success)
        self._worker.weather_failed.connect(self._on_fail)
        self._worker.start()

    def get_weather_sync(self, city: str = "New Delhi") -> Dict[str, Any]:
        """Synchronously queries weather for tool router."""
        return fetch_weather_report(city)

    def stop(self):
        """Stops active background weather worker cleanly."""
        if self._worker and self._worker.isRunning():
            self._worker.quit()
            self._worker.wait(500)

    def _on_success(self, data: WeatherData):
        self.cached_weather = data
        self.weather_updated.emit(data)

    def _on_fail(self, err: str):
        self.weather_error.emit(err)
