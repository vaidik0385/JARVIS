# JARVIS AI — Advanced Desktop Assistant (Integrated Frontend & Backend)

**JARVIS AI** is an enterprise-grade, production-quality Windows desktop AI assistant engineered with **Python 3.14**, **PySide6 (Qt 6.12)**, **Groq Cloud API**, **Groq Whisper**, and **Windows local automation**. Designed for live college project exhibitions and daily personal computing, it combines real-time streaming AI reasoning, local hardware diagnostics, native voice dictation, safe desktop application dispatching, and secure API credential storage.

---

## 🚀 System Architecture

```
JARVIS AI Assistant
│
├── Frontend (PySide6)
│   ├── Left Navigation Sidebar (Collapsible, Search, Local Stored History)
│   ├── Central Dynamic View Stack:
│   │   ├── Dashboard (210px Animated Voice Orb, Waveform, Live Gauges)
│   │   ├── Conversational Chat (Markdown, Syntax Highlighted Code, Streaming)
│   │   ├── Live Voice Mode B (Immersive HUD, 240px Orb, Barge-in Interrupt)
│   │   ├── Quick Actions (Safe Windows App Launcher & Command Dispatcher)
│   │   └── Settings (Secure API Vault, Appearance, Voice, System Controls)
│   └── Right Information Panel (Collapsible, Clock, Open-Meteo Weather, Telemetry)
│
└── Backend Architecture
    ├── backend/config.py               # Keyring / Windows Credential Manager & .env
    ├── backend/database.py             # SQLite WAL-mode local storage (jarvis.db)
    ├── backend/ai_provider.py          # Groq Client (gpt-oss-120b, gpt-oss-20b, llama-3.3-70b)
    ├── backend/ai_engine.py            # Asynchronous streaming engine & context manager
    ├── backend/tool_router.py          # Safe command allowlist & multilingual intent matcher
    ├── backend/application_launcher.py # Real Windows process launcher (calc, notepad, explorer, etc.)
    ├── backend/speech_to_text.py       # Mode A sounddevice recording + Groq Whisper
    ├── backend/text_to_speech.py       # Asynchronous pyttsx3 Windows SAPI5 local speech
    ├── backend/live_voice.py           # Mode B dedicated live voice session manager
    ├── backend/system_monitor.py       # Real psutil hardware telemetry worker
    ├── backend/weather_service.py      # Real Open-Meteo weather & geocoding client
    └── backend/connection_manager.py   # Subsystem health & connectivity probes
```

---

## 🛠️ Complete Project Directory Structure

```
jarvis-c/
├── main.py                          # Standalone Windows application entry point
├── requirements.txt                 # Dependencies (PySide6, groq, psutil, sounddevice, etc.)
├── .env.example                     # Environment credential template
├── .gitignore                       # Protection for .env, sqlite db, cache
├── README.md                        # Master documentation & expo guide
├── test_backend.py                  # Backend test suite (8 verification modules)
├── test_frontend.py                 # Integrated visual & UI verification suite
│
├── backend/                         # Core Backend Engine
│   ├── __init__.py
│   ├── config.py                    # Windows Credential Manager & .env loader
│   ├── database.py                  # SQLite database engine (data/jarvis.db)
│   ├── ai_provider.py               # Groq SDK streaming provider with fallback
│   ├── ai_engine.py                 # Multi-turn context & Hindi/English/Hinglish engine
│   ├── tool_router.py               # Multilingual intent matcher & tool dispatcher
│   ├── application_launcher.py      # Real Windows application & browser controller
│   ├── speech_to_text.py            # Mode A audio recording & Groq Whisper STT
│   ├── text_to_speech.py            # Windows SAPI5 local TTS worker
│   ├── live_voice.py                # Mode B dedicated real-time voice session manager
│   ├── system_monitor.py            # psutil hardware telemetry worker
│   ├── weather_service.py           # Real Open-Meteo weather & geocoding
│   └── connection_manager.py        # Probes for Internet, Groq, Audio, Weather
│
├── frontend/                        # Presentation Layer
│   ├── __init__.py
│   ├── main_window.py               # Master window coordinator & signal bridges
│   ├── sidebar.py                   # Collapsible left navigation & history search
│   ├── chat_view.py                 # Conversational chat view with markdown stream
│   ├── chat_input.py                # Auto-expanding input & Mode A voice recorder
│   ├── dashboard_view.py            # Centerpiece voice orb & telemetry view
│   ├── voice_view.py                # Mode B dedicated live voice HUD
│   ├── quick_actions_view.py        # Windows apps & command dispatcher
│   ├── system_panel.py              # Collapsible right telemetry & digital clock
│   ├── settings_view.py             # Secure API Key Management & preferences suite
│   └── dialogs.py                   # Confirmation modals & About popups
│
├── components/                      # Reusable Custom Qt Widgets
│   ├── __init__.py
│   ├── voice_orb.py                 # 40 FPS animated multi-layer plasma voice orb
│   ├── waveform.py                  # Sinusoidal energy wave & frequency bars
│   ├── metric_gauge.py              # Circular and bar gauges for CPU/RAM/Battery
│   ├── status_indicator.py          # Glowing status dots & privacy badges
│   ├── cards.py                     # Elevated surface cards & action cards
│   ├── buttons.py                   # Gradient, icon, and danger buttons
│   └── message_bubble.py            # Markdown bubbles & copyable code blocks
│
├── styles/                          # Visual Design System
│   ├── __init__.py
│   ├── palette.py                   # Color constants & hex definitions
│   ├── icons.py                     # High-DPI QPainter vector icon generator
│   └── theme.qss                    # Master Qt Style Sheet
│
├── services/                        # Backward-Compatible Service Bridges
│   ├── __init__.py
│   ├── frontend_interfaces.py       # Data models & abstract contracts
│   ├── system_monitor.py            # Bridges to backend.system_monitor
│   ├── conversation_manager.py      # Bridges to backend.database SQLite
│   └── app_launcher.py              # Bridges to backend.application_launcher
│
├── data/                            # Persistent Application Storage
│   └── jarvis.db                    # SQLite database for conversations & messages
│
└── screenshots/                     # High-resolution verification captures
    ├── 01_dashboard_view.png
    ├── 02_chat_view.png
    ├── 03_voice_view.png
    ├── 04_quick_actions_view.png
    └── 05_settings_view.png
```

---

## ⚡ Quick Start: Installation & Launch Commands

### Prerequisites
- Windows 10 or Windows 11 (64-bit)
- Python 3.12, 3.13, or 3.14

### 1. Install Dependencies
```powershell
cd C:\Users\varun\Downloads\jarvis-c
pip install -r requirements.txt
```

### 2. Configure Credentials (Optional / Via UI)
You can configure credentials either by creating `.env` from `.env.example`:
```powershell
Copy-Item .env.example .env
```
Or directly inside the running application in **Settings -> AI Provider & Credentials** (`Ctrl+,`).

### 3. Launch JARVIS AI
```powershell
python main.py
```

### 4. Run Verification Test Suites
```powershell
# Run backend integration tests (8 modules: SQLite, Telemetry, Weather, Router, TTS, etc.)
python test_backend.py

# Run integrated UI test suite & regenerate screenshots
python test_frontend.py
```

---

## 🔑 Secure API Key Management

The Settings section (`Ctrl+,`) features a dedicated **API Key Management** interface:
- **Groq Cloud API Key**: Masked password field, Show/Hide toggle, Test Connection button, and Save button.
- **Google Gemini API Key**: Masked password field, Show/Hide toggle, Test Connection button, and Save button.
- **Model Architecture Settings**: Configurable primary model (`openai/gpt-oss-120b`), fallback model (`openai/gpt-oss-20b`), and default weather city.
- **Windows Credential Manager**: Keys are encrypted on-disk using Windows DPAPI / WinVault via `keyring`. Keys are never committed to version control and never printed in logs.
- **Dynamic Hot Reloading**: Updating and saving credentials applies immediately to subsequent requests without restarting the application.

---

## 🎯 Implemented Features Matrix

| Category | Feature | Status |
| :--- | :--- | :---: |
| **Conversational AI** | Multi-turn reasoning with Groq Cloud SDK | **Operational** |
| **Streaming Output** | Instant token streaming (target 1–3s first token) | **Operational** |
| **Model Fallback** | `openai/gpt-oss-120b` -> `openai/gpt-oss-20b` -> `llama-3.3-70b-versatile` | **Operational** |
| **Multilingual Support** | Automatic matching for English, Hindi, and Hinglish | **Operational** |
| **Code Generation** | Syntax-highlighted code blocks with "Copy Code" button | **Operational** |
| **Local Persistence** | SQLite WAL-mode database (`data/jarvis.db`) with full search | **Operational** |
| **Mode A Voice Dictation** | `sounddevice` recording + in-memory WAV + Groq Whisper STT | **Operational** |
| **Mode B Live Voice Call** | Full-screen HUD, reactive 240px orb, transcript, barge-in interrupt | **Operational** |
| **Local Speech (TTS)** | Asynchronous non-blocking Windows SAPI5 (`pyttsx3`) | **Operational** |
| **Real Hardware Telemetry** | psutil background thread (CPU %, RAM %, Disk %, Battery %) | **Operational** |
| **Real Weather Service** | Open-Meteo REST API + geocoding (no key required) | **Operational** |
| **Safe App Launcher** | Strict allowlist: Calculator, Notepad, Explorer, Settings, Web URLs | **Operational** |
| **Workstation Security** | System lock guarded by custom confirmation modal | **Operational** |
| **Subsystem Health Probes** | Live checks for Internet, Groq, Gemini, Mic, Speaker, Weather | **Operational** |
| **Responsive Design** | Collapsible sidebar (`Ctrl+B`) & collapsible telemetry (`Ctrl+T`) | **Operational** |

---

## 📋 Features Actually Tested & Verified

1. **SQLite Database Persistence**: Tested tables creation, insert, multi-turn message fetching, full-text search, and cascade deletion via `test_backend.py`.
2. **Open-Meteo Real Weather**: Tested live geocoding for `"New Delhi, India"` (`Lat: 28.62, Lon: 77.21`) and live current weather extraction (`20.5°C, 86% humidity, Clear Sky`).
3. **Hardware Telemetry via psutil**: Tested real collection on host machine (`VAIDIK-VERMA, Windows 11, 12 physical / 16 logical cores, 78% RAM, 85.5% Disk, Battery 78%`).
4. **Safe Command Registry**: Tested execution allowlist and verified that unsafe arbitrary commands are blocked.
5. **Multilingual Intent Matcher**: Tested English (`"open calculator"`), Hindi/Hinglish (`"notepad kholo"`, `"google pe machine learning search karo"`, `"search Python tutorials on youtube"`).
6. **Subsystem Connection Probes**: Verified real socket probes to DNS and Open-Meteo, plus audio input/output device detection via `sounddevice`.
7. **Windows SAPI5 Local TTS**: Verified detection and initialization of Microsoft David and Microsoft Zira voices.
8. **Integrated UI & Transitions**: Tested switching between all 5 views, collapsible panels, and verified rendering with high-resolution screenshots.

---

## 🔒 Features Requiring Additional External Credentials

1. **Groq Cloud API Key (`GROQ_API_KEY`)**:
   - Required for live neural conversational chat and Groq Whisper audio dictation.
   - Obtain a free key from: [https://console.groq.com/keys](https://console.groq.com/keys)
   - Once acquired, simply paste it in **Settings -> AI Provider & Credentials** and click **Save & Apply Groq Key**.
2. **Google Gemini API Key (`GEMINI_API_KEY`)**:
   - Required for dedicated Mode B Gemini Live real-time bidirectional audio streaming.
   - Obtain a key from: [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
   - Configure in **Settings -> AI Provider & Credentials**.

*Note: All desktop controls, application launches, system monitoring, Open-Meteo weather, and local persistence function fully without any cloud credentials.*

---

## 💡 Keyboard Shortcuts Cheat Sheet

| Shortcut | Action |
| :--- | :--- |
| **Enter** | Send message in Chat |
| **Shift + Enter** | Insert new line in Chat input |
| **Ctrl + N** | Start new conversation |
| **Ctrl + B** | Toggle Left Sidebar collapse |
| **Ctrl + T** | Toggle Right Telemetry Panel collapse |
| **Ctrl + 1** | Switch to Dashboard |
| **Ctrl + 2** | Switch to Chat Assistant |
| **Ctrl + 3** | Switch to Live Voice Call |
| **Ctrl + 4** | Switch to Quick Actions |
| **Ctrl + ,** | Open Settings (API Keys & Preferences) |
| **Escape** | Stop active AI streaming generation |
| **F11** | Toggle Fullscreen |
