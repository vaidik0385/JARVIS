"""
JARVIS AI — Automated Frontend Verification & Visual Test Suite
Tests module imports, widget instantiation, state transitions, signal flows,
and saves high-resolution snapshots of each screen.
"""

import sys
import os
import time
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QPixmap

def run_tests():
    print("[1/6] Initializing QApplication...")
    app = QApplication.instance() or QApplication(sys.argv)

    # Load stylesheet
    qss_path = os.path.join(os.path.dirname(__file__), "styles", "theme.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())
        print("  [OK] Stylesheet loaded successfully.")

    print("[2/6] Instantiating MainWindow...")
    from frontend.main_window import MainWindow
    window = MainWindow()
    window.resize(1340, 840)
    window.show()
    app.processEvents()
    print("  [OK] MainWindow instantiated and rendered.")

    # Create screenshots directory
    screenshots_dir = os.path.join(os.path.dirname(__file__), "screenshots")
    os.makedirs(screenshots_dir, exist_ok=True)

    print("[3/6] Testing View Transitions & Capturing Snapshots...")

    # View 0: Dashboard (Wait for weather probe to update panel)
    window._on_navigation_changed("dashboard")
    for _ in range(15):
        time.sleep(0.1)
        app.processEvents()
    dash_pix = window.grab()
    dash_path = os.path.join(screenshots_dir, "01_dashboard_view.png")
    dash_pix.save(dash_path)
    print(f"  [OK] Dashboard rendered -> saved to {dash_path}")

    # View 1: Chat Assistant
    window._on_navigation_changed("chat")
    app.processEvents()
    window._create_new_chat()
    app.processEvents()
    # Send a sample prompt
    window._on_user_sent_message("Display system architecture telemetry and run a self diagnostic.")
    # Wait for response timer
    for _ in range(16):
        time.sleep(0.1)
        app.processEvents()
    chat_pix = window.grab()
    chat_path = os.path.join(screenshots_dir, "02_chat_view.png")
    chat_pix.save(chat_path)
    print(f"  [OK] Chat Assistant rendered -> saved to {chat_path}")

    # View 2: Live Voice Conversation
    window._on_navigation_changed("voice")
    app.processEvents()
    time.sleep(0.1)
    voice_pix = window.grab()
    voice_path = os.path.join(screenshots_dir, "03_voice_view.png")
    voice_pix.save(voice_path)
    print(f"  [OK] Live Voice View rendered -> saved to {voice_path}")

    # View 3: Quick Actions
    window._on_navigation_changed("actions")
    app.processEvents()
    time.sleep(0.1)
    actions_pix = window.grab()
    actions_path = os.path.join(screenshots_dir, "04_quick_actions_view.png")
    actions_pix.save(actions_path)
    print(f"  [OK] Quick Actions rendered -> saved to {actions_path}")

    # View 4: Settings (Highlighting API Key Management)
    window._on_navigation_changed("settings")
    from PySide6.QtWidgets import QTabWidget
    tabs = window.settings_view.findChild(QTabWidget)
    if tabs:
        tabs.setCurrentIndex(3)  # Select AI Provider & API Keys tab
    app.processEvents()
    time.sleep(0.1)
    settings_pix = window.grab()
    settings_path = os.path.join(screenshots_dir, "05_settings_view.png")
    settings_pix.save(settings_path)
    print(f"  [OK] Settings View (API Keys) rendered -> saved to {settings_path}")

    print("[4/6] Testing Collapsible Panels...")
    # Collapse sidebar
    window.sidebar.toggle_collapse()
    app.processEvents()
    assert window.sidebar.width() == 70, f"Sidebar failed to collapse (width={window.sidebar.width()})"
    # Expand sidebar
    window.sidebar.toggle_collapse()
    app.processEvents()
    assert window.sidebar.width() == 270, f"Sidebar failed to expand (width={window.sidebar.width()})"
    print("  [OK] Sidebar collapse and expand verified.")

    # Collapse telemetry panel
    window.system_panel.toggle_collapse()
    app.processEvents()
    assert window.system_panel.width() == 50, f"System panel failed to collapse (width={window.system_panel.width()})"
    # Expand telemetry panel
    window.system_panel.toggle_collapse()
    app.processEvents()
    assert window.system_panel.width() == 290, f"System panel failed to expand (width={window.system_panel.width()})"
    print("  [OK] Right System Panel collapse and expand verified.")

    print("[5/6] Testing Local Persistence...")
    convs = window.conv_manager.get_all_conversations()
    assert len(convs) > 0, "No conversations found in storage."
    print(f"  [OK] Persistence verified: {len(convs)} conversations loaded.")

    print("[6/6] Testing Real Telemetry Metrics Collection...")
    metrics = window.monitor_worker._collect_metrics()
    print(f"  [OK] Real Metrics collected: CPU={metrics.cpu_percent}%, RAM={metrics.ram_percent}% ({metrics.ram_used_gb}/{metrics.ram_total_gb} GB), Disk={metrics.disk_percent}%, Battery={metrics.battery_percent}%")

    print("\n==========================================")
    print("ALL FRONTEND TESTS COMPLETED SUCCESSFULLY!")
    print("==========================================")

    # Clean shutdown
    window.close()
    app.quit()
    sys.exit(0)

if __name__ == "__main__":
    run_tests()
