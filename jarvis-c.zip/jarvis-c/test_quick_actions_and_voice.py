"""
Verification Suite for Quick Actions & Live Voice Call Enhancements
"""

import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
from PySide6.QtWidgets import QApplication
from backend.application_launcher import ApplicationLauncher
from backend.tool_router import ToolRouter
from backend.text_to_speech import TextToSpeechService
from backend.live_voice import LiveVoiceManager, LIVE_VOICE_SYSTEM_PROMPT, VoiceTurnWorker
from backend.config import config
from groq import Groq

def test_quick_actions():
    print("[1/3] Testing Quick Actions Launch & Command Dispatch...")
    launcher = ApplicationLauncher(dry_run=True)
    
    actions = [
        "calculator", "notepad", "explorer", "settings",
        "chrome", "youtube", "google", "linkedin", "whatsapp"
    ]
    for action in actions:
        ok, msg = launcher.launch(action)
        assert ok, f"Failed to launch {action}: {msg}"
        print(f"  [OK] launch('{action}') -> {msg}")
    
    # Test natural language command bar dispatcher
    commands = [
        "open calculator",
        "notepad kholo",
        "search Python tutorials on youtube",
        "whatsapp kholo"
    ]
    for cmd in commands:
        ok, msg = launcher.parse_and_execute_command(cmd)
        assert ok, f"Failed command '{cmd}': {msg}"
        print(f"  [OK] parse_and_execute_command('{cmd}') -> {msg}")

def test_live_voice_manager():
    print("\n[2/3] Testing LiveVoiceManager Architecture...")
    app = QApplication.instance() or QApplication(sys.argv)
    tts = TextToSpeechService()
    launcher = ApplicationLauncher(dry_run=True)
    router = ToolRouter(launcher)
    live_voice = LiveVoiceManager(tts, router)
    
    # Verify properties
    assert not live_voice.is_active()
    assert live_voice._state == "idle"
    
    # Verify telemetry context injection
    live_voice.set_system_context("Location: New Delhi; Temp: 27C; Battery: 80%")
    assert "New Delhi" in live_voice._system_context
    print("  [OK] LiveVoiceManager instantiated with tool router and telemetry context.")
    
    # Test tool confirmation generator
    c1 = VoiceTurnWorker._generate_tool_confirmation("open calculator", "launched")
    assert "Calculator" in c1
    print(f"  [OK] Spoken tool confirmation: '{c1}'")
    
    # Test text cleaner
    clean = VoiceTurnWorker._clean_spoken_text("**Hello** `world`! https://example.com")
    assert "Hello world" in clean, f"Got: {repr(clean)}"
    print(f"  [OK] Spoken text cleaner: '{clean}'")
    
    tts.shutdown()

def test_live_voice_ai_reasoning():
    print("\n[3/3] Testing Live Voice Conversational Reasoning (Groq Cloud)...")
    key = config.groq_api_key
    assert key, "Groq API key required"
    client = Groq(api_key=key)
    
    test_queries = [
        ("English", "Hello Jarvis, how are you today?"),
        ("Hinglish", "Jarvis bhai, computer ka mausam aur battery batao?")
    ]
    
    for lang, prompt in test_queries:
        messages = [
            {"role": "system", "content": LIVE_VOICE_SYSTEM_PROMPT},
            {
                "role": "system",
                "content": "[Live Telemetry & Environmental Context]\nLocation: New Delhi, India; Temperature: 27.5C; Weather: Clear Sky; CPU Load: 12%; Battery: 75%."
            },
            {"role": "user", "content": prompt}
        ]
        
        res = client.chat.completions.create(
            model=config.ai_model,
            messages=messages,
            max_tokens=500,
            temperature=0.6
        )
        msg = res.choices[0].message
        ans = msg.content or getattr(msg, "reasoning", "")
        clean_ans = VoiceTurnWorker._clean_spoken_text(ans)
        
        print(f"  [{lang} Voice Query] '{prompt}'")
        print(f"  -> JARVIS Spoken Reply: \"{clean_ans}\"")
        assert len(clean_ans) > 5, "Response too short"
        assert len(clean_ans.split()) <= 45, "Response too long for voice"

if __name__ == "__main__":
    test_quick_actions()
    test_live_voice_manager()
    test_live_voice_ai_reasoning()
    print("\n" + "="*60)
    print("ALL QUICK ACTIONS & LIVE VOICE TESTS PASSED SUCCESSFULLY!")
    print("="*60)
    sys.exit(0)
