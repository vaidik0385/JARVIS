"""
JARVIS AI — Chat Message Bubble & Code Block Renderer
Supports user/assistant bubbles, markdown rendering, styled code blocks
with copy buttons, timestamps, action toolbars, and thinking indicators.
"""

import re
from typing import Optional, List, Tuple
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextBrowser,
    QFrame, QPushButton, QApplication, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QTimer, QSize
from PySide6.QtGui import QFont, QColor
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.buttons import IconButton

class CodeBlockWidget(QFrame):
    """Sleek syntax-highlighted code block with language header and copy button."""
    def __init__(self, code: str, lang: str = "text", parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.code = code
        self.lang = (lang or "code").upper()

        self.setStyleSheet("""
            CodeBlockWidget {
                background-color: #080C16;
                border: 1px solid #1C263B;
                border-radius: 8px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header bar
        header = QFrame(self)
        header.setStyleSheet("""
            background-color: #0E1424;
            border-bottom: 1px solid #1C263B;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        """)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(12, 6, 8, 6)

        lang_lbl = QLabel(self.lang, header)
        lang_lbl.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700; letter-spacing: 1px; font-family: Consolas, monospace;")

        self.copy_btn = QPushButton("Copy Code", header)
        self.copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.copy_btn.setIcon(get_icon("copy", color="#94A3B8", size=14))
        self.copy_btn.setIconSize(QSize(14, 14))
        self.copy_btn.setStyleSheet("""
            QPushButton {
                background-color: #162032;
                color: #CBD5E1;
                border: 1px solid #25334E;
                border-radius: 5px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #1F2D48;
                border: 1px solid #00E5FF;
                color: #F8FAFC;
            }
        """)
        self.copy_btn.clicked.connect(self._copy_code)

        h_layout.addWidget(lang_lbl)
        h_layout.addStretch()
        h_layout.addWidget(self.copy_btn)

        # Code body
        self.code_label = QLabel(code, self)
        self.code_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.code_label.setStyleSheet("""
            QLabel {
                background-color: #070A12;
                color: #38BDF8;
                font-family: Consolas, 'Cascadia Code', 'Courier New', monospace;
                font-size: 12px;
                padding: 12px 14px;
                border: none;
                border-bottom-left-radius: 8px;
                border-bottom-right-radius: 8px;
            }
        """)

        layout.addWidget(header)
        layout.addWidget(self.code_label)

    def _copy_code(self):
        QApplication.clipboard().setText(self.code)
        self.copy_btn.setText("Copied!")
        self.copy_btn.setIcon(get_icon("check", color="#10B981", size=14))
        QTimer.singleShot(2000, self._reset_copy_btn)

    def _reset_copy_btn(self):
        self.copy_btn.setText("Copy Code")
        self.copy_btn.setIcon(get_icon("copy", color="#94A3B8", size=14))


class MessageBubbleWidget(QWidget):
    copy_requested = Signal(str)
    regenerate_requested = Signal()

    def __init__(self, role: str, content: str, timestamp: str = "", is_streaming: bool = False, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.role = role
        self.raw_content = content
        self.timestamp = timestamp
        self.is_streaming = is_streaming
        self._stream_label = None

        self._init_ui()

    def append_chunk(self, chunk: str):
        self.raw_content += chunk
        if self._stream_label:
            self._stream_label.setText(self.raw_content)

    def finalize_stream(self, full_text: Optional[str] = None):
        if full_text is not None:
            self.raw_content = full_text
        self.is_streaming = False
        # Rebuild UI with full syntax highlighted code blocks
        layout = self.layout()
        if layout:
            while layout.count() > 0:
                item = layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
                elif item.layout():
                    sub = item.layout()
                    while sub.count() > 0:
                        sub_item = sub.takeAt(0)
                        if sub_item.widget():
                            sub_item.widget().deleteLater()
        self._init_ui()

    def _init_ui(self):
        main_layout = self.layout()
        if main_layout is None:
            main_layout = QVBoxLayout(self)
            main_layout.setContentsMargins(12, 6, 12, 6)
            main_layout.setSpacing(4)

        if self.role == "user":
            self._build_user_bubble(main_layout)
        else:
            self._build_assistant_bubble(main_layout)

    def _build_user_bubble(self, main_layout: QVBoxLayout):
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        row.addStretch()

        # Content bubble container
        bubble = QFrame(self)
        bubble.setStyleSheet("""
            QFrame {
                background-color: #17243C;
                border: 1px solid #243657;
                border-radius: 12px;
                border-top-right-radius: 2px;
            }
        """)
        b_layout = QVBoxLayout(bubble)
        b_layout.setContentsMargins(14, 10, 14, 10)
        b_layout.setSpacing(6)

        text_lbl = QLabel(self.raw_content, bubble)
        text_lbl.setWordWrap(True)
        text_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        text_lbl.setStyleSheet("color: #F8FAFC; font-size: 13px; line-height: 19px; background: transparent; border: none;")
        b_layout.addWidget(text_lbl)

        # Timestamp row
        if self.timestamp:
            ts_lbl = QLabel(self.timestamp, bubble)
            ts_lbl.setStyleSheet("color: #64748B; font-size: 10px; background: transparent; border: none;")
            ts_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
            b_layout.addWidget(ts_lbl)

        row.addWidget(bubble)
        main_layout.addLayout(row)

    def _build_assistant_bubble(self, main_layout: QVBoxLayout):
        # Header: JARVIS Logo + Name + Timestamp
        header = QHBoxLayout()
        header.setSpacing(8)

        logo_lbl = QLabel(self)
        logo_lbl.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=18))
        logo_lbl.setStyleSheet("border: none; background: transparent;")

        name_lbl = QLabel("JARVIS", self)
        name_lbl.setStyleSheet("color: #00E5FF; font-size: 12px; font-weight: 700; letter-spacing: 0.8px;")

        header.addWidget(logo_lbl)
        header.addWidget(name_lbl)

        if self.timestamp:
            ts_lbl = QLabel(f"• {self.timestamp}", self)
            ts_lbl.setStyleSheet("color: #64748B; font-size: 11px;")
            header.addWidget(ts_lbl)

        header.addStretch()
        main_layout.addLayout(header)

        # Bubble Card
        bubble = QFrame(self)
        bubble.setStyleSheet("""
            QFrame {
                background-color: #111728;
                border: 1px solid #1C263B;
                border-radius: 12px;
                border-top-left-radius: 2px;
            }
        """)
        b_layout = QVBoxLayout(bubble)
        b_layout.setContentsMargins(16, 14, 16, 14)
        b_layout.setSpacing(10)

        if self.is_streaming:
            self._stream_label = QLabel(self.raw_content or "Thinking...", bubble)
            self._stream_label.setWordWrap(True)
            self._stream_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self._stream_label.setStyleSheet("color: #38BDF8; font-size: 13px; line-height: 20px; background: transparent; border: none; font-style: italic;")
            b_layout.addWidget(self._stream_label)
        else:
            # Parse text and code blocks
            blocks = self._parse_blocks(self.raw_content)
            for b_type, b_content, b_lang in blocks:
                if b_type == "code":
                    cb = CodeBlockWidget(b_content, b_lang, bubble)
                    b_layout.addWidget(cb)
                else:
                    lbl = QLabel(bubble)
                    lbl.setTextFormat(Qt.TextFormat.MarkdownText)
                    lbl.setText(b_content)
                    lbl.setWordWrap(True)
                    lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.LinksAccessibleByMouse)
                    lbl.setOpenExternalLinks(True)
                    lbl.setStyleSheet("""
                        QLabel {
                            color: #E2E8F0;
                            font-size: 13px;
                            background: transparent;
                            border: none;
                        }
                    """)
                    b_layout.addWidget(lbl)

        # Action Toolbar at bottom of assistant card
        actions_row = QHBoxLayout()
        actions_row.setContentsMargins(0, 4, 0, 0)
        actions_row.setSpacing(8)

        copy_btn = QPushButton("Copy", bubble)
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.setIcon(get_icon("copy", color="#94A3B8", size=13))
        copy_btn.setIconSize(QSize(13, 13))
        copy_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #94A3B8;
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #182236;
                color: #F8FAFC;
                border: 1px solid #25334E;
            }
        """)
        copy_btn.clicked.connect(lambda: self._on_copy_full(copy_btn))

        regen_btn = QPushButton("Regenerate", bubble)
        regen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        regen_btn.setIcon(get_icon("refresh", color="#94A3B8", size=13))
        regen_btn.setIconSize(QSize(13, 13))
        regen_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #94A3B8;
                border: 1px solid transparent;
                border-radius: 4px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #182236;
                color: #F8FAFC;
                border: 1px solid #25334E;
            }
        """)
        regen_btn.clicked.connect(self.regenerate_requested.emit)

        actions_row.addWidget(copy_btn)
        actions_row.addWidget(regen_btn)
        actions_row.addStretch()

        b_layout.addLayout(actions_row)
        main_layout.addWidget(bubble)

    def _on_copy_full(self, btn: QPushButton):
        QApplication.clipboard().setText(self.raw_content)
        btn.setText("Copied!")
        btn.setIcon(get_icon("check", color="#10B981", size=13))
        QTimer.singleShot(2000, lambda: self._reset_copy_text(btn))

    def _reset_copy_text(self, btn: QPushButton):
        btn.setText("Copy")
        btn.setIcon(get_icon("copy", color="#94A3B8", size=13))

    def _parse_blocks(self, text: str) -> List[Tuple[str, str, str]]:
        """Parses markdown into alternating (text, code) tuples."""
        pattern = r"```([a-zA-Z0-9_\-\+]*)\n(.*?)```"
        blocks = []
        last_idx = 0
        for match in re.finditer(pattern, text, re.DOTALL):
            start, end = match.span()
            if start > last_idx:
                raw_txt = text[last_idx:start].strip()
                if raw_txt:
                    blocks.append(("text", raw_txt, ""))
            lang = match.group(1).strip()
            code = match.group(2).rstrip()
            blocks.append(("code", code, lang))
            last_idx = end
        if last_idx < len(text):
            tail = text[last_idx:].strip()
            if tail:
                blocks.append(("text", tail, ""))
        if not blocks:
            blocks.append(("text", text, ""))
        return blocks


class TypingIndicatorWidget(QWidget):
    """Pulsing dots indicating JARVIS is thinking or processing."""
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setFixedHeight(40)
        self._dot_index = 0

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 4, 14, 4)
        layout.setSpacing(10)

        logo_lbl = QLabel(self)
        logo_lbl.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=16))
        layout.addWidget(logo_lbl)

        self.label = QLabel("JARVIS is thinking...", self)
        self.label.setStyleSheet("color: #38BDF8; font-size: 12px; font-weight: 500; font-style: italic;")
        layout.addWidget(self.label)
        layout.addStretch()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start(350)

    def _on_tick(self):
        self._dot_index = (self._dot_index + 1) % 4
        dots = "." * self._dot_index
        self.label.setText(f"JARVIS is thinking{dots}")
