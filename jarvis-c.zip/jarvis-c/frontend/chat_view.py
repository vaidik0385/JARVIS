"""
JARVIS AI — Central Conversational Chat Interface
Features time-based welcome greeting, 4 quick starter cards,
message bubble stream, auto-scrolling, thinking indicator,
streaming response animation, and conversation controls.
"""

from datetime import datetime
from typing import Optional, List
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
    QFrame, QGridLayout, QPushButton
)
from PySide6.QtCore import Qt, Signal, QTimer, QSize
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.message_bubble import MessageBubbleWidget, TypingIndicatorWidget
from components.cards import ActionTriggerCard
from components.buttons import IconButton
from frontend.chat_input import ChatInputWidget
from services.frontend_interfaces import ChatMessage
from backend.config import config

class ChatView(QWidget):
    user_sent_message = Signal(str)
    clear_conversation_requested = Signal()
    regenerate_last_requested = Signal()
    switch_view_requested = Signal(str)  # "voice", "actions", "dashboard"
    stop_generation_requested = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._is_generating = False
        self._current_cid = None
        self._messages: List[ChatMessage] = []
        self._active_stream_bubble: Optional[MessageBubbleWidget] = None

        self._init_ui()
        self.update_connection_status()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 16, 20, 16)
        main_layout.setSpacing(12)

        # 1. Top Chat Header Bar
        header = QFrame(self)
        header.setStyleSheet("""
            QFrame {
                background-color: #0E1424;
                border: 1px solid #1C263B;
                border-radius: 10px;
                padding: 6px 12px;
            }
        """)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(12, 6, 12, 6)
        h_layout.setSpacing(10)

        # Model badge
        model_icon = QLabel(header)
        model_icon.setPixmap(get_pixmap("sparkle", color=Palette.ACCENT_CYAN, size=16))
        model_icon.setStyleSheet("border: none; background: transparent;")

        self.chat_title_lbl = QLabel("JARVIS Core v2.4 • Direct Line", header)
        self.chat_title_lbl.setStyleSheet("color: #F8FAFC; font-size: 13px; font-weight: 700; border: none; background: transparent;")

        self.model_status_lbl = QLabel("(Local Standby / Real Frontend)", header)
        self.model_status_lbl.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: 600; border: none; background: transparent;")

        # Header utility buttons
        self.clear_btn = IconButton("trash", tooltip="Clear Conversation", size=30, parent=header)
        self.clear_btn.clicked.connect(self.clear_conversation_requested.emit)

        h_layout.addWidget(model_icon)
        h_layout.addWidget(self.chat_title_lbl)
        h_layout.addWidget(self.model_status_lbl)
        h_layout.addStretch()
        h_layout.addWidget(self.clear_btn)

        main_layout.addWidget(header)

        # 2. Main Scroll Area for Messages
        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.scroll_widget = QWidget()
        self.messages_layout = QVBoxLayout(self.scroll_widget)
        self.messages_layout.setContentsMargins(0, 8, 0, 8)
        self.messages_layout.setSpacing(12)

        # 3. Welcome Container (displayed when conversation is empty)
        self.welcome_container = QWidget(self.scroll_widget)
        self._build_welcome_screen()
        self.messages_layout.addWidget(self.welcome_container)

        # 4. Message Bubbles Container
        self.bubbles_widget = QWidget(self.scroll_widget)
        self.bubbles_layout = QVBoxLayout(self.bubbles_widget)
        self.bubbles_layout.setContentsMargins(0, 0, 0, 0)
        self.bubbles_layout.setSpacing(10)
        self.messages_layout.addWidget(self.bubbles_widget)

        # 5. Typing Indicator (hidden by default)
        self.typing_indicator = TypingIndicatorWidget(self.scroll_widget)
        self.typing_indicator.hide()
        self.messages_layout.addWidget(self.typing_indicator)

        self.messages_layout.addStretch()

        self.scroll_area.setWidget(self.scroll_widget)
        main_layout.addWidget(self.scroll_area, stretch=1)

        # 5. Bottom Chat Input Widget
        self.chat_input = ChatInputWidget(self)
        self.chat_input.message_sent.connect(self._on_message_sent)
        self.chat_input.live_voice_requested.connect(lambda: self.switch_view_requested.emit("voice"))
        self.chat_input.stop_requested.connect(self.stop_generation_requested.emit)
        main_layout.addWidget(self.chat_input)

    def _build_welcome_screen(self):
        w_layout = QVBoxLayout(self.welcome_container)
        w_layout.setContentsMargins(20, 30, 20, 20)
        w_layout.setSpacing(20)
        w_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Glowing Arc Logo Emblem
        logo_lbl = QLabel(self.welcome_container)
        logo_lbl.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=56))
        logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        w_layout.addWidget(logo_lbl)

        # Dynamic Time-based Greeting
        now = datetime.now()
        hr = now.hour
        if hr < 12:
            greet = "Good morning, Sir."
        elif hr < 17:
            greet = "Good afternoon, Sir."
        else:
            greet = "Good evening, Sir."

        greeting_lbl = QLabel(greet, self.welcome_container)
        greeting_lbl.setStyleSheet("color: #F8FAFC; font-size: 24px; font-weight: 800; letter-spacing: 0.5px;")
        greeting_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        w_layout.addWidget(greeting_lbl)

        intro_lbl = QLabel(
            "JARVIS AI is active and monitoring all subsystems. How may I be of assistance?",
            self.welcome_container
        )
        intro_lbl.setStyleSheet("color: #94A3B8; font-size: 13px; line-height: 18px;")
        intro_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        w_layout.addWidget(intro_lbl)

        # 4 Quick Starter Cards Grid
        grid_widget = QWidget(self.welcome_container)
        grid = QGridLayout(grid_widget)
        grid.setSpacing(14)
        grid.setContentsMargins(10, 10, 10, 10)

        card1 = ActionTriggerCard(
            "chat",
            "Ask Anything",
            "Inquire about programming, system architecture, or general knowledge.",
            accent_color=Palette.ACCENT_CYAN,
            parent=grid_widget
        )
        card1.clicked.connect(lambda: self.chat_input.set_text("Explain the architectural lifecycle of a desktop AI assistant."))

        card2 = ActionTriggerCard(
            "actions",
            "Open Applications",
            "Instantly launch Windows apps like Calculator, Notepad, or browsers.",
            accent_color=Palette.ACCENT_BLUE,
            parent=grid_widget
        )
        card2.clicked.connect(lambda: self.switch_view_requested.emit("actions"))

        card3 = ActionTriggerCard(
            "cpu",
            "System Information",
            "View real-time CPU telemetry, RAM allocation, and battery metrics.",
            accent_color="#10B981",
            parent=grid_widget
        )
        card3.clicked.connect(lambda: self.switch_view_requested.emit("dashboard"))

        card4 = ActionTriggerCard(
            "voice",
            "Voice Conversation",
            "Engage in hands-free live conversational mode with the central voice orb.",
            accent_color=Palette.ACCENT_PURPLE,
            parent=grid_widget
        )
        card4.clicked.connect(lambda: self.switch_view_requested.emit("voice"))

        grid.addWidget(card1, 0, 0)
        grid.addWidget(card2, 0, 1)
        grid.addWidget(card3, 1, 0)
        grid.addWidget(card4, 1, 1)

        w_layout.addWidget(grid_widget)

    def load_messages(self, messages: List[ChatMessage], title: str = "Conversation"):
        self.chat_title_lbl.setText(title)
        self._messages = messages

        # Clean all existing bubbles
        while self.bubbles_layout.count() > 0:
            item = self.bubbles_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if messages:
            self.welcome_container.hide()
            for msg in messages:
                self._render_message(msg)
        else:
            self.welcome_container.show()

        self._scroll_to_bottom()

    def add_message(self, msg: ChatMessage):
        self.welcome_container.hide()
        self._messages.append(msg)
        self._render_message(msg)
        self._scroll_to_bottom()

    def _render_message(self, msg: ChatMessage):
        bubble = MessageBubbleWidget(
            role=msg.role,
            content=msg.content,
            timestamp=msg.timestamp,
            is_streaming=msg.is_streaming,
            parent=self.bubbles_widget
        )
        bubble.regenerate_requested.connect(self.regenerate_last_requested.emit)
        self.bubbles_layout.addWidget(bubble)

    def start_stream_message(self, timestamp: str = ""):
        self.welcome_container.hide()
        self.typing_indicator.hide()
        ts = timestamp or datetime.now().strftime("%I:%M %p")
        bubble = MessageBubbleWidget(
            role="assistant",
            content="",
            timestamp=ts,
            is_streaming=True,
            parent=self.bubbles_widget
        )
        bubble.regenerate_requested.connect(self.regenerate_last_requested.emit)
        self.bubbles_layout.addWidget(bubble)
        self._active_stream_bubble = bubble
        self._scroll_to_bottom()

    def append_stream_chunk(self, chunk: str):
        if self._active_stream_bubble:
            self._active_stream_bubble.append_chunk(chunk)
            self._scroll_to_bottom()

    def finalize_stream(self, full_text: str):
        self.typing_indicator.hide()
        if self._active_stream_bubble:
            self._active_stream_bubble.finalize_stream(full_text)
            self._active_stream_bubble = None
        self.set_generating(False)
        self.update_connection_status()
        self._scroll_to_bottom()

    def set_generating(self, is_generating: bool):
        self._is_generating = is_generating
        self.chat_input.set_generating(is_generating)
        if is_generating:
            self.model_status_lbl.setText("● Groq: Generating response...")
            self.model_status_lbl.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: 600; border: none; background: transparent;")
        else:
            self.update_connection_status()

    def update_connection_status(self, custom_text: Optional[str] = None, is_error: bool = False):
        if is_error:
            self.model_status_lbl.setText(f"● {custom_text or 'Connection Error'}")
            self.model_status_lbl.setStyleSheet("color: #EF4444; font-size: 11px; font-weight: 600; border: none; background: transparent;")
        elif custom_text:
            self.model_status_lbl.setText(f"● {custom_text}")
            self.model_status_lbl.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: 600; border: none; background: transparent;")
        elif config.is_groq_configured():
            self.model_status_lbl.setText(f"● Groq: {config.groq_model} (Ready)")
            self.model_status_lbl.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 600; border: none; background: transparent;")
        else:
            self.model_status_lbl.setText("● Groq: Key Required (Press Ctrl+,)")
            self.model_status_lbl.setStyleSheet("color: #F59E0B; font-size: 11px; font-weight: 600; border: none; background: transparent;")

    def set_thinking(self, is_thinking: bool):
        if is_thinking:
            self.typing_indicator.show()
        else:
            self.typing_indicator.hide()
        self._scroll_to_bottom()

    def _on_message_sent(self, text: str):
        self.user_sent_message.emit(text)

    def _scroll_to_bottom(self):
        QTimer.singleShot(50, lambda: self.scroll_area.verticalScrollBar().setValue(
            self.scroll_area.verticalScrollBar().maximum()
        ))
