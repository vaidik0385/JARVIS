"""
JARVIS AI — Comprehensive Settings View
Structured multi-category settings interface: General, Appearance, Voice & Audio,
AI Provider, Language, Privacy & Security, Keyboard Shortcuts, and About.
"""

from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTabWidget, QCheckBox, QComboBox, QSlider, QPushButton,
    QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QLineEdit
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.buttons import PrimaryButton, DangerButton
from components.status_indicator import GlowingDot

class SettingsView(QWidget):
    theme_changed = Signal(str)
    clear_all_data_requested = Signal()
    groq_key_updated = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(28, 20, 28, 20)
        main_layout.setSpacing(16)

        # 1. Header
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(get_pixmap("settings", color=Palette.ACCENT_CYAN, size=24))

        title_vbox = QVBoxLayout()
        title_vbox.setSpacing(2)

        title_lbl = QLabel("JARVIS CONFIGURATION & PREFERENCES", self)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 20px; font-weight: 800; letter-spacing: 1px;")

        sub_lbl = QLabel("Customize desktop behavior, audio channels, AI endpoints, and security policies.", self)
        sub_lbl.setStyleSheet("color: #94A3B8; font-size: 12px;")

        title_vbox.addWidget(title_lbl)
        title_vbox.addWidget(sub_lbl)

        header_row.addWidget(icon_lbl)
        header_row.addLayout(title_vbox)
        header_row.addStretch()

        main_layout.addLayout(header_row)

        # 2. Tab Widget
        tabs = QTabWidget(self)
        tabs.addTab(self._build_general_tab(), "General")
        tabs.addTab(self._build_appearance_tab(), "Appearance")
        tabs.addTab(self._build_voice_tab(), "Voice & Audio")
        tabs.addTab(self._build_ai_tab(), "AI Provider")
        tabs.addTab(self._build_privacy_tab(), "Privacy & Security")
        tabs.addTab(self._build_shortcuts_tab(), "Shortcuts")
        tabs.addTab(self._build_about_tab(), "About")

        main_layout.addWidget(tabs, stretch=1)

    def _build_general_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        self.startup_chk = QCheckBox("Launch JARVIS AI automatically on Windows startup", widget)
        self.startup_chk.setChecked(True)

        self.tray_chk = QCheckBox("Minimize to system notification tray when window is closed", widget)
        self.tray_chk.setChecked(True)

        self.telemetry_chk = QCheckBox("Enable high-frequency background system performance polling", widget)
        self.telemetry_chk.setChecked(True)

        # Default landing view
        view_row = QHBoxLayout()
        v_lbl = QLabel("Default View on Startup:", widget)
        v_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.view_combo = QComboBox(widget)
        self.view_combo.addItems(["Dashboard (Voice Orb & Telemetry)", "Chat Assistant", "Live Voice Call", "Quick Actions"])
        view_row.addWidget(v_lbl)
        view_row.addWidget(self.view_combo)
        view_row.addStretch()

        layout.addWidget(self.startup_chk)
        layout.addWidget(self.tray_chk)
        layout.addWidget(self.telemetry_chk)
        layout.addLayout(view_row)
        layout.addStretch()
        return widget

    def _build_appearance_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Theme Selector
        theme_row = QHBoxLayout()
        t_lbl = QLabel("Active Color Theme:", widget)
        t_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.theme_combo = QComboBox(widget)
        self.theme_combo.addItems(["Midnight Charcoal (Default)", "Deep Navy Obsidian", "Cyber Slate"])
        theme_row.addWidget(t_lbl)
        theme_row.addWidget(self.theme_combo)
        theme_row.addStretch()

        # Accent Color
        accent_row = QHBoxLayout()
        a_lbl = QLabel("Primary Accent Glow:", widget)
        a_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.accent_combo = QComboBox(widget)
        self.accent_combo.addItems(["Electric Cyan (#00E5FF)", "Neon Purple (#8B5CF6)", "Cobalt Blue (#3B82F6)"])
        accent_row.addWidget(a_lbl)
        accent_row.addWidget(self.accent_combo)
        accent_row.addStretch()

        # UI Scale
        scale_row = QHBoxLayout()
        s_lbl = QLabel("Interface Scaling:", widget)
        s_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.scale_combo = QComboBox(widget)
        self.scale_combo.addItems(["100% (Standard)", "110% (Enhanced)", "125% (High DPI)"])
        scale_row.addWidget(s_lbl)
        scale_row.addWidget(self.scale_combo)
        scale_row.addStretch()

        layout.addLayout(theme_row)
        layout.addLayout(accent_row)
        layout.addLayout(scale_row)
        layout.addStretch()
        return widget

    def _build_voice_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Voice selection
        voice_row = QHBoxLayout()
        v_lbl = QLabel("Text-to-Speech Engine Voice:", widget)
        v_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.voice_combo = QComboBox(widget)
        self.voice_combo.addItems(["JARVIS British Male (Neural)", "JARVIS American Male (Studio)", "Friday Female (Neural)"])
        voice_row.addWidget(v_lbl)
        voice_row.addWidget(self.voice_combo)
        voice_row.addStretch()

        # Speech rate slider
        rate_box = QVBoxLayout()
        rate_box.setSpacing(6)
        r_lbl = QLabel("Speech Synthesis Speed: 1.0x", widget)
        r_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.rate_slider = QSlider(Qt.Orientation.Horizontal, widget)
        self.rate_slider.setRange(75, 150)
        self.rate_slider.setValue(100)
        self.rate_slider.valueChanged.connect(lambda val: r_lbl.setText(f"Speech Synthesis Speed: {val/100.0:.2f}x"))
        rate_box.addWidget(r_lbl)
        rate_box.addWidget(self.rate_slider)

        # Wake word toggle
        self.wake_chk = QCheckBox("Enable Wake Word Detection ('Hey JARVIS')", widget)
        self.wake_chk.setChecked(True)

        layout.addLayout(voice_row)
        layout.addLayout(rate_box)
        layout.addWidget(self.wake_chk)
        layout.addStretch()
        return widget

    def _build_ai_tab(self) -> QWidget:
        from backend.config import config
        from backend.ai_provider import GroqProvider

        widget = QWidget()
        scroll = QScrollArea(widget)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(14)

        # 1. Primary AI Provider Selection
        prov_row = QHBoxLayout()
        p_lbl = QLabel("Active AI Reasoning Provider:", content)
        p_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px; font-weight: 600;")
        self.prov_combo = QComboBox(content)
        self.prov_combo.addItems([
            "Groq Cloud (openai/gpt-oss-120b & llama-3.3-70b)",
            "Google Gemini (Multimodal & Live Audio)",
            "Local Ollama (Offline Inference)"
        ])
        prov_row.addWidget(p_lbl)
        prov_row.addWidget(self.prov_combo, stretch=1)
        layout.addLayout(prov_row)

        # 2. Card: Groq API Key
        groq_card = QFrame(content)
        groq_card.setStyleSheet("""
            QFrame {
                background-color: #111828;
                border: 1px solid #1E2D4A;
                border-radius: 10px;
                padding: 12px;
            }
        """)
        g_layout = QVBoxLayout(groq_card)
        g_layout.setContentsMargins(12, 10, 12, 10)
        g_layout.setSpacing(10)

        g_header = QHBoxLayout()
        g_title = QLabel("GROQ CLOUD API CREDENTIALS", groq_card)
        g_title.setStyleSheet("color: #00E5FF; font-size: 12px; font-weight: 800; letter-spacing: 0.8px;")
        
        is_configured = config.is_groq_configured()
        self.groq_status_lbl = QLabel(
            "● Connected (Active)" if is_configured else "● Key Not Set", groq_card
        )
        self.groq_status_lbl.setStyleSheet(
            f"color: {'#10B981' if is_configured else '#F59E0B'}; font-size: 11px; font-weight: 700;"
        )
        g_header.addWidget(g_title)
        g_header.addStretch()
        g_header.addWidget(self.groq_status_lbl)
        g_layout.addLayout(g_header)

        # Active Key fingerprint indicator (NEVER displays raw complete key)
        self.groq_masked_lbl = QLabel(
            f"Active Vault Key: {config.mask_key(config.groq_api_key)}", groq_card
        )
        self.groq_masked_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-family: Consolas, monospace;")
        g_layout.addWidget(self.groq_masked_lbl)

        # Input row for setting or replacing key
        g_input_row = QHBoxLayout()
        g_input_row.setSpacing(8)
        self.groq_key_input = QLineEdit(groq_card)
        self.groq_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.groq_key_input.setPlaceholderText("Paste new Groq API Key to set or replace (gsk_...)")
        self.groq_key_input.setStyleSheet("background-color: #0B101D; border: 1px solid #202F4F; color: #F8FAFC; padding: 6px 10px;")

        self.groq_show_btn = QPushButton("Show", groq_card)
        self.groq_show_btn.setToolTip("Show/hide text while typing")
        self.groq_show_btn.setFixedWidth(64)
        self.groq_show_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.groq_show_btn.clicked.connect(self._toggle_groq_visibility)

        g_input_row.addWidget(self.groq_key_input, stretch=1)
        g_input_row.addWidget(self.groq_show_btn)
        g_layout.addLayout(g_input_row)

        # Actions row
        g_btn_row = QHBoxLayout()
        g_btn_row.setSpacing(10)

        self.groq_test_btn = QPushButton("Test Groq Connection", groq_card)
        self.groq_test_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.groq_test_btn.clicked.connect(self._test_groq_connection)

        self.groq_clear_btn = QPushButton("Clear Key", groq_card)
        self.groq_clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.groq_clear_btn.setStyleSheet("color: #EF4444; border: 1px solid #7F1D1D; background: transparent; padding: 5px 12px; border-radius: 4px;")
        self.groq_clear_btn.clicked.connect(self._clear_groq_key)

        self.groq_save_btn = PrimaryButton("Save && Apply Groq Key", parent=groq_card)
        self.groq_save_btn.clicked.connect(self._save_groq_key)

        g_btn_row.addWidget(self.groq_test_btn)
        g_btn_row.addWidget(self.groq_clear_btn)
        g_btn_row.addStretch()
        g_btn_row.addWidget(self.groq_save_btn)
        g_layout.addLayout(g_btn_row)

        layout.addWidget(groq_card)

        # 3. Card: Gemini API Key
        gemini_card = QFrame(content)
        gemini_card.setStyleSheet("""
            QFrame {
                background-color: #111828;
                border: 1px solid #1E2D4A;
                border-radius: 10px;
                padding: 12px;
            }
        """)
        gm_layout = QVBoxLayout(gemini_card)
        gm_layout.setContentsMargins(12, 10, 12, 10)
        gm_layout.setSpacing(10)

        gm_header = QHBoxLayout()
        gm_title = QLabel("GOOGLE GEMINI API CREDENTIALS (LIVE MODE)", gemini_card)
        gm_title.setStyleSheet("color: #8B5CF6; font-size: 12px; font-weight: 800; letter-spacing: 0.8px;")
        self.gemini_status_lbl = QLabel(
            "● Connected (Live Ready)" if config.gemini_api_key else "● Key Not Set", gemini_card
        )
        self.gemini_status_lbl.setStyleSheet(
            f"color: {'#10B981' if config.gemini_api_key else '#64748B'}; font-size: 11px; font-weight: 700;"
        )
        gm_header.addWidget(gm_title)
        gm_header.addStretch()
        gm_header.addWidget(self.gemini_status_lbl)
        gm_layout.addLayout(gm_header)

        # Input row
        gm_input_row = QHBoxLayout()
        gm_input_row.setSpacing(8)
        self.gemini_key_input = QLineEdit(gemini_card)
        self.gemini_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.gemini_key_input.setPlaceholderText("Enter your Google Gemini API Key (AIzaSy...)")
        if config.gemini_api_key:
            self.gemini_key_input.setText(config.gemini_api_key)
        self.gemini_key_input.setStyleSheet("background-color: #0B101D; border: 1px solid #202F4F; color: #F8FAFC; padding: 6px 10px;")

        self.gemini_show_btn = QPushButton("Show", gemini_card)
        self.gemini_show_btn.setFixedWidth(64)
        self.gemini_show_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.gemini_show_btn.clicked.connect(self._toggle_gemini_visibility)

        gm_input_row.addWidget(self.gemini_key_input, stretch=1)
        gm_input_row.addWidget(self.gemini_show_btn)
        gm_layout.addLayout(gm_input_row)

        # Actions row
        gm_btn_row = QHBoxLayout()
        gm_btn_row.setSpacing(10)

        self.gemini_test_btn = QPushButton("Test Gemini Connection", gemini_card)
        self.gemini_test_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.gemini_test_btn.clicked.connect(self._test_gemini_connection)

        self.gemini_save_btn = PrimaryButton("Save && Apply Gemini Key", parent=gemini_card)
        self.gemini_save_btn.clicked.connect(self._save_gemini_key)

        gm_btn_row.addWidget(self.gemini_test_btn)
        gm_btn_row.addStretch()
        gm_btn_row.addWidget(self.gemini_save_btn)
        gm_layout.addLayout(gm_btn_row)

        layout.addWidget(gemini_card)

        # 4. Model & Location Customization Card
        model_card = QFrame(content)
        model_card.setStyleSheet("background-color: #111828; border: 1px solid #1E2D4A; border-radius: 10px; padding: 12px;")
        m_layout = QVBoxLayout(model_card)
        m_layout.setContentsMargins(12, 10, 12, 10)
        m_layout.setSpacing(8)

        m_title = QLabel("MODEL ARCHITECTURE & LOCALIZATION", model_card)
        m_title.setStyleSheet("color: #38BDF8; font-size: 12px; font-weight: 800; letter-spacing: 0.8px;")
        m_layout.addWidget(m_title)

        # Primary Model
        p_row = QHBoxLayout()
        p_lbl2 = QLabel("Primary Reasoning Model:", model_card)
        p_lbl2.setFixedWidth(180)
        p_lbl2.setStyleSheet("color: #CBD5E1; font-size: 12px;")
        self.model_input = QLineEdit(config.ai_model, model_card)
        self.model_input.setStyleSheet("background-color: #0B101D; border: 1px solid #202F4F; color: #F8FAFC;")
        p_row.addWidget(p_lbl2)
        p_row.addWidget(self.model_input, stretch=1)
        m_layout.addLayout(p_row)

        # Fallback Model
        fb_row = QHBoxLayout()
        fb_lbl = QLabel("Fallback Reasoning Model:", model_card)
        fb_lbl.setFixedWidth(180)
        fb_lbl.setStyleSheet("color: #CBD5E1; font-size: 12px;")
        self.fallback_input = QLineEdit(config.ai_fallback_model, model_card)
        self.fallback_input.setStyleSheet("background-color: #0B101D; border: 1px solid #202F4F; color: #F8FAFC;")
        fb_row.addWidget(fb_lbl)
        fb_row.addWidget(self.fallback_input, stretch=1)
        m_layout.addLayout(fb_row)

        # Weather Location
        w_row = QHBoxLayout()
        w_lbl = QLabel("Default Weather City:", model_card)
        w_lbl.setFixedWidth(180)
        w_lbl.setStyleSheet("color: #CBD5E1; font-size: 12px;")
        self.weather_input = QLineEdit(config.weather_location, model_card)
        self.weather_input.setStyleSheet("background-color: #0B101D; border: 1px solid #202F4F; color: #F8FAFC;")
        w_row.addWidget(w_lbl)
        w_row.addWidget(self.weather_input, stretch=1)
        m_layout.addLayout(w_row)

        # Save model button
        m_btn_row = QHBoxLayout()
        m_save_btn = QPushButton("Save Model & Location Settings", model_card)
        m_save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        m_save_btn.clicked.connect(self._save_model_settings)
        m_btn_row.addStretch()
        m_btn_row.addWidget(m_save_btn)
        m_layout.addLayout(m_btn_row)

        layout.addWidget(model_card)

        # 5. Security Notice
        sec_card = QFrame(content)
        sec_card.setStyleSheet("background-color: #12192A; border: 1px solid #1E2D48; border-radius: 8px; padding: 12px;")
        sec_vbox = QVBoxLayout(sec_card)
        sec_vbox.setSpacing(6)

        sec_title = QLabel("WINDOWS CREDENTIAL VAULT ENCRYPTION", sec_card)
        sec_title.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 700; letter-spacing: 0.8px;")

        sec_desc = QLabel(
            "API keys are encrypted using Windows Credential Manager (DPAPI / WinVault). "
            "Secrets are never printed in console logs, never exposed in exception traces, "
            "and can be dynamically replaced at runtime without restarting the application.",
            sec_card
        )
        sec_desc.setWordWrap(True)
        sec_desc.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 16px;")

        sec_vbox.addWidget(sec_title)
        sec_vbox.addWidget(sec_desc)
        layout.addWidget(sec_card)
        layout.addStretch()

        scroll.setWidget(content)
        outer_layout = QVBoxLayout(widget)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.addWidget(scroll)
        return widget

    def _toggle_groq_visibility(self):
        if self.groq_key_input.echoMode() == QLineEdit.EchoMode.Password:
            self.groq_key_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.groq_show_btn.setText("Hide")
        else:
            self.groq_key_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.groq_show_btn.setText("Show")

    def _test_groq_connection(self):
        from backend.ai_provider import GroqProvider
        from backend.config import config
        key = self.groq_key_input.text().strip() or config.groq_api_key
        if not key:
            QMessageBox.warning(self, "Missing Key", "Please paste a Groq API key (gsk_...) or save one to test.")
            return

        self.groq_status_lbl.setText("● Testing...")
        self.groq_status_lbl.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700;")
        prov = GroqProvider()
        ok, msg = prov.test_connection(key)
        if ok:
            self.groq_status_lbl.setText("● Verified & Connected")
            self.groq_status_lbl.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 700;")
            QMessageBox.information(self, "Groq Connection Test", f"Success:\n{msg}")
        else:
            self.groq_status_lbl.setText("● Connection Failed")
            self.groq_status_lbl.setStyleSheet("color: #EF4444; font-size: 11px; font-weight: 700;")
            QMessageBox.critical(self, "Groq Connection Failed", f"Failed:\n{msg}")

    def _save_groq_key(self):
        from backend.config import config
        key = self.groq_key_input.text().strip()
        if not key:
            QMessageBox.warning(self, "Missing Key", "Please paste a Groq API key into the input field before saving.")
            return

        if not key.startswith("gsk_"):
            reply = QMessageBox.question(
                self,
                "API Key Format Notice",
                "Standard Groq API keys begin with 'gsk_'. Do you still wish to save this credential?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        config.set_secret("GROQ_API_KEY", key, save_to_env=True)
        # Clear the input field so raw key is NEVER displayed in cleartext
        self.groq_key_input.clear()
        self.groq_masked_lbl.setText(f"Active Vault Key: {config.mask_key(key)}")
        self.groq_status_lbl.setText("● Connected (Active)")
        self.groq_status_lbl.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 700;")
        self.groq_key_updated.emit()
        QMessageBox.information(
            self,
            "Credentials Encrypted & Saved",
            "Groq API Key has been encrypted into Windows Credential Vault and updated in .env.\n\n"
            "The key is protected and will not be displayed in plaintext."
        )

    def _clear_groq_key(self):
        from backend.config import config
        reply = QMessageBox.question(
            self,
            "Clear Groq Credentials",
            "Are you sure you want to remove the stored Groq API Key from this device?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            config.set_secret("GROQ_API_KEY", "", save_to_env=True)
            self.groq_key_input.clear()
            self.groq_masked_lbl.setText("Active Vault Key: Not Configured")
            self.groq_status_lbl.setText("● Key Not Set")
            self.groq_status_lbl.setStyleSheet("color: #F59E0B; font-size: 11px; font-weight: 700;")
            self.groq_key_updated.emit()

    def _toggle_gemini_visibility(self):
        if self.gemini_key_input.echoMode() == QLineEdit.EchoMode.Password:
            self.gemini_key_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.gemini_show_btn.setText("Hide")
        else:
            self.gemini_key_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.gemini_show_btn.setText("Show")

    def _test_gemini_connection(self):
        key = self.gemini_key_input.text().strip()
        if not key:
            QMessageBox.warning(self, "Missing Key", "Please enter a Gemini API key to test.")
            return

        self.gemini_status_lbl.setText("● Testing...")
        self.gemini_status_lbl.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700;")
        try:
            from google import genai
            client = genai.Client(api_key=key)
            self.gemini_status_lbl.setText("● Verified (Live Ready)")
            self.gemini_status_lbl.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 700;")
            QMessageBox.information(self, "Gemini Connection Test", "Gemini API Client initialized successfully.")
        except Exception as e:
            self.gemini_status_lbl.setText("● Test Failed")
            self.gemini_status_lbl.setStyleSheet("color: #EF4444; font-size: 11px; font-weight: 700;")
            QMessageBox.critical(self, "Gemini Connection Failed", f"Failed to connect: {e}")

    def _save_gemini_key(self):
        from backend.config import config
        key = self.gemini_key_input.text().strip()
        config.set_secret("GEMINI_API_KEY", key, save_to_env=True)
        self.gemini_status_lbl.setText("● Connected (Live Ready)" if key else "● Key Not Set")
        self.gemini_status_lbl.setStyleSheet(f"color: {'#10B981' if key else '#64748B'}; font-size: 11px; font-weight: 700;")
        QMessageBox.information(self, "Credentials Saved", "Gemini API Key saved securely to Windows Credential Vault and .env!")

    def _save_model_settings(self):
        from backend.config import config, set_key, ENV_PATH
        chosen_model = self.model_input.text().strip() or "llama-3.3-70b-versatile"
        fallback_model = self.fallback_input.text().strip() or "llama-3.1-8b-instant"
        weather_loc = self.weather_input.text().strip() or "New Delhi"

        config.set_model(chosen_model)
        config.ai_fallback_model = fallback_model
        config.weather_location = weather_loc

        try:
            if not ENV_PATH.exists():
                ENV_PATH.touch(mode=0o600)
            set_key(str(ENV_PATH), "GROQ_MODEL", chosen_model)
            set_key(str(ENV_PATH), "AI_MODEL", chosen_model)
            set_key(str(ENV_PATH), "AI_FALLBACK_MODEL", fallback_model)
            set_key(str(ENV_PATH), "WEATHER_LOCATION", weather_loc)
            self.groq_key_updated.emit()
            QMessageBox.information(self, "Settings Saved", f"Groq Model set to '{chosen_model}' and settings updated successfully!")
        except Exception as e:
            QMessageBox.warning(self, "Save Warning", f"Updated in memory, but could not update .env: {e}")

    def _build_privacy_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Principles checklist
        p1 = QCheckBox("Enforce strict local privacy sandbox (No unauthorized folder indexing)", widget)
        p1.setChecked(True)
        p1.setEnabled(False)

        p2 = QCheckBox("Require explicit confirmation dialog before executing system lock or destructive tasks", widget)
        p2.setChecked(True)

        p3 = QCheckBox("Keep all conversation history strictly local on device in JSON format", widget)
        p3.setChecked(True)
        p3.setEnabled(False)

        # Clear data button
        clear_row = QHBoxLayout()
        clear_desc = QLabel("Permanently purge local conversation history and cached telemetry:", widget)
        clear_desc.setStyleSheet("color: #94A3B8; font-size: 12px;")
        clear_btn = DangerButton("Purge All History", icon_name="trash", parent=widget)
        clear_btn.clicked.connect(self._confirm_clear_data)
        clear_row.addWidget(clear_desc)
        clear_row.addWidget(clear_btn)
        clear_row.addStretch()

        layout.addWidget(p1)
        layout.addWidget(p2)
        layout.addWidget(p3)
        layout.addLayout(clear_row)
        layout.addStretch()
        return widget

    def _build_shortcuts_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        table = QTableWidget(widget)
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Action", "Keybinding"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().setVisible(False)
        table.setStyleSheet("""
            QTableWidget {
                background-color: #0E1424;
                border: 1px solid #1C273E;
                border-radius: 8px;
                gridline-color: #1C273E;
            }
            QHeaderView::section {
                background-color: #141C30;
                color: #CBD5E1;
                font-weight: 700;
                padding: 6px;
                border: none;
            }
        """)

        shortcuts = [
            ("Send Message in Chat", "Enter"),
            ("New Line in Chat Input", "Shift + Enter"),
            ("Start New Conversation", "Ctrl + N"),
            ("Toggle Left Sidebar", "Ctrl + B"),
            ("Toggle Right Telemetry Panel", "Ctrl + T"),
            ("Switch to Dashboard", "Ctrl + 1"),
            ("Switch to Chat Assistant", "Ctrl + 2"),
            ("Switch to Live Voice Mode", "Ctrl + 3"),
            ("Switch to Quick Actions", "Ctrl + 4"),
            ("Cancel / Stop Generation", "Escape"),
        ]

        table.setRowCount(len(shortcuts))
        for row, (action, key) in enumerate(shortcuts):
            it_a = QTableWidgetItem(action)
            it_a.setForeground(Qt.GlobalColor.white)
            it_k = QTableWidgetItem(key)
            it_k.setForeground(QColor(Palette.ACCENT_CYAN))
            table.setItem(row, 0, it_a)
            table.setItem(row, 1, it_k)

        layout.addWidget(table)
        return widget

    def _build_about_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        logo_lbl = QLabel(widget)
        logo_lbl.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=48))
        logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title_lbl = QLabel("JARVIS AI DESKTOP ASSISTANT", widget)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 18px; font-weight: 800; letter-spacing: 1.5px;")
        title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        ver_lbl = QLabel("Version 2.4.0 • College Project Expo Demonstration Edition", widget)
        ver_lbl.setStyleSheet("color: #00E5FF; font-size: 12px; font-weight: 600;")
        ver_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        about_text = QLabel(
            "An enterprise-grade, privacy-first desktop intelligent assistant engineered with Python 3.14 "
            "and PySide6. Features an animated neural voice orb, dynamic audio spectrum analysis, real-time "
            "hardware telemetry polling, application workflow dispatching, and asynchronous background worker threads.\n\n"
            "• Technology: Python 3.14, PySide6 (Qt 6.12), psutil\n"
            "• Architecture: Decoupled Signal-Driven Asynchronous UI\n"
            "• Designed for: Next-Generation Human-Computer Collaboration",
            widget
        )
        about_text.setWordWrap(True)
        about_text.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 18px; padding: 12px;")

        layout.addWidget(logo_lbl)
        layout.addWidget(title_lbl)
        layout.addWidget(ver_lbl)
        layout.addWidget(about_text)
        layout.addStretch()
        return widget

    def _confirm_clear_data(self):
        reply = QMessageBox.question(
            self,
            "Confirm Data Purge",
            "Are you sure you want to delete all saved conversations? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.clear_all_data_requested.emit()
