"""
JARVIS AI — Collapsible Right System Information Panel
Houses real-time Digital Clock, Weather Service Card (with explicit integration status),
Laptop Performance Gauges (live CPU, RAM, Disk, Battery via psutil),
and System Status Subsystem Indicators.
"""

from datetime import datetime
from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QScrollArea, QPushButton, QProgressBar, QSlider
)
from PySide6.QtCore import Qt, Signal, QTimer, QSize
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.cards import TelemetryCard
from components.metric_gauge import CircularGaugeWidget, BarGaugeWidget
from components.status_indicator import GlowingDot, StatusIndicatorWidget
from components.buttons import IconButton
from services.frontend_interfaces import SystemMetrics, WeatherData
from backend.windows_hardware import WindowsHardwareController

class SystemPanelWidget(QWidget):
    toggle_collapse_requested = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("systemPanel")
        self.setFixedWidth(290)
        self._is_collapsed = False
        self.hardware = WindowsHardwareController(self)

        self._clock_timer = QTimer(self)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start(1000)

        self._init_ui()
        self._update_clock()
        QTimer.singleShot(150, self._refresh_hardware_state)

    def _init_ui(self):
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(12, 14, 12, 14)
        self.main_layout.setSpacing(12)

        # 1. Header Bar with Collapse Button
        header_row = QHBoxLayout()
        header_row.setSpacing(8)

        self.panel_title = QLabel("SYSTEM TELEMETRY", self)
        self.panel_title.setStyleSheet("color: #F8FAFC; font-size: 13px; font-weight: 800; letter-spacing: 1.2px;")

        self.collapse_btn = IconButton("panel_toggle", tooltip="Collapse Information Panel", size=28, parent=self)
        self.collapse_btn.clicked.connect(self.toggle_collapse_requested.emit)

        header_row.addWidget(self.panel_title, stretch=1)
        header_row.addWidget(self.collapse_btn)
        self.main_layout.addLayout(header_row)

        # 2. Scrollable Body
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.body_widget = QWidget()
        self.body_layout = QVBoxLayout(self.body_widget)
        self.body_layout.setContentsMargins(0, 0, 4, 0)
        self.body_layout.setSpacing(12)

        # --- CARD 1: Date & Time ---
        self.clock_card = TelemetryCard("clock", "Date & Time", parent=self.body_widget)
        clock_vbox = QVBoxLayout()
        clock_vbox.setSpacing(2)

        self.time_lbl = QLabel("12:00:00 AM", self.clock_card)
        self.time_lbl.setStyleSheet("color: #00E5FF; font-size: 24px; font-weight: 800; font-family: Consolas, monospace;")

        self.date_lbl = QLabel("Loading Date...", self.clock_card)
        self.date_lbl.setStyleSheet("color: #CBD5E1; font-size: 12px; font-weight: 600;")

        self.day_lbl = QLabel("Day of Week", self.clock_card)
        self.day_lbl.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 500;")

        clock_vbox.addWidget(self.time_lbl)
        clock_vbox.addWidget(self.date_lbl)
        clock_vbox.addWidget(self.day_lbl)
        self.clock_card.add_layout(clock_vbox)
        self.body_layout.addWidget(self.clock_card)

        # --- CARD 2: Weather (Clear unavailable/awaiting provider state) ---
        self.weather_card = TelemetryCard("weather", "Weather Telemetry", parent=self.body_widget)
        weather_vbox = QVBoxLayout()
        weather_vbox.setSpacing(6)

        weather_status_row = QHBoxLayout()
        self.w_dot = GlowingDot("#F59E0B", size=8, parent=self.weather_card)
        self.w_status = QLabel("Service Pending Integration", self.weather_card)
        self.w_status.setStyleSheet("color: #F59E0B; font-size: 10px; font-weight: 700; letter-spacing: 0.5px;")
        weather_status_row.addWidget(self.w_dot)
        weather_status_row.addWidget(self.w_status)
        weather_status_row.addStretch()

        self.weather_desc = QLabel("Weather API key not configured.\nAwaiting weather service provider.", self.weather_card)
        self.weather_desc.setStyleSheet("color: #94A3B8; font-size: 11px; line-height: 15px;")

        weather_vbox.addLayout(weather_status_row)
        weather_vbox.addWidget(self.weather_desc)
        self.weather_card.add_layout(weather_vbox)
        self.body_layout.addWidget(self.weather_card)

        # --- CARD 3: Laptop Performance (psutil live data) ---
        self.perf_card = TelemetryCard("cpu", "Laptop Performance", parent=self.body_widget)
        perf_vbox = QVBoxLayout()
        perf_vbox.setSpacing(10)

        # CPU bar
        self.cpu_bar = BarGaugeWidget("CPU Load", height=38, parent=self.perf_card)
        # RAM bar
        self.ram_bar = BarGaugeWidget("RAM Usage", height=38, parent=self.perf_card)
        # Disk bar
        self.disk_bar = BarGaugeWidget("Disk (C:)", height=38, parent=self.perf_card)

        # Battery status row
        batt_row = QHBoxLayout()
        batt_row.setSpacing(8)

        self.batt_icon = QLabel(self.perf_card)
        self.batt_icon.setPixmap(get_pixmap("battery", color=Palette.ACCENT_CYAN, size=18))

        batt_vbox = QVBoxLayout()
        batt_vbox.setSpacing(1)
        self.batt_lbl = QLabel("Battery: 100% (AC Powered)", self.perf_card)
        self.batt_lbl.setStyleSheet("color: #F8FAFC; font-size: 11px; font-weight: 600;")
        self.batt_sub = QLabel("Power Status: Nominal", self.perf_card)
        self.batt_sub.setStyleSheet("color: #94A3B8; font-size: 10px;")
        batt_vbox.addWidget(self.batt_lbl)
        batt_vbox.addWidget(self.batt_sub)

        batt_row.addWidget(self.batt_icon)
        batt_row.addLayout(batt_vbox)
        batt_row.addStretch()

        perf_vbox.addWidget(self.cpu_bar)
        perf_vbox.addWidget(self.ram_bar)
        perf_vbox.addWidget(self.disk_bar)
        perf_vbox.addLayout(batt_row)

        self.perf_card.add_layout(perf_vbox)
        self.body_layout.addWidget(self.perf_card)

        # --- CARD 4: Real Windows Hardware Controls (Volume & Brightness) ---
        self.hardware_card = TelemetryCard("settings", "Hardware Controls", parent=self.body_widget)
        hw_vbox = QVBoxLayout()
        hw_vbox.setSpacing(10)

        # 1. Master Volume Control
        vol_header = QHBoxLayout()
        vol_icon = QLabel(self.hardware_card)
        vol_icon.setPixmap(get_pixmap("volume", color=Palette.ACCENT_CYAN, size=16))
        vol_lbl = QLabel("Master Volume", self.hardware_card)
        vol_lbl.setStyleSheet("color: #E2E8F0; font-size: 11px; font-weight: 700;")
        self.vol_pct_lbl = QLabel("68%", self.hardware_card)
        self.vol_pct_lbl.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: 800; font-family: Consolas, monospace;")
        vol_header.addWidget(vol_icon)
        vol_header.addWidget(vol_lbl)
        vol_header.addStretch()
        vol_header.addWidget(self.vol_pct_lbl)

        self.vol_slider = QSlider(Qt.Orientation.Horizontal, self.hardware_card)
        self.vol_slider.setRange(0, 100)
        self.vol_slider.setValue(68)
        self.vol_slider.setStyleSheet("""
            QSlider::groove:horizontal { height: 6px; background: #1C273E; border-radius: 3px; }
            QSlider::sub-page:horizontal { background: #00E5FF; border-radius: 3px; }
            QSlider::handle:horizontal { background: #F8FAFC; border: 1px solid #00E5FF; width: 14px; margin-top: -4px; margin-bottom: -4px; border-radius: 7px; }
        """)
        self.vol_slider.sliderMoved.connect(self._on_vol_slider_moved)

        self.mute_btn = QPushButton("Mute", self.hardware_card)
        self.mute_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.mute_btn.setStyleSheet("""
            QPushButton { background-color: #12192A; color: #94A3B8; border: 1px solid #1C273E; border-radius: 6px; padding: 4px 8px; font-size: 10px; font-weight: 600; }
            QPushButton:hover { background-color: #1C273E; color: #F8FAFC; border-color: #00E5FF; }
        """)
        self.mute_btn.clicked.connect(self._toggle_mute)

        self.device_lbl = QLabel("Output: Loading...", self.hardware_card)
        self.device_lbl.setStyleSheet("color: #64748B; font-size: 9px;")
        self.device_lbl.setWordWrap(True)

        hw_vbox.addLayout(vol_header)
        hw_vbox.addWidget(self.vol_slider)
        vol_btn_row = QHBoxLayout()
        vol_btn_row.addWidget(self.device_lbl, stretch=1)
        vol_btn_row.addWidget(self.mute_btn)
        hw_vbox.addLayout(vol_btn_row)

        # 2. Display Brightness Control
        bright_header = QHBoxLayout()
        bright_icon = QLabel(self.hardware_card)
        bright_icon.setPixmap(get_pixmap("sun", color="#F59E0B", size=16))
        bright_lbl = QLabel("Display Brightness", self.hardware_card)
        bright_lbl.setStyleSheet("color: #E2E8F0; font-size: 11px; font-weight: 700;")
        self.bright_pct_lbl = QLabel("50%", self.hardware_card)
        self.bright_pct_lbl.setStyleSheet("color: #F59E0B; font-size: 11px; font-weight: 800; font-family: Consolas, monospace;")
        bright_header.addWidget(bright_icon)
        bright_header.addWidget(bright_lbl)
        bright_header.addStretch()
        bright_header.addWidget(self.bright_pct_lbl)

        self.bright_slider = QSlider(Qt.Orientation.Horizontal, self.hardware_card)
        self.bright_slider.setRange(0, 100)
        self.bright_slider.setValue(50)
        self.bright_slider.setStyleSheet("""
            QSlider::groove:horizontal { height: 6px; background: #1C273E; border-radius: 3px; }
            QSlider::sub-page:horizontal { background: #F59E0B; border-radius: 3px; }
            QSlider::handle:horizontal { background: #F8FAFC; border: 1px solid #F59E0B; width: 14px; margin-top: -4px; margin-bottom: -4px; border-radius: 7px; }
        """)
        self.bright_slider.sliderMoved.connect(self._on_bright_slider_moved)

        hw_vbox.addLayout(bright_header)
        hw_vbox.addWidget(self.bright_slider)

        self.hardware_card.add_layout(hw_vbox)
        self.body_layout.addWidget(self.hardware_card)

        # --- CARD 5: System Status Subsystems ---
        self.status_card = TelemetryCard("network", "System Status", parent=self.body_widget)
        status_vbox = QVBoxLayout()
        status_vbox.setSpacing(8)

        self.net_status = StatusIndicatorWidget("Internet: Online", "#10B981", parent=self.status_card)
        self.ai_status = StatusIndicatorWidget("AI Engine: Ready for Key", "#F59E0B", parent=self.status_card)
        self.mic_status = StatusIndicatorWidget("Microphone: Connected", "#10B981", parent=self.status_card)
        self.spk_status = StatusIndicatorWidget("Audio Output: Connected", "#10B981", parent=self.status_card)
        self.backend_status = StatusIndicatorWidget("Backend: Local Mode", "#00E5FF", parent=self.status_card)

        status_vbox.addWidget(self.net_status)
        status_vbox.addWidget(self.ai_status)
        status_vbox.addWidget(self.mic_status)
        status_vbox.addWidget(self.spk_status)
        status_vbox.addWidget(self.backend_status)

        self.status_card.add_layout(status_vbox)
        self.body_layout.addWidget(self.status_card)

        self.body_layout.addStretch()
        self.scroll.setWidget(self.body_widget)
        self.main_layout.addWidget(self.scroll, stretch=1)

    def _update_clock(self):
        now = datetime.now()
        self.time_lbl.setText(now.strftime("%I:%M:%S %p"))
        self.date_lbl.setText(now.strftime("%B %d, %Y"))
        self.day_lbl.setText(now.strftime("%A • Local Time"))

    def update_metrics(self, m: SystemMetrics):
        self.cpu_bar.set_value(m.cpu_percent, f"{m.cpu_percent:.1f}%")
        self.ram_bar.set_value(m.ram_percent, f"{m.ram_used_gb} / {m.ram_total_gb} GB ({m.ram_percent:.1f}%)")
        self.disk_bar.set_value(m.disk_percent, f"{m.disk_percent:.1f}%")

        charging_str = "Charging" if m.is_charging else "On Battery"
        self.batt_lbl.setText(f"Battery: {m.battery_percent}% ({charging_str})")
        self.batt_sub.setText(f"State: {m.battery_health}")

        # Update indicators
        if m.network_online:
            self.net_status.set_status("Internet: Online", "#10B981")
        else:
            self.net_status.set_status("Internet: Offline", "#EF4444")

        self.mic_status.set_status("Microphone: Available" if m.mic_available else "Microphone: Missing", "#10B981" if m.mic_available else "#EF4444")
        self.spk_status.set_status("Audio Output: Ready" if m.speaker_available else "Audio Output: Missing", "#10B981" if m.speaker_available else "#EF4444")

    def update_weather(self, data: WeatherData):
        if data and data.is_connected:
            self.w_dot.set_color("#10B981")
            self.w_status.setText("Live (Open-Meteo)")
            self.w_status.setStyleSheet("color: #10B981; font-size: 10px; font-weight: 700; letter-spacing: 0.5px;")
            self.weather_desc.setText(
                f"{data.temperature_c:.1f}°C • {data.condition}\n"
                f"{data.location}\n"
                f"Humidity: {data.humidity_percent}% | Wind: {data.wind_speed_kmh} km/h"
            )
            self.weather_desc.setStyleSheet("color: #F8FAFC; font-size: 12px; font-weight: 500; line-height: 16px;")

    def update_health_status(self, res: dict):
        if res.get("internet"):
            self.net_status.set_status("Internet: Online", "#10B981")
        else:
            self.net_status.set_status("Internet: Offline", "#EF4444")

        if res.get("groq"):
            self.ai_status.set_status("AI Engine: Groq Ready", "#10B981")
        else:
            self.ai_status.set_status("AI Engine: Groq Key Needed", "#F59E0B")

        self.mic_status.set_status("Microphone: Available" if res.get("microphone") else "Microphone: Missing", "#10B981" if res.get("microphone") else "#EF4444")
        self.spk_status.set_status("Audio Output: Ready" if res.get("speaker") else "Audio Output: Missing", "#10B981" if res.get("speaker") else "#EF4444")

    def _refresh_hardware_state(self):
        """Polls current Windows OS volume and display brightness."""
        try:
            ok_v, v_pct, is_muted, dev_name = self.hardware.get_volume()
            if ok_v:
                self.vol_slider.blockSignals(True)
                self.vol_slider.setValue(v_pct)
                self.vol_slider.blockSignals(False)
                self.vol_pct_lbl.setText(f"{v_pct}%")
                short_name = dev_name[:24] + "..." if len(dev_name) > 24 else dev_name
                self.device_lbl.setText(f"Output: {short_name}")
                self.mute_btn.setText("Unmute" if is_muted else "Mute")
                if is_muted:
                    self.mute_btn.setStyleSheet("background-color: rgba(239, 68, 68, 0.2); color: #EF4444; border: 1px solid #EF4444; border-radius: 6px; padding: 4px 8px; font-size: 10px; font-weight: 700;")
                else:
                    self.mute_btn.setStyleSheet("background-color: #12192A; color: #94A3B8; border: 1px solid #1C273E; border-radius: 6px; padding: 4px 8px; font-size: 10px; font-weight: 600;")
        except Exception:
            pass

        try:
            ok_b, b_pct, _ = self.hardware.get_brightness()
            if ok_b:
                self.bright_slider.blockSignals(True)
                self.bright_slider.setValue(b_pct)
                self.bright_slider.blockSignals(False)
                self.bright_pct_lbl.setText(f"{b_pct}%")
        except Exception:
            pass

    def _on_vol_slider_moved(self, val: int):
        self.vol_pct_lbl.setText(f"{val}%")
        self.hardware.set_volume(val)

    def _on_bright_slider_moved(self, val: int):
        self.bright_pct_lbl.setText(f"{val}%")
        self.hardware.set_brightness(val)

    def _toggle_mute(self):
        self.hardware.toggle_mute()
        self._refresh_hardware_state()

    def toggle_collapse(self):
        self._is_collapsed = not self._is_collapsed
        if self._is_collapsed:
            self.setFixedWidth(50)
            self.panel_title.hide()
            self.scroll.hide()
        else:
            self.setFixedWidth(290)
            self.panel_title.show()
            self.scroll.show()
