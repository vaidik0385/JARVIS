"""
JARVIS AI — Master Desktop Application Window
Coordinates the 3-panel architecture: Collapsible Left Sidebar,
Central Dynamic View Stack (Dashboard, Chat, Voice, Quick Actions, Settings),
and Collapsible Right Information Panel.
Fully integrates the real AI Engine (Groq), Whisper STT, pyttsx3 TTS,
Open-Meteo Weather, SQLite database, and safe Windows automation registry.
"""

from datetime import datetime
from typing import Optional
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QStackedWidget, QApplication, QMessageBox
)
from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QKeySequence, QIcon, QShortcut

from styles.palette import Palette
from styles.icons import get_icon
from frontend.sidebar import SidebarWidget
from frontend.chat_view import ChatView
from frontend.dashboard_view import DashboardView
from frontend.voice_view import VoiceView
from frontend.quick_actions_view import QuickActionsView
from frontend.system_panel import SystemPanelWidget
from frontend.settings_view import SettingsView
from frontend.dialogs import ActionConfirmationDialog, AboutDialog

# Backend Services
from backend.config import config
from backend.database import db
from backend.ai_engine import AIEngine
from backend.application_launcher import ApplicationLauncher
from backend.tool_router import ToolRouter
from backend.search_service import WebSearchService
from backend.crypto_service import CryptoMarketService
from backend.stock_service import StockMarketService
from backend.speech_to_text import SpeechToTextService
from backend.text_to_speech import TextToSpeechService
from backend.live_voice import LiveVoiceManager
from backend.weather_service import WeatherService
from backend.connection_manager import ConnectionManager
from backend.system_monitor import SystemMonitorWorker, ExtendedSystemMetrics
from services.conversation_manager import ConversationManager
from services.frontend_interfaces import ChatMessage, SystemMetrics

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("JARVIS AI — Advanced Desktop Assistant")
        self.setMinimumSize(960, 600)
        self.setWindowIcon(get_icon("logo", color=Palette.ACCENT_CYAN, size=32))

        # Adapt initial window dimensions to primary display
        screen = QApplication.primaryScreen()
        if screen:
            avail = screen.availableGeometry()
            target_w = min(1260, max(960, int(avail.width() * 0.88)))
            target_h = min(780, max(600, int(avail.height() * 0.88)))
            self.resize(target_w, target_h)
            x = avail.x() + (avail.width() - target_w) // 2
            y = avail.y() + (avail.height() - target_h) // 2
            self.move(x, y)
        else:
            self.resize(1200, 750)

        # 1. Initialize Real Backend Services
        self.conv_manager = ConversationManager(db)
        self.app_launcher = ApplicationLauncher(self)
        self.weather_service = WeatherService(self)
        self.search_service = WebSearchService(self)
        self.crypto_service = CryptoMarketService(self)
        self.stock_service = StockMarketService(self)
        self.tool_router = ToolRouter(
            launcher=self.app_launcher,
            search_service=self.search_service,
            crypto_service=self.crypto_service,
            stock_service=self.stock_service,
            weather_service=self.weather_service,
            parent=self
        )
        self.ai_engine = AIEngine(tool_router=self.tool_router, parent=self)
        self.stt_service = SpeechToTextService(self)
        self.tts_service = TextToSpeechService(self)
        self.live_voice = LiveVoiceManager(self.tts_service, self.tool_router, self)
        self.conn_manager = ConnectionManager(self)
        self.monitor_worker = SystemMonitorWorker(poll_interval_ms=2000, parent=self)

        # 2. State Tracking
        self.active_cid = None
        self._active_streaming_text = ""
        self._latest_telemetry: Optional[ExtendedSystemMetrics] = None
        self._latest_weather_str = ""
        self._latest_telemetry_str = ""

        # 3. Build UI
        self._init_ui()
        self._setup_shortcuts()
        self._connect_signals()

        # 4. Defer background services & health monitoring so GUI opens instantly
        QTimer.singleShot(50, self._start_background_services)

    def _start_background_services(self):
        """Asynchronously triggers telemetry, weather, and connection health."""
        try:
            self.monitor_worker.start()
        except Exception as e:
            print(f"[Warning] Monitor start error: {e}")

        try:
            self.weather_service.refresh()
        except Exception as e:
            print(f"[Warning] Weather refresh error: {e}")

        try:
            self.conn_manager.check_health()
        except Exception as e:
            print(f"[Warning] Health check error: {e}")

        # Health check timer (every 25s)
        self.health_timer = QTimer(self)
        self.health_timer.timeout.connect(self.conn_manager.check_health)
        self.health_timer.start(25000)

        # Weather refresh timer (every 10 minutes)
        self.weather_timer = QTimer(self)
        self.weather_timer.timeout.connect(self.weather_service.refresh)
        self.weather_timer.start(600000)

        # Load initial telemetry & conversations
        try:
            initial_m = self.monitor_worker._gather_metrics()
            self._on_metrics_updated(initial_m)
        except Exception as e:
            print(f"[Warning] Initial metrics load error: {e}")

        try:
            self._reload_conversations()
        except Exception as e:
            print(f"[Warning] Initial conversations load error: {e}")

    def _init_ui(self):
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        root_layout = QHBoxLayout(central_widget)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # Panel A: Left Sidebar
        self.sidebar = SidebarWidget(self)

        # Panel B: Central Stacked Views
        self.view_stack = QStackedWidget(self)
        self.view_stack.setObjectName("centralStack")

        # 0: Dashboard View
        self.dashboard_view = DashboardView(self)
        self.view_stack.addWidget(self.dashboard_view)

        # 1: Chat Assistant View
        self.chat_view = ChatView(self)
        self.view_stack.addWidget(self.chat_view)

        # 2: Live Voice View
        self.voice_view = VoiceView(self)
        self.view_stack.addWidget(self.voice_view)

        # 3: Quick Actions View
        self.quick_actions_view = QuickActionsView(self.app_launcher, self)
        self.view_stack.addWidget(self.quick_actions_view)

        # 4: Settings View
        self.settings_view = SettingsView(self)
        self.view_stack.addWidget(self.settings_view)

        # Panel C: Right Information Panel
        self.system_panel = SystemPanelWidget(self)

        # Assemble Panels
        root_layout.addWidget(self.sidebar)
        root_layout.addWidget(self.view_stack, stretch=1)
        root_layout.addWidget(self.system_panel)

    def _connect_signals(self):
        # Sidebar Navigation
        self.sidebar.navigation_changed.connect(self._on_navigation_changed)
        self.sidebar.new_chat_requested.connect(self._create_new_chat)
        self.sidebar.conversation_selected.connect(self._load_conversation)
        self.sidebar.conversation_deleted.connect(self._delete_conversation)
        self.sidebar.search_query_changed.connect(self._filter_conversations)
        self.sidebar.toggle_collapse_requested.connect(self.sidebar.toggle_collapse)

        # Right Panel Toggle
        self.system_panel.toggle_collapse_requested.connect(self.system_panel.toggle_collapse)

        # Dashboard View Signals
        self.dashboard_view.switch_view_requested.connect(self._on_navigation_changed)
        self.dashboard_view.prompt_submitted.connect(self._on_dashboard_prompt)

        # Chat View Signals
        self.chat_view.user_sent_message.connect(self._on_user_sent_message)
        self.chat_view.clear_conversation_requested.connect(self._clear_current_conversation)
        self.chat_view.regenerate_last_requested.connect(self._regenerate_last_response)
        self.chat_view.switch_view_requested.connect(self._on_navigation_changed)
        self.chat_view.stop_generation_requested.connect(self.ai_engine.stop_generation)

        # Mode A Voice Dictation Signals
        self.chat_view.chat_input.voice_dictation_requested.connect(self._on_dictation_toggle)
        self.stt_service.transcription_completed.connect(self._on_transcription_ready)
        self.stt_service.transcription_error.connect(self._on_transcription_error)
        self.stt_service.audio_level_updated.connect(self._on_dictation_audio_level)

        # AI Engine Signals
        self.ai_engine.chunk_received.connect(self._on_ai_chunk)
        self.ai_engine.response_completed.connect(self._on_ai_completed)
        self.ai_engine.error_occurred.connect(self._on_ai_error)

        # Mode B Live Voice Signals
        self.voice_view.session_closed.connect(lambda: self._on_navigation_changed("dashboard"))
        self.voice_view.mic_toggled.connect(lambda muted: self.live_voice.toggle_mute())
        self.voice_view.interrupted.connect(self.live_voice.interrupt)
        self.live_voice.state_changed.connect(self.voice_view.set_state)
        self.live_voice.amplitude_updated.connect(self.voice_view.orb.set_amplitude)
        self.live_voice.amplitude_updated.connect(self.voice_view.waveform.set_amplitude)
        self.live_voice.transcript_received.connect(self.voice_view.set_transcript)

        # Hardware Telemetry & Services
        self.monitor_worker.metrics_ready.connect(self._on_metrics_updated)
        self.weather_service.weather_updated.connect(self._on_weather_updated)
        self.conn_manager.status_updated.connect(self.system_panel.update_health_status)

        # Hardware Volume & Brightness Sync
        if hasattr(self.tool_router, "hardware"):
            self.tool_router.hardware.volume_changed.connect(lambda *_: self.system_panel._refresh_hardware_state())
            self.tool_router.hardware.brightness_changed.connect(lambda *_: self.system_panel._refresh_hardware_state())

        # App Launcher Confirmation
        self.app_launcher.confirmation_requested.connect(self._show_confirmation_dialog)

        # Settings View Signals
        self.settings_view.clear_all_data_requested.connect(self._purge_all_conversations)
        self.settings_view.groq_key_updated.connect(self._on_groq_key_updated)

    def _setup_shortcuts(self):
        QShortcut(QKeySequence("Ctrl+N"), self, self._create_new_chat)
        QShortcut(QKeySequence("Ctrl+B"), self, self.sidebar.toggle_collapse)
        QShortcut(QKeySequence("Ctrl+T"), self, self.system_panel.toggle_collapse)
        QShortcut(QKeySequence("Ctrl+1"), self, lambda: self._on_navigation_changed("dashboard"))
        QShortcut(QKeySequence("Ctrl+2"), self, lambda: self._on_navigation_changed("chat"))
        QShortcut(QKeySequence("Ctrl+3"), self, lambda: self._on_navigation_changed("voice"))
        QShortcut(QKeySequence("Ctrl+4"), self, lambda: self._on_navigation_changed("actions"))
        QShortcut(QKeySequence("Ctrl+,"), self, lambda: self._on_navigation_changed("settings"))
        QShortcut(QKeySequence("Escape"), self, self.ai_engine.stop_generation)
        QShortcut(QKeySequence("F11"), self, self._toggle_fullscreen)

    def _on_navigation_changed(self, nav_id: str):
        # Stop live voice if navigating away from voice view
        if nav_id != "voice" and self.live_voice.is_active():
            self.live_voice.stop_session()

        self.sidebar.set_active_nav(nav_id)
        if nav_id == "dashboard":
            self.view_stack.setCurrentIndex(0)
        elif nav_id == "chat":
            self.view_stack.setCurrentIndex(1)
            if not self.active_cid:
                convs = self.conv_manager.get_all_conversations()
                if convs:
                    self._load_conversation(convs[0].id)
                else:
                    self._create_new_chat()
        elif nav_id == "voice":
            self.view_stack.setCurrentIndex(2)
            self.live_voice.start_session()
        elif nav_id == "actions":
            self.view_stack.setCurrentIndex(3)
        elif nav_id == "settings":
            self.view_stack.setCurrentIndex(4)
        elif nav_id == "about":
            dlg = AboutDialog(self)
            dlg.exec()

    def _reload_conversations(self):
        convs = self.conv_manager.get_all_conversations()
        self.sidebar.set_conversations(convs, active_id=self.active_cid)

    def _create_new_chat(self):
        cid = self.conv_manager.create_conversation("New Conversation")
        self.active_cid = cid
        self._reload_conversations()
        self._load_conversation(cid)
        self._on_navigation_changed("chat")

    def _load_conversation(self, cid: str):
        self.active_cid = cid
        messages = self.conv_manager.get_conversation_messages(cid)

        title = "Conversation"
        for c in self.conv_manager.get_all_conversations():
            if c.id == cid:
                title = c.title
                break

        self.chat_view.load_messages(messages, title=f"JARVIS Core v2.4 • {title}")
        self._reload_conversations()
        if self.view_stack.currentIndex() != 1:
            self._on_navigation_changed("chat")

    def _delete_conversation(self, cid: str):
        self.conv_manager.delete_conversation(cid)
        if self.active_cid == cid:
            self.active_cid = None
            convs = self.conv_manager.get_all_conversations()
            if convs:
                self._load_conversation(convs[0].id)
            else:
                self.chat_view.load_messages([])
        self._reload_conversations()

    def _clear_current_conversation(self):
        if self.active_cid:
            self.conv_manager.clear_messages(self.active_cid)
            self._load_conversation(self.active_cid)

    def _filter_conversations(self, query: str):
        results = self.conv_manager.search_conversations(query)
        self.sidebar.set_conversations(results, active_id=self.active_cid)

    def _on_user_sent_message(self, text: str):
        if not self.active_cid:
            self.active_cid = self.conv_manager.create_conversation("New Conversation")

        # 1. Save and display user message
        user_msg = self.conv_manager.add_message(self.active_cid, role="user", content=text)
        self.chat_view.add_message(user_msg)
        self._reload_conversations()

        # 2. Fast local intent matching (English, Hindi, Hinglish) for desktop automation
        direct_tool_result = self.tool_router.try_direct_intent(text)
        if direct_tool_result is not None:
            success, msg = direct_tool_result
            status_tag = "SUCCESS" if success else "FAILED"
            resp = (
                f"**System Dispatcher Result:**\n\n"
                f"- **Action**: `{status_tag}`\n"
                f"- **Details**: {msg}\n\n"
                f"```bash\n# Real-time operation executed locally\nEXEC_STATUS: {status_tag}\n```"
            )
            asst_msg = self.conv_manager.add_message(self.active_cid, role="assistant", content=resp)
            self.chat_view.add_message(asst_msg)
            self._reload_conversations()
            self.tts_service.speak(msg)
            return

        # 3. Check for Groq API Key configuration
        if not config.is_groq_configured():
            guide_resp = (
                "**Groq Cloud API Key Required**\n\n"
                "To enable fast AI conversations, please provide your Groq API key:\n\n"
                "1. Open **Settings -> AI Provider** (or press `Ctrl+,`).\n"
                "2. Paste your key in the **Groq Cloud API Credentials** field.\n"
                "3. Click **Save & Apply Groq Key**.\n\n"
                "*Tip: You can get a free instant API key from [Groq Console](https://console.groq.com/keys). "
                "Local application controls and system telemetry remain fully functional.*"
            )
            asst_msg = self.conv_manager.add_message(self.active_cid, role="assistant", content=guide_resp)
            self.chat_view.add_message(asst_msg)
            self._reload_conversations()
            return

        # 4. Initiate real-time streaming AI conversation via Groq
        self._active_streaming_text = ""
        self.chat_view.set_generating(True)
        self.chat_view.start_stream_message(datetime.now().strftime("%I:%M %p"))

        # Build telemetry context for AI awareness
        telemetry_ctx = ""
        if self._latest_telemetry:
            m = self._latest_telemetry
            telemetry_ctx = (
                f"OS: {m.os_name} | CPU: {m.cpu_percent}% ({m.cpu_cores_physical} cores) | "
                f"RAM: {m.ram_used_gb}/{m.ram_total_gb} GB ({m.ram_percent}%) | "
                f"Battery: {m.battery_percent}% ({m.battery_health}) | Uptime: {m.uptime_str}"
            )

        history = self.conv_manager.get_conversation_messages(self.active_cid)[:-1]
        self.ai_engine.send_prompt(
            prompt=text,
            conversation_history=history,
            system_context=telemetry_ctx,
            tools=self.tool_router.get_tool_definitions()
        )

    def _on_ai_chunk(self, chunk: str):
        self._active_streaming_text += chunk
        self.chat_view.append_stream_chunk(chunk)

    def _on_ai_completed(self, full_text: str):
        self.chat_view.finalize_stream(full_text)
        if self.active_cid:
            self.conv_manager.add_message(self.active_cid, role="assistant", content=full_text)
            self._reload_conversations()
        # Voice output
        self.tts_service.speak(full_text)

    def _on_ai_error(self, err: str):
        self.chat_view.set_generating(False)
        self.chat_view.update_connection_status("Groq Error", is_error=True)
        err_msg = f"**AI Engine Error:** {err}\n\n*Click **Regenerate** below to retry this query.*"
        self.chat_view.finalize_stream(err_msg)
        if self.active_cid:
            self.conv_manager.add_message(self.active_cid, role="assistant", content=err_msg)
            self._reload_conversations()

    def _on_groq_key_updated(self):
        config.reload()
        self.chat_view.update_connection_status()
        self.conn_manager.check_health()

    # --- Mode A Voice Dictation Handlers ---
    def _on_dictation_toggle(self, is_recording: bool):
        if is_recording:
            self.stt_service.start_recording()
        else:
            self.stt_service.stop_recording()

    def _on_dictation_audio_level(self, level: float):
        # Update dashboard waveform if visible
        if self.view_stack.currentIndex() == 0:
            self.dashboard_view.waveform.set_amplitude(level)

    def _on_transcription_ready(self, transcript: str):
        self.chat_view.chat_input.set_text(transcript)

    def _on_transcription_error(self, err: str):
        QMessageBox.warning(self, "Voice Dictation", f"Speech recognition notice:\n{err}")

    # --- Mode B Live Voice Handlers ---
    def _on_live_voice_closed(self):
        self.live_voice.stop_session()
        self._on_navigation_changed("dashboard")

    def _on_dashboard_prompt(self, text: str):
        t_lower = text.lower().strip()
        if any(w in t_lower for w in ("open", "search", "launch", "calc", "note", "lock")):
            self._on_navigation_changed("actions")
            self.quick_actions_view.cmd_input.setText(text)
            self.quick_actions_view._on_cmd_submitted()
        else:
            self._on_navigation_changed("chat")
            self._on_user_sent_message(text)

    def _regenerate_last_response(self):
        if self.active_cid:
            msgs = self.conv_manager.get_conversation_messages(self.active_cid)
            if msgs:
                last_user = "Tell me about JARVIS AI"
                for m in reversed(msgs):
                    if m.role == "user":
                        last_user = m.content
                        break
                self._on_user_sent_message(last_user)

    def _on_weather_updated(self, weather):
        self.system_panel.update_weather(weather)
        loc = getattr(weather, 'location', 'Local')
        temp = getattr(weather, 'temperature_c', 25.0)
        cond = getattr(weather, 'condition', 'Clear')
        hum = getattr(weather, 'humidity_percent', 50)
        wind = getattr(weather, 'wind_speed_kmh', 5.0)
        self._latest_weather_str = f"Location: {loc}; Temperature: {temp}°C; Weather: {cond}; Humidity: {hum}%; Wind: {wind} km/h."
        self._update_live_voice_context()

    def _on_metrics_updated(self, metrics: ExtendedSystemMetrics):
        self._latest_telemetry = metrics
        self.dashboard_view.update_metrics(metrics)
        self.system_panel.update_metrics(metrics)
        is_chg = getattr(metrics, 'is_charging', True)
        self._latest_telemetry_str = f"CPU Load: {metrics.cpu_percent}%, RAM: {metrics.ram_used_gb:.1f}/{metrics.ram_total_gb:.1f} GB ({metrics.ram_percent}%), Battery: {metrics.battery_percent}% ({'Charging' if is_chg else 'Discharging'})"
        self._update_live_voice_context()

    def _update_live_voice_context(self):
        parts = []
        if getattr(self, '_latest_weather_str', None):
            parts.append(f"[Weather] {self._latest_weather_str}")
        if getattr(self, '_latest_telemetry_str', None):
            parts.append(f"[Telemetry] {self._latest_telemetry_str}")
        if parts and hasattr(self, 'live_voice'):
            self.live_voice.set_system_context("\n".join(parts))

    def _show_confirmation_dialog(self, title: str, message: str, callback):
        dlg = ActionConfirmationDialog(title, message, is_destructive=("Lock" in title), parent=self)
        if dlg.exec():
            if callable(callback):
                callback()

    def _purge_all_conversations(self):
        for c in self.conv_manager.get_all_conversations():
            self.conv_manager.delete_conversation(c.id)
        self.active_cid = None
        self._create_new_chat()

    def _toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def closeEvent(self, event):
        # Gracefully shutdown background workers and audio engines
        if hasattr(self, 'health_timer'):
            self.health_timer.stop()
        if hasattr(self, 'weather_timer'):
            self.weather_timer.stop()
        self.monitor_worker.stop()
        self.conn_manager.stop()
        self.weather_service.stop()
        self.ai_engine.stop_generation()
        self.stt_service.stop_recording()
        self.live_voice.stop_session()
        self.tts_service.shutdown()
        event.accept()
