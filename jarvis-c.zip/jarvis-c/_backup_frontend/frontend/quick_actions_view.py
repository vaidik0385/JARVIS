"""
JARVIS AI — Quick Actions & System Control Interface
Dedicated control panel to launch local Windows applications, open web portals,
execute natural language command dispatching, and view real execution telemetry logs.
"""

from datetime import datetime
from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QLineEdit, QGridLayout, QPushButton, QTextBrowser, QScrollArea
)
from PySide6.QtCore import Qt, Signal, QSize
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.buttons import PrimaryButton, IconButton
from services.app_launcher import AppLauncher

class QuickActionButton(QFrame):
    clicked = Signal(str)

    def __init__(self, action_id: str, label: str, icon_name: str, desc: str, accent: str = Palette.ACCENT_CYAN, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.action_id = action_id
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self.setStyleSheet(f"""
            QuickActionButton {{
                background-color: #12192A;
                border: 1px solid #1C273E;
                border-radius: 12px;
                padding: 12px;
            }}
            QuickActionButton:hover {{
                background-color: #18233C;
                border: 1px solid {accent};
            }}
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(12)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(get_pixmap(icon_name, color=accent, size=24))
        icon_lbl.setStyleSheet("border: none; background: transparent;")

        text_vbox = QVBoxLayout()
        text_vbox.setSpacing(2)

        title_lbl = QLabel(label, self)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 13px; font-weight: 700; border: none; background: transparent;")

        desc_lbl = QLabel(desc, self)
        desc_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; border: none; background: transparent;")

        text_vbox.addWidget(title_lbl)
        text_vbox.addWidget(desc_lbl)

        layout.addWidget(icon_lbl)
        layout.addLayout(text_vbox, stretch=1)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.action_id)
        super().mousePressEvent(event)


class QuickActionsView(QWidget):
    action_triggered = Signal(str)  # action_id

    def __init__(self, app_launcher: AppLauncher, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.launcher = app_launcher
        self._init_ui()

        # Connect launcher feedback
        self.launcher.action_completed.connect(self._log_action)

    def _init_ui(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        container = QWidget()
        main_layout = QVBoxLayout(container)
        main_layout.setContentsMargins(28, 20, 28, 20)
        main_layout.setSpacing(18)

        # 1. Header
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        title_vbox = QVBoxLayout()
        title_vbox.setSpacing(2)

        title_lbl = QLabel("QUICK ACTIONS & APPLICATION CONTROL", container)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 20px; font-weight: 800; letter-spacing: 1px;")

        sub_lbl = QLabel("Execute system-level tasks, launch desktop utilities, and query web services.", container)
        sub_lbl.setStyleSheet("color: #94A3B8; font-size: 12px;")

        title_vbox.addWidget(title_lbl)
        title_vbox.addWidget(sub_lbl)
        header_row.addLayout(title_vbox)
        header_row.addStretch()

        main_layout.addLayout(header_row)

        # 2. Natural Language Command Bar
        cmd_card = QFrame(container)
        cmd_card.setStyleSheet("""
            QFrame {
                background-color: #0F1626;
                border: 1px solid #25334E;
                border-radius: 12px;
                padding: 6px 12px;
            }
            QFrame:hover {
                border: 1px solid #00E5FF;
            }
        """)
        cmd_layout = QHBoxLayout(cmd_card)
        cmd_layout.setContentsMargins(8, 4, 8, 4)
        cmd_layout.setSpacing(10)

        icon_lbl = QLabel(cmd_card)
        icon_lbl.setPixmap(get_pixmap("sparkle", color=Palette.ACCENT_CYAN, size=18))
        icon_lbl.setStyleSheet("border: none; background: transparent;")

        self.cmd_input = QLineEdit(cmd_card)
        self.cmd_input.setPlaceholderText("Type a command (e.g. 'Search Python on YouTube', 'Open Calculator', 'Open WhatsApp')...")
        self.cmd_input.setStyleSheet("background: transparent; border: none; color: #F8FAFC; font-size: 13px;")
        self.cmd_input.returnPressed.connect(self._on_cmd_submitted)

        self.run_btn = PrimaryButton("Execute", icon_name="send", parent=cmd_card)
        self.run_btn.clicked.connect(self._on_cmd_submitted)

        cmd_layout.addWidget(icon_lbl)
        cmd_layout.addWidget(self.cmd_input, stretch=1)
        cmd_layout.addWidget(self.run_btn)

        main_layout.addWidget(cmd_card)

        # 3. Application Grid
        grid_title = QLabel("WINDOWS APPS & WEB UTILITIES", container)
        grid_title.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 700; letter-spacing: 1px; margin-top: 4px;")
        main_layout.addWidget(grid_title)

        grid = QGridLayout()
        grid.setSpacing(12)

        apps = [
            ("calculator", "Calculator", "calculator", "Launch Windows Math Calculator", Palette.ACCENT_CYAN),
            ("notepad", "Notepad", "notepad", "Open Windows Text Editor", Palette.ACCENT_BLUE),
            ("explorer", "File Explorer", "folder", "Open Local Drives & Files", "#38BDF8"),
            ("settings", "Windows Settings", "settings", "System Configuration Panel", "#94A3B8"),
            ("chrome", "Google Chrome", "actions", "Launch Default Web Browser", Palette.ACCENT_CYAN),
            ("youtube", "YouTube", "weather", "Open Video Streaming Platform", "#EF4444"),
            ("google", "Google Search", "search", "Search the Web", Palette.ACCENT_BLUE),
            ("linkedin", "LinkedIn", "network", "Open Professional Network", "#0A66C2"),
            ("whatsapp", "WhatsApp Web", "chat", "Messaging & Contacts", "#10B981"),
            ("lock", "Lock Workstation", "lock", "Secure Laptop with Confirmation", "#F59E0B"),
        ]

        for idx, (app_id, name, icon_name, desc, color) in enumerate(apps):
            btn = QuickActionButton(app_id, name, icon_name, desc, accent=color, parent=container)
            btn.clicked.connect(self._on_action_clicked)
            row = idx // 2
            col = idx % 2
            grid.addWidget(btn, row, col)

        main_layout.addLayout(grid)

        # 4. Real-time Activity Telemetry Log
        log_title = QLabel("SYSTEM DISPATCH ACTIVITY LOG", container)
        log_title.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 700; letter-spacing: 1px; margin-top: 6px;")
        main_layout.addWidget(log_title)

        self.log_viewer = QTextBrowser(container)
        self.log_viewer.setFixedHeight(120)
        self.log_viewer.setStyleSheet("""
            QTextBrowser {
                background-color: #0A0F1B;
                color: #94A3B8;
                border: 1px solid #1C273E;
                border-radius: 8px;
                padding: 10px;
                font-family: Consolas, 'Cascadia Code', monospace;
                font-size: 11px;
                line-height: 16px;
            }
        """)
        self._append_log("JARVIS Application Control Dispatcher initialized and online.")
        main_layout.addWidget(self.log_viewer)

        scroll.setWidget(container)
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.addWidget(scroll)

    def _on_action_clicked(self, action_id: str):
        self.launcher.launch(action_id, prompt_confirmation=True)

    def _on_cmd_submitted(self):
        text = self.cmd_input.text().strip()
        if text:
            self.cmd_input.clear()
            self._append_log(f"Parsing natural command: '{text}'")
            self.launcher.parse_and_execute_command(text)

    def _log_action(self, action_name: str, success: bool, message: str):
        status_tag = "SUCCESS" if success else "FAILED"
        self._append_log(f"[{status_tag}] {action_name}: {message}")

    def _append_log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_viewer.append(f"[{ts}] {msg}")
        self.log_viewer.verticalScrollBar().setValue(self.log_viewer.verticalScrollBar().maximum())
