"""
JARVIS AI — Comprehensive Settings View
Structured multi-category settings interface: General, Appearance, Voice & Audio,
AI Provider, Language, Privacy & Security, Keyboard Shortcuts, and About.
"""

from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTabWidget, QCheckBox, QComboBox, QSlider, QPushButton,
    QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.buttons import PrimaryButton, DangerButton
from components.status_indicator import GlowingDot

class SettingsView(QWidget):
    theme_changed = Signal(str)
    clear_all_data_requested = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(28, 20, 28, 20)
        main_layout.setSpacing(16)

        # 1. Header
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(get_pixmap("settings", color=Palette.ACCENT_CYAN, size=24))

        title_vbox = QVBoxLayout()
        title_vbox.setSpacing(2)

        title_lbl = QLabel("JARVIS CONFIGURATION & PREFERENCES", self)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 20px; font-weight: 800; letter-spacing: 1px;")

        sub_lbl = QLabel("Customize desktop behavior, audio channels, AI endpoints, and security policies.", self)
        sub_lbl.setStyleSheet("color: #94A3B8; font-size: 12px;")

        title_vbox.addWidget(title_lbl)
        title_vbox.addWidget(sub_lbl)

        header_row.addWidget(icon_lbl)
        header_row.addLayout(title_vbox)
        header_row.addStretch()

        main_layout.addLayout(header_row)

        # 2. Tab Widget
        tabs = QTabWidget(self)
        tabs.addTab(self._build_general_tab(), "General")
        tabs.addTab(self._build_appearance_tab(), "Appearance")
        tabs.addTab(self._build_voice_tab(), "Voice & Audio")
        tabs.addTab(self._build_ai_tab(), "AI Provider")
        tabs.addTab(self._build_privacy_tab(), "Privacy & Security")
        tabs.addTab(self._build_shortcuts_tab(), "Shortcuts")
        tabs.addTab(self._build_about_tab(), "About")

        main_layout.addWidget(tabs, stretch=1)

    def _build_general_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        self.startup_chk = QCheckBox("Launch JARVIS AI automatically on Windows startup", widget)
        self.startup_chk.setChecked(True)

        self.tray_chk = QCheckBox("Minimize to system notification tray when window is closed", widget)
        self.tray_chk.setChecked(True)

        self.telemetry_chk = QCheckBox("Enable high-frequency background system performance polling", widget)
        self.telemetry_chk.setChecked(True)

        # Default landing view
        view_row = QHBoxLayout()
        v_lbl = QLabel("Default View on Startup:", widget)
        v_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.view_combo = QComboBox(widget)
        self.view_combo.addItems(["Dashboard (Voice Orb & Telemetry)", "Chat Assistant", "Live Voice Call", "Quick Actions"])
        view_row.addWidget(v_lbl)
        view_row.addWidget(self.view_combo)
        view_row.addStretch()

        layout.addWidget(self.startup_chk)
        layout.addWidget(self.tray_chk)
        layout.addWidget(self.telemetry_chk)
        layout.addLayout(view_row)
        layout.addStretch()
        return widget

    def _build_appearance_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Theme Selector
        theme_row = QHBoxLayout()
        t_lbl = QLabel("Active Color Theme:", widget)
        t_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.theme_combo = QComboBox(widget)
        self.theme_combo.addItems(["Midnight Charcoal (Default)", "Deep Navy Obsidian", "Cyber Slate"])
        theme_row.addWidget(t_lbl)
        theme_row.addWidget(self.theme_combo)
        theme_row.addStretch()

        # Accent Color
        accent_row = QHBoxLayout()
        a_lbl = QLabel("Primary Accent Glow:", widget)
        a_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.accent_combo = QComboBox(widget)
        self.accent_combo.addItems(["Electric Cyan (#00E5FF)", "Neon Purple (#8B5CF6)", "Cobalt Blue (#3B82F6)"])
        accent_row.addWidget(a_lbl)
        accent_row.addWidget(self.accent_combo)
        accent_row.addStretch()

        # UI Scale
        scale_row = QHBoxLayout()
        s_lbl = QLabel("Interface Scaling:", widget)
        s_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.scale_combo = QComboBox(widget)
        self.scale_combo.addItems(["100% (Standard)", "110% (Enhanced)", "125% (High DPI)"])
        scale_row.addWidget(s_lbl)
        scale_row.addWidget(self.scale_combo)
        scale_row.addStretch()

        layout.addLayout(theme_row)
        layout.addLayout(accent_row)
        layout.addLayout(scale_row)
        layout.addStretch()
        return widget

    def _build_voice_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Voice selection
        voice_row = QHBoxLayout()
        v_lbl = QLabel("Text-to-Speech Engine Voice:", widget)
        v_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.voice_combo = QComboBox(widget)
        self.voice_combo.addItems(["JARVIS British Male (Neural)", "JARVIS American Male (Studio)", "Friday Female (Neural)"])
        voice_row.addWidget(v_lbl)
        voice_row.addWidget(self.voice_combo)
        voice_row.addStretch()

        # Speech rate slider
        rate_box = QVBoxLayout()
        rate_box.setSpacing(6)
        r_lbl = QLabel("Speech Synthesis Speed: 1.0x", widget)
        r_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.rate_slider = QSlider(Qt.Orientation.Horizontal, widget)
        self.rate_slider.setRange(75, 150)
        self.rate_slider.setValue(100)
        self.rate_slider.valueChanged.connect(lambda val: r_lbl.setText(f"Speech Synthesis Speed: {val/100.0:.2f}x"))
        rate_box.addWidget(r_lbl)
        rate_box.addWidget(self.rate_slider)

        # Wake word toggle
        self.wake_chk = QCheckBox("Enable Wake Word Detection ('Hey JARVIS')", widget)
        self.wake_chk.setChecked(True)

        layout.addLayout(voice_row)
        layout.addLayout(rate_box)
        layout.addWidget(self.wake_chk)
        layout.addStretch()
        return widget

    def _build_ai_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Provider selection
        prov_row = QHBoxLayout()
        p_lbl = QLabel("AI Inference Provider:", widget)
        p_lbl.setStyleSheet("color: #E2E8F0; font-size: 13px;")
        self.prov_combo = QComboBox(widget)
        self.prov_combo.addItems(["Google Gemini 2.0 (Fast & Multimodal)", "Local Ollama (Offline LLM)", "OpenAI GPT-4o"])
        prov_row.addWidget(p_lbl)
        prov_row.addWidget(self.prov_combo)
        prov_row.addStretch()

        # Security Notice Card
        sec_card = QFrame(widget)
        sec_card.setStyleSheet("background-color: #12192A; border: 1px solid #1E2D48; border-radius: 8px; padding: 12px;")
        sec_vbox = QVBoxLayout(sec_card)
        sec_vbox.setSpacing(6)

        sec_title = QLabel("SECURE BACKEND CREDENTIAL MANAGEMENT", sec_card)
        sec_title.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 700; letter-spacing: 0.8px;")

        sec_desc = QLabel(
            "API keys and provider tokens are loaded strictly via backend environment variables "
            "(e.g., GEMINI_API_KEY) and never exposed or logged in the user interface.",
            sec_card
        )
        sec_desc.setWordWrap(True)
        sec_desc.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 16px;")

        sec_vbox.addWidget(sec_title)
        sec_vbox.addWidget(sec_desc)

        layout.addLayout(prov_row)
        layout.addWidget(sec_card)
        layout.addStretch()
        return widget

    def _build_privacy_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        # Principles checklist
        p1 = QCheckBox("Enforce strict local privacy sandbox (No unauthorized folder indexing)", widget)
        p1.setChecked(True)
        p1.setEnabled(False)

        p2 = QCheckBox("Require explicit confirmation dialog before executing system lock or destructive tasks", widget)
        p2.setChecked(True)

        p3 = QCheckBox("Keep all conversation history strictly local on device in JSON format", widget)
        p3.setChecked(True)
        p3.setEnabled(False)

        # Clear data button
        clear_row = QHBoxLayout()
        clear_desc = QLabel("Permanently purge local conversation history and cached telemetry:", widget)
        clear_desc.setStyleSheet("color: #94A3B8; font-size: 12px;")
        clear_btn = DangerButton("Purge All History", icon_name="trash", parent=widget)
        clear_btn.clicked.connect(self._confirm_clear_data)
        clear_row.addWidget(clear_desc)
        clear_row.addWidget(clear_btn)
        clear_row.addStretch()

        layout.addWidget(p1)
        layout.addWidget(p2)
        layout.addWidget(p3)
        layout.addLayout(clear_row)
        layout.addStretch()
        return widget

    def _build_shortcuts_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        table = QTableWidget(widget)
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Action", "Keybinding"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().setVisible(False)
        table.setStyleSheet("""
            QTableWidget {
                background-color: #0E1424;
                border: 1px solid #1C273E;
                border-radius: 8px;
                gridline-color: #1C273E;
            }
            QHeaderView::section {
                background-color: #141C30;
                color: #CBD5E1;
                font-weight: 700;
                padding: 6px;
                border: none;
            }
        """)

        shortcuts = [
            ("Send Message in Chat", "Enter"),
            ("New Line in Chat Input", "Shift + Enter"),
            ("Start New Conversation", "Ctrl + N"),
            ("Toggle Left Sidebar", "Ctrl + B"),
            ("Toggle Right Telemetry Panel", "Ctrl + T"),
            ("Switch to Dashboard", "Ctrl + 1"),
            ("Switch to Chat Assistant", "Ctrl + 2"),
            ("Switch to Live Voice Mode", "Ctrl + 3"),
            ("Switch to Quick Actions", "Ctrl + 4"),
            ("Cancel / Stop Generation", "Escape"),
        ]

        table.setRowCount(len(shortcuts))
        for row, (action, key) in enumerate(shortcuts):
            it_a = QTableWidgetItem(action)
            it_a.setForeground(Qt.GlobalColor.white)
            it_k = QTableWidgetItem(key)
            it_k.setForeground(QColor(Palette.ACCENT_CYAN))
            table.setItem(row, 0, it_a)
            table.setItem(row, 1, it_k)

        layout.addWidget(table)
        return widget

    def _build_about_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        logo_lbl = QLabel(widget)
        logo_lbl.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=48))
        logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title_lbl = QLabel("JARVIS AI DESKTOP ASSISTANT", widget)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 18px; font-weight: 800; letter-spacing: 1.5px;")
        title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        ver_lbl = QLabel("Version 2.4.0 • College Project Expo Demonstration Edition", widget)
        ver_lbl.setStyleSheet("color: #00E5FF; font-size: 12px; font-weight: 600;")
        ver_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        about_text = QLabel(
            "An enterprise-grade, privacy-first desktop intelligent assistant engineered with Python 3.14 "
            "and PySide6. Features an animated neural voice orb, dynamic audio spectrum analysis, real-time "
            "hardware telemetry polling, application workflow dispatching, and asynchronous background worker threads.\n\n"
            "• Technology: Python 3.14, PySide6 (Qt 6.12), psutil\n"
            "• Architecture: Decoupled Signal-Driven Asynchronous UI\n"
            "• Designed for: Next-Generation Human-Computer Collaboration",
            widget
        )
        about_text.setWordWrap(True)
        about_text.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 18px; padding: 12px;")

        layout.addWidget(logo_lbl)
        layout.addWidget(title_lbl)
        layout.addWidget(ver_lbl)
        layout.addWidget(about_text)
        layout.addStretch()
        return widget

    def _confirm_clear_data(self):
        reply = QMessageBox.question(
            self,
            "Confirm Data Purge",
            "Are you sure you want to delete all saved conversations? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.clear_all_data_requested.emit()
