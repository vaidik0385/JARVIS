"""
JARVIS AI — Main Assistant Dashboard
Features the prominent animated Voice Orb, flowing audio waveform,
live telemetry insights, quick prompt dispatcher, and action cards.
"""

from datetime import datetime
from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QLineEdit, QGridLayout, QPushButton, QScrollArea
)
from PySide6.QtCore import Qt, Signal, QTimer, QSize
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.voice_orb import VoiceOrbWidget
from components.waveform import WaveformWidget
from components.metric_gauge import CircularGaugeWidget, BarGaugeWidget
from components.status_indicator import GlowingDot
from components.cards import ActionTriggerCard
from components.buttons import IconButton, PrimaryButton
from services.frontend_interfaces import SystemMetrics

class DashboardView(QWidget):
    prompt_submitted = Signal(str)
    switch_view_requested = Signal(str)  # "chat", "voice", "actions", "settings"
    voice_session_triggered = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._orb_state = "idle"
        self._init_ui()

    def _init_ui(self):
        # Outer scroll area for responsive scaling
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        container = QWidget()
        main_layout = QVBoxLayout(container)
        main_layout.setContentsMargins(28, 20, 28, 20)
        main_layout.setSpacing(20)

        # 1. Top Greeting & Status Banner
        top_banner = QHBoxLayout()
        top_banner.setSpacing(12)

        banner_text_box = QVBoxLayout()
        banner_text_box.setSpacing(2)

        # Greeting based on time
        now = datetime.now()
        hr = now.hour
        greeting = "Good evening, Sir." if hr >= 17 else ("Good afternoon, Sir." if hr >= 12 else "Good morning, Sir.")

        self.greeting_lbl = QLabel(greeting, container)
        self.greeting_lbl.setStyleSheet("color: #F8FAFC; font-size: 26px; font-weight: 800; letter-spacing: 0.5px;")

        self.sub_status_lbl = QLabel("All core protocols operational • Neural engine standing by", container)
        self.sub_status_lbl.setStyleSheet("color: #94A3B8; font-size: 13px; font-weight: 500;")

        banner_text_box.addWidget(self.greeting_lbl)
        banner_text_box.addWidget(self.sub_status_lbl)

        # Live Status Pill
        self.status_pill = QFrame(container)
        self.status_pill.setStyleSheet("""
            QFrame {
                background-color: #12192A;
                border: 1px solid #1F2D48;
                border-radius: 14px;
                padding: 4px 12px;
            }
        """)
        sp_layout = QHBoxLayout(self.status_pill)
        sp_layout.setContentsMargins(8, 4, 8, 4)
        sp_layout.setSpacing(6)

        self.status_dot = GlowingDot("#10B981", size=10, parent=self.status_pill)
        self.status_lbl = QLabel("SYSTEM ONLINE", self.status_pill)
        self.status_lbl.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 700; letter-spacing: 1px;")

        sp_layout.addWidget(self.status_dot)
        sp_layout.addWidget(self.status_lbl)

        top_banner.addLayout(banner_text_box)
        top_banner.addStretch()
        top_banner.addWidget(self.status_pill)

        main_layout.addLayout(top_banner)

        # 2. Central Voice Orb Hero Section
        hero_card = QFrame(container)
        hero_card.setStyleSheet("""
            QFrame {
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #121A2D, stop:1 #0C1220);
                border: 1px solid #1E2B47;
                border-radius: 16px;
            }
        """)
        hero_layout = QVBoxLayout(hero_card)
        hero_layout.setContentsMargins(20, 24, 20, 20)
        hero_layout.setSpacing(14)
        hero_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Interactive state selector tabs (Idle, Listening, Thinking, Speaking)
        state_row = QHBoxLayout()
        state_row.setSpacing(8)
        state_row.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.state_btns = {}
        for st in ("idle", "listening", "thinking", "speaking"):
            btn = QPushButton(st.upper(), hero_card)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(self._get_state_btn_style(st == "idle"))
            btn.clicked.connect(lambda ch=False, s=st: self._set_orb_state(s))
            state_row.addWidget(btn)
            self.state_btns[st] = btn

        hero_layout.addLayout(state_row)

        # Large Animated Voice Orb (210px)
        self.voice_orb = VoiceOrbWidget(size=210, parent=hero_card)
        hero_layout.addWidget(self.voice_orb, alignment=Qt.AlignmentFlag.AlignCenter)

        # Reactive Waveform Visualizer
        self.waveform = WaveformWidget(height=48, bar_count=42, parent=hero_card)
        hero_layout.addWidget(self.waveform)

        # Quick Voice Action Trigger Button
        voice_action_row = QHBoxLayout()
        voice_action_row.setAlignment(Qt.AlignmentFlag.AlignCenter)
        voice_action_row.setSpacing(12)

        self.start_voice_btn = PrimaryButton("Start Live Voice Session", icon_name="voice", parent=hero_card)
        self.start_voice_btn.clicked.connect(lambda: self.switch_view_requested.emit("voice"))

        voice_action_row.addWidget(self.start_voice_btn)
        hero_layout.addLayout(voice_action_row)

        main_layout.addWidget(hero_card)

        # 3. Quick Natural Command / Prompt Bar
        prompt_card = QFrame(container)
        prompt_card.setStyleSheet("""
            QFrame {
                background-color: #0F1626;
                border: 1px solid #25334E;
                border-radius: 12px;
                padding: 4px;
            }
            QFrame:hover {
                border: 1px solid #00E5FF;
            }
        """)
        p_layout = QHBoxLayout(prompt_card)
        p_layout.setContentsMargins(14, 8, 14, 8)
        p_layout.setSpacing(10)

        sparkle_lbl = QLabel(prompt_card)
        sparkle_lbl.setPixmap(get_pixmap("sparkle", color=Palette.ACCENT_CYAN, size=18))
        sparkle_lbl.setStyleSheet("border: none; background: transparent;")

        self.prompt_input = QLineEdit(prompt_card)
        self.prompt_input.setPlaceholderText("Ask JARVIS anything or type a system command (e.g. 'Open Calculator', 'Search YouTube')...")
        self.prompt_input.setStyleSheet("""
            QLineEdit {
                background: transparent;
                border: none;
                color: #F8FAFC;
                font-size: 13px;
            }
        """)
        self.prompt_input.returnPressed.connect(self._on_prompt_submitted)

        self.exec_btn = IconButton("send", tooltip="Submit Command", size=32, icon_color=Palette.ACCENT_CYAN, parent=prompt_card)
        self.exec_btn.clicked.connect(self._on_prompt_submitted)

        p_layout.addWidget(sparkle_lbl)
        p_layout.addWidget(self.prompt_input, stretch=1)
        p_layout.addWidget(self.exec_btn)

        main_layout.addWidget(prompt_card)

        # 4. Live Telemetry Insights Row (CPU, RAM, Battery gauges)
        telemetry_title = QLabel("SYSTEM TELEMETRY INSIGHTS", container)
        telemetry_title.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
        main_layout.addWidget(telemetry_title)

        gauge_row = QHBoxLayout()
        gauge_row.setSpacing(14)

        # CPU Card
        self.cpu_card = QFrame(container)
        self.cpu_card.setStyleSheet("background-color: #121828; border: 1px solid #1C263B; border-radius: 12px; padding: 10px;")
        c_vbox = QVBoxLayout(self.cpu_card)
        c_vbox.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.cpu_gauge = CircularGaugeWidget("CPU", unit="%", size=96, parent=self.cpu_card)
        c_vbox.addWidget(self.cpu_gauge, alignment=Qt.AlignmentFlag.AlignCenter)
        gauge_row.addWidget(self.cpu_card)

        # RAM Card
        self.ram_card = QFrame(container)
        self.ram_card.setStyleSheet("background-color: #121828; border: 1px solid #1C263B; border-radius: 12px; padding: 10px;")
        r_vbox = QVBoxLayout(self.ram_card)
        r_vbox.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ram_gauge = CircularGaugeWidget("RAM", unit="%", size=96, parent=self.ram_card)
        r_vbox.addWidget(self.ram_gauge, alignment=Qt.AlignmentFlag.AlignCenter)
        gauge_row.addWidget(self.ram_card)

        # Battery Card
        self.batt_card = QFrame(container)
        self.batt_card.setStyleSheet("background-color: #121828; border: 1px solid #1C263B; border-radius: 12px; padding: 10px;")
        b_vbox = QVBoxLayout(self.batt_card)
        b_vbox.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.batt_gauge = CircularGaugeWidget("BATTERY", unit="%", size=96, parent=self.batt_card)
        b_vbox.addWidget(self.batt_gauge, alignment=Qt.AlignmentFlag.AlignCenter)
        gauge_row.addWidget(self.batt_card)

        main_layout.addLayout(gauge_row)

        # 5. Four Feature Cards Grid
        grid_title = QLabel("CORE CAPABILITIES", container)
        grid_title.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 700; letter-spacing: 1px; margin-top: 6px;")
        main_layout.addWidget(grid_title)

        grid = QGridLayout()
        grid.setSpacing(14)

        card1 = ActionTriggerCard("chat", "Conversational AI", "Ask multi-turn queries, review code snippets, and synthesize solutions.", accent_color=Palette.ACCENT_CYAN, parent=container)
        card1.clicked.connect(lambda: self.switch_view_requested.emit("chat"))

        card2 = ActionTriggerCard("voice", "Live Voice Call", "Enter dedicated Mode B full-screen audio conversation with voice interruption.", accent_color=Palette.ACCENT_PURPLE, parent=container)
        card2.clicked.connect(lambda: self.switch_view_requested.emit("voice"))

        card3 = ActionTriggerCard("actions", "App Control & Automations", "Launch Calculator, Notepad, browsers, and workstation controls.", accent_color=Palette.ACCENT_BLUE, parent=container)
        card3.clicked.connect(lambda: self.switch_view_requested.emit("actions"))

        card4 = ActionTriggerCard("settings", "Security & System Preferences", "Configure voice parameters, appearance themes, and strict privacy guards.", accent_color="#10B981", parent=container)
        card4.clicked.connect(lambda: self.switch_view_requested.emit("settings"))

        grid.addWidget(card1, 0, 0)
        grid.addWidget(card2, 0, 1)
        grid.addWidget(card3, 1, 0)
        grid.addWidget(card4, 1, 1)

        main_layout.addLayout(grid)

        scroll.setWidget(container)
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.addWidget(scroll)

    def _set_orb_state(self, state: str):
        self._orb_state = state
        self.voice_orb.set_state(state)
        for st, btn in self.state_btns.items():
            btn.setStyleSheet(self._get_state_btn_style(st == state))

        # Adjust waveform reactivity
        if state == "speaking":
            self.waveform.set_amplitude(0.8)
        elif state == "listening":
            self.waveform.set_amplitude(0.55)
        elif state == "thinking":
            self.waveform.set_amplitude(0.35)
        else:
            self.waveform.set_amplitude(0.2)

    def _get_state_btn_style(self, active: bool) -> str:
        if active:
            return """
                QPushButton {
                    background-color: #1E2D48;
                    color: #00E5FF;
                    border: 1px solid #00E5FF;
                    border-radius: 6px;
                    padding: 4px 10px;
                    font-size: 10px;
                    font-weight: 700;
                    letter-spacing: 0.5px;
                }
            """
        else:
            return """
                QPushButton {
                    background-color: #12192A;
                    color: #94A3B8;
                    border: 1px solid #1C263B;
                    border-radius: 6px;
                    padding: 4px 10px;
                    font-size: 10px;
                    font-weight: 600;
                    letter-spacing: 0.5px;
                }
                QPushButton:hover {
                    background-color: #18233C;
                    color: #F8FAFC;
                }
            """

    def _on_prompt_submitted(self):
        text = self.prompt_input.text().strip()
        if text:
            self.prompt_input.clear()
            self.prompt_submitted.emit(text)

    def update_metrics(self, metrics: SystemMetrics):
        self.cpu_gauge.set_value(metrics.cpu_percent)
        self.ram_gauge.set_value(metrics.ram_percent)
        self.batt_gauge.set_value(float(metrics.battery_percent))
