"""
JARVIS AI — Collapsible Left Navigation Sidebar
Features logo branding, New Chat trigger, live search filter,
view navigation tabs, locally stored conversation history, and privacy status.
"""

from typing import Optional, List
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QScrollArea, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QSize
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.buttons import IconButton
from components.status_indicator import GlowingDot
from services.frontend_interfaces import ConversationMeta

class SidebarConversationItem(QFrame):
    clicked = Signal(str)
    delete_requested = Signal(str)

    def __init__(self, meta: ConversationMeta, is_active: bool = False, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.meta = meta
        self.cid = meta.id
        self._is_active = is_active
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(34)

        self.setStyleSheet(self._get_style())

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 4, 6, 4)
        layout.setSpacing(8)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(get_pixmap("chat", color=Palette.ACCENT_CYAN if is_active else Palette.TEXT_MUTED, size=14))
        icon_lbl.setStyleSheet("border: none; background: transparent;")

        # Elide title to 24 chars if too long
        title = meta.title if len(meta.title) <= 24 else meta.title[:22] + "..."
        self.title_lbl = QLabel(title, self)
        self.title_lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.title_lbl.setStyleSheet(f"color: {'#38BDF8' if is_active else '#CBD5E1'}; font-size: 11px; font-weight: {'600' if is_active else '400'}; border: none; background: transparent;")
        self.title_lbl.setToolTip(meta.title)

        self.del_btn = QPushButton(self)
        self.del_btn.setFixedSize(20, 20)
        self.del_btn.setIcon(get_icon("trash", color="#64748B", size=12))
        self.del_btn.setToolTip("Delete conversation")
        self.del_btn.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.2);
            }
        """)
        self.del_btn.clicked.connect(lambda: self.delete_requested.emit(self.cid))

        layout.addWidget(icon_lbl)
        layout.addWidget(self.title_lbl, stretch=1)
        layout.addWidget(self.del_btn)

    def _get_style(self) -> str:
        if self._is_active:
            return """
                SidebarConversationItem {
                    background-color: #17243C;
                    border: 1px solid #283C63;
                    border-left: 3px solid #00E5FF;
                    border-radius: 0px 6px 6px 0px;
                }
            """
        else:
            return """
                SidebarConversationItem {
                    background-color: transparent;
                    border: 1px solid transparent;
                    border-radius: 6px;
                }
                SidebarConversationItem:hover {
                    background-color: #141C2E;
                    border: 1px solid #1E2B47;
                }
            """

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.cid)
        super().mousePressEvent(event)


class SidebarWidget(QWidget):
    navigation_changed = Signal(str)      # "dashboard", "chat", "voice", "actions", "settings", "about"
    new_chat_requested = Signal()
    conversation_selected = Signal(str)  # conversation_id
    conversation_deleted = Signal(str)
    search_query_changed = Signal(str)
    toggle_collapse_requested = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(270)
        self._is_collapsed = False
        self._active_nav = "dashboard"
        self._active_cid = None
        self._conversations: List[ConversationMeta] = []

        self._init_ui()

    def _init_ui(self):
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(12, 14, 12, 14)
        self.main_layout.setSpacing(12)

        # 1. Header (Logo + Title + Collapse Toggle)
        header_row = QHBoxLayout()
        header_row.setSpacing(10)

        self.logo_btn = QPushButton(self)
        self.logo_btn.setIcon(get_icon("logo", color=Palette.ACCENT_CYAN, size=24))
        self.logo_btn.setIconSize(QSize(24, 24))
        self.logo_btn.setFixedSize(32, 32)
        self.logo_btn.setStyleSheet("background: transparent; border: none;")
        self.logo_btn.setToolTip("Toggle Sidebar (Ctrl+B)")
        self.logo_btn.clicked.connect(self.toggle_collapse_requested.emit)

        self.title_container = QWidget(self)
        title_vbox = QVBoxLayout(self.title_container)
        title_vbox.setContentsMargins(0, 0, 0, 0)
        title_vbox.setSpacing(0)

        self.title_lbl = QLabel("JARVIS AI", self.title_container)
        self.title_lbl.setStyleSheet("color: #F8FAFC; font-size: 15px; font-weight: 800; letter-spacing: 1.5px;")

        self.sub_lbl = QLabel("ASSISTANT v2.4", self.title_container)
        self.sub_lbl.setStyleSheet("color: #00E5FF; font-size: 9px; font-weight: 700; letter-spacing: 1px;")

        title_vbox.addWidget(self.title_lbl)
        title_vbox.addWidget(self.sub_lbl)

        self.collapse_btn = IconButton("sidebar_toggle", tooltip="Collapse Sidebar", size=28, parent=self)
        self.collapse_btn.clicked.connect(self.toggle_collapse_requested.emit)

        header_row.addWidget(self.logo_btn)
        header_row.addWidget(self.title_container, stretch=1)
        header_row.addWidget(self.collapse_btn)

        self.main_layout.addLayout(header_row)

        # 2. "New Chat" Action Button
        self.new_chat_btn = QPushButton("+  New Conversation", self)
        self.new_chat_btn.setObjectName("newChatBtn")
        self.new_chat_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.new_chat_btn.setToolTip("Start New Chat (Ctrl+N)")
        self.new_chat_btn.clicked.connect(self.new_chat_requested.emit)
        self.main_layout.addWidget(self.new_chat_btn)

        # 3. Main Navigation Items
        self.nav_container = QWidget(self)
        nav_vbox = QVBoxLayout(self.nav_container)
        nav_vbox.setContentsMargins(0, 0, 0, 0)
        nav_vbox.setSpacing(4)

        self.nav_btns = {}
        items = [
            ("dashboard", "Dashboard", "dashboard"),
            ("chat", "Chat Assistant", "chat"),
            ("voice", "Live Voice Call", "voice"),
            ("actions", "Quick Actions", "actions"),
        ]

        for nav_id, label, icon_name in items:
            btn = QPushButton(f"  {label}", self.nav_container)
            btn.setProperty("class", "nav-btn")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setIcon(get_icon(icon_name, color=Palette.TEXT_SECONDARY, size=16))
            btn.setIconSize(QSize(16, 16))
            btn.clicked.connect(lambda checked=False, nid=nav_id: self._on_nav_clicked(nid))
            nav_vbox.addWidget(btn)
            self.nav_btns[nav_id] = btn

        self.main_layout.addWidget(self.nav_container)

        # 4. Search Filter for Conversations
        self.search_container = QWidget(self)
        search_layout = QHBoxLayout(self.search_container)
        search_layout.setContentsMargins(0, 4, 0, 0)
        search_layout.setSpacing(6)

        self.search_bar = QLineEdit(self.search_container)
        self.search_bar.setObjectName("searchBar")
        self.search_bar.setPlaceholderText("Search conversations...")
        self.search_bar.textChanged.connect(self.search_query_changed.emit)
        search_layout.addWidget(self.search_bar)

        self.main_layout.addWidget(self.search_container)

        # 5. History Section Title
        self.history_title = QLabel("RECENT CONVERSATIONS", self)
        self.history_title.setStyleSheet("color: #64748B; font-size: 10px; font-weight: 700; letter-spacing: 1px; padding-top: 6px;")
        self.main_layout.addWidget(self.history_title)

        # 6. Scrollable Conversation History
        self.history_scroll = QScrollArea(self)
        self.history_scroll.setWidgetResizable(True)
        self.history_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.history_widget = QWidget()
        self.history_layout = QVBoxLayout(self.history_widget)
        self.history_layout.setContentsMargins(0, 0, 4, 0)
        self.history_layout.setSpacing(3)
        self.history_layout.addStretch()

        self.history_scroll.setWidget(self.history_widget)
        self.main_layout.addWidget(self.history_scroll, stretch=1)

        # 7. Privacy Status Indicator
        self.privacy_card = QFrame(self)
        self.privacy_card.setStyleSheet("""
            QFrame {
                background-color: #12192A;
                border: 1px solid #1E2D48;
                border-radius: 8px;
                padding: 4px;
            }
        """)
        priv_layout = QHBoxLayout(self.privacy_card)
        priv_layout.setContentsMargins(8, 6, 8, 6)
        priv_layout.setSpacing(8)

        priv_dot = GlowingDot("#10B981", size=10, parent=self.privacy_card)
        self.priv_text = QLabel("Local • Private • Verified", self.privacy_card)
        self.priv_text.setStyleSheet("color: #38BDF8; font-size: 10px; font-weight: 700; border: none; background: transparent;")

        priv_layout.addWidget(priv_dot)
        priv_layout.addWidget(self.priv_text)
        priv_layout.addStretch()

        self.main_layout.addWidget(self.privacy_card)

        # 8. Bottom utility buttons (Settings & About)
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(6)

        self.settings_btn = QPushButton("  Settings", self)
        self.settings_btn.setProperty("class", "nav-btn")
        self.settings_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.settings_btn.setIcon(get_icon("settings", color=Palette.TEXT_SECONDARY, size=15))
        self.settings_btn.clicked.connect(lambda: self._on_nav_clicked("settings"))

        self.about_btn = IconButton("help", tooltip="About JARVIS AI", size=32, parent=self)
        self.about_btn.clicked.connect(lambda: self.navigation_changed.emit("about"))

        bottom_row.addWidget(self.settings_btn, stretch=1)
        bottom_row.addWidget(self.about_btn)

        self.main_layout.addLayout(bottom_row)

        # Set default active nav
        self.set_active_nav("dashboard")

    def _on_nav_clicked(self, nav_id: str):
        self.set_active_nav(nav_id)
        self.navigation_changed.emit(nav_id)

    def set_active_nav(self, nav_id: str):
        self._active_nav = nav_id
        for nid, btn in self.nav_btns.items():
            if nid == nav_id:
                btn.setStyleSheet("""
                    background-color: #1B2640;
                    color: #00E5FF;
                    border: 1px solid rgba(0, 229, 255, 0.4);
                    font-weight: 600;
                """)
                btn.setIcon(get_icon(btn.icon().name() if hasattr(btn.icon(), 'name') else nid, color=Palette.ACCENT_CYAN, size=16))
            else:
                btn.setStyleSheet("""
                    background-color: transparent;
                    color: #94A3B8;
                    border: 1px solid transparent;
                    font-weight: 500;
                """)

    def set_conversations(self, conversations: List[ConversationMeta], active_id: Optional[str] = None):
        self._conversations = conversations
        self._active_cid = active_id

        # Clear existing items
        while self.history_layout.count() > 1:
            item = self.history_layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
                item.widget().deleteLater()

        if not conversations:
            empty_lbl = QLabel("No conversations yet", self.history_widget)
            empty_lbl.setStyleSheet("color: #475569; font-size: 11px; padding: 12px; font-style: italic;")
            empty_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.history_layout.insertWidget(0, empty_lbl)
            return

        for meta in conversations:
            is_active = (meta.id == active_id)
            c_item = SidebarConversationItem(meta, is_active=is_active, parent=self.history_widget)
            c_item.clicked.connect(self._on_conversation_clicked)
            c_item.delete_requested.connect(self.conversation_deleted.emit)
            self.history_layout.insertWidget(self.history_layout.count() - 1, c_item)

    def _on_conversation_clicked(self, cid: str):
        self._active_cid = cid
        self.conversation_selected.emit(cid)

    def toggle_collapse(self):
        self._is_collapsed = not self._is_collapsed
        if self._is_collapsed:
            self.setFixedWidth(70)
            self.title_container.hide()
            self.collapse_btn.hide()
            self.new_chat_btn.setText("+")
            self.new_chat_btn.setToolTip("New Chat (Ctrl+N)")
            self.search_container.hide()
            self.history_title.hide()
            self.history_scroll.hide()
            self.privacy_card.hide()
            self.settings_btn.setText("")
            for nid, btn in self.nav_btns.items():
                btn.setText("")
        else:
            self.setFixedWidth(270)
            self.title_container.show()
            self.collapse_btn.show()
            self.new_chat_btn.setText("+  New Conversation")
            self.search_container.show()
            self.history_title.show()
            self.history_scroll.show()
            self.privacy_card.show()
            self.settings_btn.setText("  Settings")
            labels = {
                "dashboard": "  Dashboard",
                "chat": "  Chat Assistant",
                "voice": "  Live Voice Call",
                "actions": "  Quick Actions",
            }
            for nid, btn in self.nav_btns.items():
                btn.setText(labels.get(nid, ""))
