"""
JARVIS AI — Styled Modal Dialogs
Custom confirmation modals and Help/About dialogs matching the dark aesthetic.
"""

from typing import Optional, Callable
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame, QWidget
)
from PySide6.QtCore import Qt
from styles.palette import Palette
from styles.icons import get_pixmap
from components.buttons import PrimaryButton, SecondaryButton, DangerButton

class ActionConfirmationDialog(QDialog):
    """Modern dark modal for sensitive actions like system lock or data purge."""
    def __init__(self, title: str, message: str, is_destructive: bool = False, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFixedSize(420, 200)
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self._init_ui(title, message, is_destructive)

    def _init_ui(self, title: str, message: str, is_destructive: bool):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)

        card = QFrame(self)
        card.setStyleSheet("""
            QFrame {
                background-color: #121828;
                border: 1px solid #25334E;
                border-radius: 12px;
            }
        """)
        c_layout = QVBoxLayout(card)
        c_layout.setContentsMargins(20, 18, 20, 18)
        c_layout.setSpacing(12)

        # Header
        h_row = QHBoxLayout()
        h_row.setSpacing(10)

        icon_lbl = QLabel(card)
        icon_name = "lock" if "Lock" in title else "sparkle"
        icon_color = "#EF4444" if is_destructive else Palette.ACCENT_CYAN
        icon_lbl.setPixmap(get_pixmap(icon_name, color=icon_color, size=24))

        title_lbl = QLabel(title, card)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 15px; font-weight: 800;")

        h_row.addWidget(icon_lbl)
        h_row.addWidget(title_lbl)
        h_row.addStretch()

        # Message Body
        msg_lbl = QLabel(message, card)
        msg_lbl.setWordWrap(True)
        msg_lbl.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 18px;")

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_row.addStretch()

        cancel_btn = SecondaryButton("Cancel", parent=card)
        cancel_btn.clicked.connect(self.reject)

        if is_destructive:
            confirm_btn = DangerButton("Confirm Action", parent=card)
        else:
            confirm_btn = PrimaryButton("Proceed", parent=card)
        confirm_btn.clicked.connect(self.accept)

        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(confirm_btn)

        c_layout.addLayout(h_row)
        c_layout.addWidget(msg_lbl)
        c_layout.addStretch()
        c_layout.addLayout(btn_row)

        main_layout.addWidget(card)


class AboutDialog(QDialog):
    """Help / About Modal."""
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("About JARVIS AI")
        self.setFixedSize(460, 320)
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)

        card = QFrame(self)
        card.setStyleSheet("""
            QFrame {
                background-color: #101626;
                border: 1px solid #1F2D48;
                border-radius: 14px;
            }
        """)
        c_layout = QVBoxLayout(card)
        c_layout.setContentsMargins(24, 22, 24, 20)
        c_layout.setSpacing(12)
        c_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        logo = QLabel(card)
        logo.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=44))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel("JARVIS AI DESKTOP ASSISTANT", card)
        title.setStyleSheet("color: #F8FAFC; font-size: 16px; font-weight: 800; letter-spacing: 1.5px;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        ver = QLabel("Version 2.4.0 • College Expo Demonstration Edition", card)
        ver.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: 600;")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)

        desc = QLabel(
            "An enterprise desktop AI assistant engineered with Python 3.14 & PySide6.\n"
            "Features animated voice orb, audio waveform visualization, live system monitoring, "
            "asynchronous workers, and local persistent conversations.",
            card
        )
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc.setStyleSheet("color: #94A3B8; font-size: 11px; line-height: 16px;")

        close_btn = PrimaryButton("Close", parent=card)
        close_btn.clicked.connect(self.accept)

        c_layout.addWidget(logo)
        c_layout.addWidget(title)
        c_layout.addWidget(ver)
        c_layout.addWidget(desc)
        c_layout.addSpacing(6)
        c_layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        main_layout.addWidget(card)
