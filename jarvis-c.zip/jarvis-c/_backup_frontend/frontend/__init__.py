from frontend.main_window import MainWindow
from frontend.sidebar import SidebarWidget
from frontend.chat_view import ChatView
from frontend.chat_input import ChatInputWidget
from frontend.dashboard_view import DashboardView
from frontend.voice_view import VoiceView
from frontend.quick_actions_view import QuickActionsView
from frontend.system_panel import SystemPanelWidget
from frontend.settings_view import SettingsView
from frontend.dialogs import ActionConfirmationDialog, AboutDialog
