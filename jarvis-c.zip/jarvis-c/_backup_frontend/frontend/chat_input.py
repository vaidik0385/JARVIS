"""
JARVIS AI — Modern Multiline Chat Input & Mode A Voice Dictation
Supports multiline auto-expanding input, Enter-to-send (Shift+Enter for newline),
Mode A Voice Dictation with live duration counter and wave meter,
attachment picker with format validation, and direct voice mode shortcut.
"""

from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QPushButton,
    QLabel, QFrame, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QTimer, QSize, QEvent
from PySide6.QtGui import QKeyEvent
from styles.palette import Palette
from styles.icons import get_icon
from components.buttons import IconButton
from components.status_indicator import GlowingDot

class AutoExpandingInput(QTextEdit):
    send_pressed = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setPlaceholderText("Message JARVIS... (Shift + Enter for new line)")
        self.setFixedHeight(44)
        self.setStyleSheet("""
            QTextEdit {
                background-color: transparent;
                color: #F8FAFC;
                border: none;
                font-size: 13px;
                line-height: 20px;
                padding: 4px 6px;
                selection-background-color: #00E5FF;
                selection-color: #070A10;
            }
        """)
        self.textChanged.connect(self._adjust_height)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                super().keyPressEvent(event)
            else:
                self.send_pressed.emit()
        else:
            super().keyPressEvent(event)

    def _adjust_height(self):
        doc_height = int(self.document().size().height())
        new_height = max(44, min(140, doc_height + 10))
        self.setFixedHeight(new_height)


class ChatInputWidget(QWidget):
    message_sent = Signal(str)
    voice_dictation_requested = Signal(bool)  # is_recording
    live_voice_requested = Signal()
    attachment_added = Signal(str)

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._is_recording = False
        self._record_seconds = 0

        self._record_timer = QTimer(self)
        self._record_timer.timeout.connect(self._on_record_tick)

        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(6)

        # 1. Mode A Dictation Status Banner (Visible only while recording)
        self.dictation_banner = QFrame(self)
        self.dictation_banner.setStyleSheet("""
            QFrame {
                background-color: #1A121D;
                border: 1px solid #7F1D1D;
                border-radius: 8px;
                padding: 4px 10px;
            }
        """)
        dict_layout = QHBoxLayout(self.dictation_banner)
        dict_layout.setContentsMargins(10, 6, 10, 6)
        dict_layout.setSpacing(10)

        self.rec_dot = GlowingDot("#EF4444", size=12, parent=self.dictation_banner)
        self.rec_label = QLabel("RECORDING AUDIO (MODE A DICTATION)...", self.dictation_banner)
        self.rec_label.setStyleSheet("color: #EF4444; font-size: 11px; font-weight: 700; letter-spacing: 0.8px;")

        self.timer_label = QLabel("00:00", self.dictation_banner)
        self.timer_label.setStyleSheet("color: #F8FAFC; font-size: 12px; font-weight: 700; font-family: Consolas, monospace;")

        self.stop_rec_btn = QPushButton("Done Speaking", self.dictation_banner)
        self.stop_rec_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.stop_rec_btn.setStyleSheet("""
            QPushButton {
                background-color: #EF4444;
                color: #FFFFFF;
                border: none;
                border-radius: 4px;
                padding: 4px 12px;
                font-size: 11px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: #DC2626;
            }
        """)
        self.stop_rec_btn.clicked.connect(self._toggle_dictation)

        dict_layout.addWidget(self.rec_dot)
        dict_layout.addWidget(self.rec_label)
        dict_layout.addWidget(self.timer_label)
        dict_layout.addStretch()
        dict_layout.addWidget(self.stop_rec_btn)

        self.dictation_banner.hide()
        main_layout.addWidget(self.dictation_banner)

        # 2. Main Input Card Container
        self.input_container = QFrame(self)
        self.input_container.setStyleSheet("""
            QFrame {
                background-color: #0F1626;
                border: 1px solid #25334E;
                border-radius: 12px;
            }
            QFrame:hover {
                border: 1px solid #334466;
            }
        """)
        container_layout = QVBoxLayout(self.input_container)
        container_layout.setContentsMargins(12, 8, 12, 8)
        container_layout.setSpacing(8)

        # Text input area
        self.text_input = AutoExpandingInput(self.input_container)
        self.text_input.send_pressed.connect(self._on_send)
        container_layout.addWidget(self.text_input)

        # Bottom buttons row
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(0, 0, 0, 0)
        btn_row.setSpacing(6)

        # Attachment button
        self.attach_btn = IconButton("attach", tooltip="Attach File (Text, Code, PDF)", size=32, parent=self.input_container)
        self.attach_btn.clicked.connect(self._on_attach_clicked)

        # Live Voice Call Shortcut
        self.live_voice_btn = IconButton("sparkle", tooltip="Switch to Live Voice Assistant", size=32, icon_color=Palette.ACCENT_PURPLE, parent=self.input_container)
        self.live_voice_btn.clicked.connect(self.live_voice_requested.emit)

        # Mode A Mic Dictation Button
        self.mic_btn = IconButton("mic", tooltip="Voice Dictation (Click to speak into input)", size=32, parent=self.input_container)
        self.mic_btn.clicked.connect(self._toggle_dictation)

        # Send Button
        self.send_btn = IconButton("send", tooltip="Send Message (Enter)", size=32, icon_color=Palette.ACCENT_CYAN, parent=self.input_container)
        self.send_btn.clicked.connect(self._on_send)

        btn_row.addWidget(self.attach_btn)
        btn_row.addWidget(self.live_voice_btn)
        btn_row.addStretch()
        btn_row.addWidget(self.mic_btn)
        btn_row.addWidget(self.send_btn)

        container_layout.addLayout(btn_row)
        main_layout.addWidget(self.input_container)

    def _toggle_dictation(self):
        self._is_recording = not self._is_recording
        if self._is_recording:
            self.dictation_banner.show()
            self._record_seconds = 0
            self.timer_label.setText("00:00")
            self._record_timer.start(1000)
            self.mic_btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(239, 68, 68, 0.25);
                    border: 1px solid #EF4444;
                    border-radius: 16px;
                }
            """)
            self.voice_dictation_requested.emit(True)
        else:
            self._record_timer.stop()
            self.dictation_banner.hide()
            self.mic_btn.setStyleSheet("")
            self.voice_dictation_requested.emit(False)

            # Insert recognized transcript into chat input for review / editing
            # (Matches requirement: user speaks -> converts to editable text -> user presses Send)
            simulated_text = "What is the current laptop resource utilization and battery status?"
            current = self.text_input.toPlainText().strip()
            if current:
                self.text_input.setPlainText(f"{current} {simulated_text}")
            else:
                self.text_input.setPlainText(simulated_text)
            self.text_input.setFocus()

    def _on_record_tick(self):
        self._record_seconds += 1
        mins = self._record_seconds // 60
        secs = self._record_seconds % 60
        self.timer_label.setText(f"{mins:02d}:{secs:02d}")

    def _on_send(self):
        text = self.text_input.toPlainText().strip()
        if text:
            self.text_input.clear()
            self.message_sent.emit(text)

    def _on_attach_clicked(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Attach Document to JARVIS",
            "",
            "Supported Files (*.txt *.py *.md *.json *.pdf *.csv);;All Files (*.*)"
        )
        if file_path:
            self.attachment_added.emit(file_path)
            # Add reference note to input
            fname = file_path.split("/")[-1].split("\\")[-1]
            current = self.text_input.toPlainText().strip()
            note = f"[Attached: {fname}]\n"
            self.text_input.setPlainText(f"{note}{current}")
            self.text_input.setFocus()

    def set_text(self, text: str):
        self.text_input.setPlainText(text)
        self.text_input.setFocus()
