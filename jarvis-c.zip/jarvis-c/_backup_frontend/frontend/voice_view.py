"""
JARVIS AI — Mode B Dedicated Live Voice Conversation View
Immersive screen featuring a massive animated Voice Orb, flowing waveform visualizer,
live HUD conversation transcript, mic mute toggle, interrupt assistant control,
language detection badge (English/Hindi/Hinglish), and real-time state machine.
"""

from typing import Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QScrollArea, QComboBox
)
from PySide6.QtCore import Qt, Signal, QTimer, QSize
from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
from components.voice_orb import VoiceOrbWidget
from components.waveform import WaveformWidget
from components.status_indicator import GlowingDot
from components.buttons import PrimaryButton, DangerButton, IconButton

class VoiceView(QWidget):
    session_closed = Signal()
    mic_toggled = Signal(bool)       # is_muted
    interrupted = Signal()
    language_changed = Signal(str)

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._is_muted = False
        self._current_state = "listening"  # "listening", "thinking", "speaking", "idle", "muted"
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 24, 30, 24)
        main_layout.setSpacing(16)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # 1. Top HUD Bar (Title, Connection Status, Language Selector, Close)
        hud_bar = QHBoxLayout()
        hud_bar.setSpacing(12)

        title_box = QHBoxLayout()
        title_box.setSpacing(8)

        logo_lbl = QLabel(self)
        logo_lbl.setPixmap(get_pixmap("logo", color=Palette.ACCENT_CYAN, size=20))
        logo_lbl.setStyleSheet("border: none; background: transparent;")

        title_lbl = QLabel("LIVE VOICE CALL", self)
        title_lbl.setStyleSheet("color: #F8FAFC; font-size: 13px; font-weight: 800; letter-spacing: 1.2px;")

        title_box.addWidget(logo_lbl)
        title_box.addWidget(title_lbl)

        # Connection Pill
        conn_pill = QFrame(self)
        conn_pill.setStyleSheet("background-color: #12192A; border: 1px solid #1E2B45; border-radius: 12px; padding: 2px 10px;")
        cp_layout = QHBoxLayout(conn_pill)
        cp_layout.setContentsMargins(6, 2, 6, 2)
        cp_layout.setSpacing(6)
        c_dot = GlowingDot("#10B981", size=8, parent=conn_pill)
        c_txt = QLabel("DIRECT NEURAL STREAM", conn_pill)
        c_txt.setStyleSheet("color: #10B981; font-size: 10px; font-weight: 700; letter-spacing: 0.8px; border: none; background: transparent;")
        cp_layout.addWidget(c_dot)
        cp_layout.addWidget(c_txt)

        # Language Selector
        self.lang_box = QComboBox(self)
        self.lang_box.addItems(["Auto (English / Hindi / Hinglish)", "English (US)", "Hindi (India)"])
        self.lang_box.setStyleSheet("""
            QComboBox {
                background-color: #121828;
                color: #CBD5E1;
                border: 1px solid #202D45;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }
        """)
        self.lang_box.currentTextChanged.connect(self.language_changed.emit)

        # End Call Button
        self.end_call_btn = QPushButton("End Session", self)
        self.end_call_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.end_call_btn.setIcon(get_icon("phone_off", color="#EF4444", size=14))
        self.end_call_btn.setIconSize(QSize(14, 14))
        self.end_call_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(239, 68, 68, 0.15);
                color: #EF4444;
                border: 1px solid rgba(239, 68, 68, 0.4);
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 11px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: rgba(239, 68, 68, 0.3);
                border: 1px solid #EF4444;
            }
        """)
        self.end_call_btn.clicked.connect(self.session_closed.emit)

        hud_bar.addLayout(title_box)
        hud_bar.addWidget(conn_pill)
        hud_bar.addStretch()
        hud_bar.addWidget(self.lang_box)
        hud_bar.addWidget(self.end_call_btn)

        main_layout.addLayout(hud_bar)

        # 2. Central Immersive Canvas
        center_card = QFrame(self)
        center_card.setStyleSheet("""
            QFrame {
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #101726, stop:1 #080D18);
                border: 1px solid #1C273E;
                border-radius: 20px;
            }
        """)
        center_layout = QVBoxLayout(center_card)
        center_layout.setContentsMargins(24, 28, 24, 24)
        center_layout.setSpacing(16)
        center_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # State Pill Banner (e.g. "LISTENING TO CREATOR...")
        self.state_banner = QFrame(center_card)
        self.state_banner.setStyleSheet("background-color: #141D30; border: 1px solid #202E4C; border-radius: 14px; padding: 4px 16px;")
        sb_layout = QHBoxLayout(self.state_banner)
        sb_layout.setContentsMargins(10, 4, 10, 4)
        sb_layout.setSpacing(8)

        self.state_dot = GlowingDot("#00E5FF", size=10, parent=self.state_banner)
        self.state_text = QLabel("JARVIS IS LISTENING...", self.state_banner)
        self.state_text.setStyleSheet("color: #00E5FF; font-size: 12px; font-weight: 800; letter-spacing: 1.5px; border: none; background: transparent;")

        sb_layout.addWidget(self.state_dot)
        sb_layout.addWidget(self.state_text)
        center_layout.addWidget(self.state_banner, alignment=Qt.AlignmentFlag.AlignCenter)

        # Massive Voice Orb (240px)
        self.orb = VoiceOrbWidget(size=240, parent=center_card)
        self.orb.set_state("listening")
        center_layout.addWidget(self.orb, alignment=Qt.AlignmentFlag.AlignCenter)

        # Audio Waveform
        self.waveform = WaveformWidget(height=52, bar_count=48, parent=center_card)
        self.waveform.set_amplitude(0.6)
        center_layout.addWidget(self.waveform)

        # Live Transcript HUD Subtitle Bubble
        self.transcript_card = QFrame(center_card)
        self.transcript_card.setStyleSheet("""
            QFrame {
                background-color: rgba(14, 20, 34, 0.85);
                border: 1px solid #223252;
                border-radius: 12px;
                padding: 12px 18px;
            }
        """)
        t_layout = QVBoxLayout(self.transcript_card)
        t_layout.setContentsMargins(14, 10, 14, 10)
        t_layout.setSpacing(4)

        self.speaker_label = QLabel("USER:", self.transcript_card)
        self.speaker_label.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700; letter-spacing: 1px; border: none; background: transparent;")

        self.transcript_text = QLabel("“What is the operational status of our workstation subsystems?”", self.transcript_card)
        self.transcript_text.setWordWrap(True)
        self.transcript_text.setStyleSheet("color: #F8FAFC; font-size: 14px; font-style: italic; line-height: 20px; border: none; background: transparent;")

        t_layout.addWidget(self.speaker_label)
        t_layout.addWidget(self.transcript_text)
        center_layout.addWidget(self.transcript_card)

        main_layout.addWidget(center_card, stretch=1)

        # 3. Bottom Controls Toolbar
        controls_row = QHBoxLayout()
        controls_row.setSpacing(14)
        controls_row.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Mic Mute Toggle
        self.mute_btn = QPushButton("  Mute Microphone", self)
        self.mute_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.mute_btn.setIcon(get_icon("mic", color=Palette.TEXT_PRIMARY, size=18))
        self.mute_btn.setIconSize(QSize(18, 18))
        self.mute_btn.setStyleSheet("""
            QPushButton {
                background-color: #172138;
                color: #F8FAFC;
                border: 1px solid #25334E;
                border-radius: 10px;
                padding: 10px 20px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #202D4A;
                border: 1px solid #00E5FF;
            }
        """)
        self.mute_btn.clicked.connect(self._toggle_mute)

        # Interrupt Assistant Button (Barge-in)
        self.interrupt_btn = QPushButton("  Interrupt / Tap to Speak", self)
        self.interrupt_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.interrupt_btn.setIcon(get_icon("stop", color="#070A10", size=16))
        self.interrupt_btn.setIconSize(QSize(16, 16))
        self.interrupt_btn.setStyleSheet("""
            QPushButton {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00E5FF, stop:1 #3B82F6);
                color: #070A10;
                border: none;
                border-radius: 10px;
                padding: 10px 22px;
                font-size: 13px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #38BDF8, stop:1 #60A5FA);
            }
        """)
        self.interrupt_btn.clicked.connect(self._on_interrupt)

        controls_row.addWidget(self.mute_btn)
        controls_row.addWidget(self.interrupt_btn)

        main_layout.addLayout(controls_row)

    def _toggle_mute(self):
        self._is_muted = not self._is_muted
        if self._is_muted:
            self.mute_btn.setText("  Unmute Microphone")
            self.mute_btn.setIcon(get_icon("mute", color="#EF4444", size=18))
            self.mute_btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(239, 68, 68, 0.15);
                    color: #EF4444;
                    border: 1px solid #EF4444;
                    border-radius: 10px;
                    padding: 10px 20px;
                    font-size: 13px;
                    font-weight: 600;
                }
            """)
            self.set_state("muted")
        else:
            self.mute_btn.setText("  Mute Microphone")
            self.mute_btn.setIcon(get_icon("mic", color=Palette.TEXT_PRIMARY, size=18))
            self.mute_btn.setStyleSheet("""
                QPushButton {
                    background-color: #172138;
                    color: #F8FAFC;
                    border: 1px solid #25334E;
                    border-radius: 10px;
                    padding: 10px 20px;
                    font-size: 13px;
                    font-weight: 600;
                }
            """)
            self.set_state("listening")
        self.mic_toggled.emit(self._is_muted)

    def _on_interrupt(self):
        self.set_transcript("USER:", "Interrupted assistant.")
        self.set_state("listening")
        self.interrupted.emit()

    def set_state(self, state: str):
        self._current_state = state
        self.orb.set_state(state)

        if state == "listening":
            self.state_text.setText("JARVIS IS LISTENING...")
            self.state_text.setStyleSheet("color: #00E5FF; font-size: 12px; font-weight: 800; letter-spacing: 1.5px;")
            self.state_dot.set_color("#00E5FF")
            self.waveform.set_amplitude(0.55)
        elif state == "thinking":
            self.state_text.setText("SYNTHESIZING RESPONSE...")
            self.state_text.setStyleSheet("color: #A855F7; font-size: 12px; font-weight: 800; letter-spacing: 1.5px;")
            self.state_dot.set_color("#A855F7")
            self.waveform.set_amplitude(0.35)
        elif state == "speaking":
            self.state_text.setText("JARVIS IS SPEAKING...")
            self.state_text.setStyleSheet("color: #38BDF8; font-size: 12px; font-weight: 800; letter-spacing: 1.5px;")
            self.state_dot.set_color("#38BDF8")
            self.waveform.set_amplitude(0.85)
        elif state == "muted":
            self.state_text.setText("MICROPHONE MUTED")
            self.state_text.setStyleSheet("color: #EF4444; font-size: 12px; font-weight: 800; letter-spacing: 1.5px;")
            self.state_dot.set_color("#EF4444")
            self.waveform.set_amplitude(0.05)

    def set_transcript(self, speaker: str, text: str):
        self.speaker_label.setText(speaker.upper())
        self.transcript_text.setText(f"“{text}”")
