"""
JARVIS AI — Advanced Desktop Assistant
Root Application Entry Point
"""

import sys
import os
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from frontend.main_window import MainWindow

def load_stylesheet(app: QApplication):
    qss_path = os.path.join(os.path.dirname(__file__), "styles", "theme.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r", encoding="utf-8") as f:
            stylesheet = f.read()
            app.setStyleSheet(stylesheet)
    else:
        print(f"[Warning] Stylesheet not found at {qss_path}")

def main():
    # 1. Enable High DPI Scaling & Smooth Font Rendering
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("JARVIS AI")
    app.setApplicationDisplayName("JARVIS AI Desktop Assistant")
    app.setOrganizationName("JARVIS Systems")

    # Set Global App Font
    font = QFont("Segoe UI", 10)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    app.setFont(font)

    # 2. Apply Master Stylesheet
    load_stylesheet(app)

    # 3. Instantiate and Display Window
    window = MainWindow()
    window.show()

    # 4. Execute Qt Event Loop
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
