"""
JARVIS AI — Circular & Bar Metric Gauges
Renders circular percentage arcs and progress gauges with gradient fills.
Used in System Information panel and Dashboard performance cards.
"""

from typing import Optional
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QRectF, QPointF
from PySide6.QtGui import QPainter, QColor, QPen, QRadialGradient, QLinearGradient, QFont

class CircularGaugeWidget(QWidget):
    def __init__(self, title: str = "CPU", unit: str = "%", size: int = 100, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.title = title
        self.unit = unit
        self._value = 0.0  # 0.0 to 100.0
        self.setFixedSize(size, size)

    def set_value(self, val: float):
        self._value = max(0.0, min(100.0, val))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        center = QPointF(w / 2.0, h / 2.0)
        radius = min(w, h) * 0.42
        pen_width = max(6.0, radius * 0.16)

        rect = QRectF(center.x() - radius, center.y() - radius, radius * 2, radius * 2)

        # Background track arc
        track_pen = QPen(QColor("#1C263B"), pen_width)
        track_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(track_pen)
        painter.drawArc(rect, -45 * 16, -270 * 16)

        # Dynamic arc color based on value (Cyan -> Blue -> Amber -> Red if critical)
        if self._value > 85.0:
            arc_color = QColor("#EF4444")
        elif self._value > 70.0:
            arc_color = QColor("#F59E0B")
        else:
            arc_color = QColor("#00E5FF")

        # Value active arc
        span_angle = -int((self._value / 100.0) * 270.0 * 16)
        active_pen = QPen(arc_color, pen_width)
        active_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(active_pen)
        painter.drawArc(rect, -45 * 16, span_angle)

        # Inner Text: Value
        painter.setPen(QColor("#F8FAFC"))
        font_val = QFont("Segoe UI", int(radius * 0.42), QFont.Weight.Bold)
        painter.setFont(font_val)
        val_str = f"{int(self._value)}"
        painter.drawText(QRectF(0, center.y() - radius * 0.45, w, radius * 0.6), Qt.AlignmentFlag.AlignCenter, val_str)

        # Inner Text: Unit & Title
        painter.setPen(QColor("#94A3B8"))
        font_sub = QFont("Segoe UI", int(radius * 0.22), QFont.Weight.DemiBold)
        painter.setFont(font_sub)
        sub_str = f"{self.unit}  {self.title}"
        painter.drawText(QRectF(0, center.y() + radius * 0.05, w, radius * 0.4), Qt.AlignmentFlag.AlignCenter, sub_str)

        painter.end()


class BarGaugeWidget(QWidget):
    def __init__(self, label: str, height: int = 40, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.label = label
        self._value = 0.0
        self._detail_text = ""
        self.setFixedHeight(height)

    def set_value(self, val: float, detail: str = ""):
        self._value = max(0.0, min(100.0, val))
        self._detail_text = detail
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()

        # Text labels on top row
        painter.setPen(QColor("#CBD5E1"))
        font_lbl = QFont("Segoe UI", 10, QFont.Weight.Medium)
        painter.setFont(font_lbl)
        painter.drawText(0, 14, self.label)

        # Detail on right (e.g. "8.2 / 16.0 GB")
        painter.setPen(QColor("#94A3B8"))
        painter.drawText(QRectF(0, 0, w, 16), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, self._detail_text or f"{int(self._value)}%")

        # Track bar
        track_y = 22
        track_h = 6
        painter.setBrush(QColor("#162032"))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, track_y, w, track_h, 3, 3)

        # Progress fill
        fill_w = max(0, int((self._value / 100.0) * w))
        if fill_w > 0:
            grad = QLinearGradient(0, 0, w, 0)
            if self._value > 85.0:
                grad.setColorAt(0.0, QColor("#F59E0B"))
                grad.setColorAt(1.0, QColor("#EF4444"))
            else:
                grad.setColorAt(0.0, QColor("#00E5FF"))
                grad.setColorAt(1.0, QColor("#3B82F6"))

            painter.setBrush(grad)
            painter.drawRoundedRect(0, track_y, fill_w, track_h, 3, 3)

        painter.end()
