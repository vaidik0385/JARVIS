"""
JARVIS AI — Dynamic Audio Waveform Visualizer
Renders flowing sinusoidal energy waveforms and animated frequency bars
reacting to voice states and live speech amplitude.
"""

import math
from typing import Optional, List
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QTimer, QPointF
from PySide6.QtGui import (
    QPainter, QColor, QPen, QLinearGradient, QPainterPath
)

class WaveformWidget(QWidget):
    def __init__(self, height: int = 60, bar_count: int = 36, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setFixedHeight(height)
        self.bar_count = bar_count
        self._phase = 0.0
        self._amplitude = 0.3
        self._is_active = True
        self._frequency_data: List[float] = [0.2] * bar_count

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start(30)

    def set_amplitude(self, amp: float):
        self._amplitude = max(0.05, min(1.0, amp))
        self.update()

    def set_active(self, active: bool):
        self._is_active = active
        self.update()

    def set_spectrum_data(self, data: List[float]):
        if data:
            self._frequency_data = data[:self.bar_count]
            # Pad if shorter
            if len(self._frequency_data) < self.bar_count:
                self._frequency_data += [0.1] * (self.bar_count - len(self._frequency_data))
            self.update()

    def _on_tick(self):
        if not self._is_active:
            return
        self._phase = (self._phase + 0.08) % (2 * math.pi)

        # Generate smooth synthetic wave spectrum if live data not streamed
        for i in range(self.bar_count):
            t = (i / self.bar_count) * 4 * math.pi + self._phase
            val = (math.sin(t) * 0.4 + math.cos(t * 1.5) * 0.3 + 0.5) * self._amplitude
            self._frequency_data[i] = max(0.08, min(0.95, val))

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        mid_y = h / 2.0

        # Background subtle guide line
        line_pen = QPen(QColor(37, 51, 78, 60), 1.0, Qt.PenStyle.DashLine)
        painter.setPen(line_pen)
        painter.drawLine(0, int(mid_y), w, int(mid_y))

        # Bar Visualizer Mode
        total_gap = 4.0
        bar_w = max(2.5, (w - (self.bar_count - 1) * total_gap) / self.bar_count)

        # Gradient for bars (Cyan -> Electric Blue -> Violet)
        grad = QLinearGradient(0, 0, w, 0)
        grad.setColorAt(0.0, QColor("#00E5FF"))
        grad.setColorAt(0.5, QColor("#38BDF8"))
        grad.setColorAt(1.0, QColor("#8B5CF6"))

        painter.setBrush(grad)
        painter.setPen(Qt.PenStyle.NoPen)

        for i in range(self.bar_count):
            x = i * (bar_w + total_gap)
            bar_height = max(4.0, self._frequency_data[i] * (h * 0.85))
            y = mid_y - (bar_height / 2.0)
            painter.drawRoundedRect(x, y, bar_w, bar_height, bar_w / 2.0, bar_w / 2.0)

        # Continuous smooth overlay line with cyan glow
        path = QPainterPath()
        path.moveTo(0, mid_y)
        step = w / float(self.bar_count - 1)

        for i in range(self.bar_count):
            px = i * step
            py = mid_y - (self._frequency_data[i] * (h * 0.45))
            if i == 0:
                path.moveTo(px, py)
            else:
                prev_x = (i - 1) * step
                cx = (prev_x + px) / 2.0
                path.quadTo(cx, py, px, py)

        glow_pen = QPen(QColor(0, 229, 255, 160), 1.8)
        painter.setPen(glow_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

        painter.end()
