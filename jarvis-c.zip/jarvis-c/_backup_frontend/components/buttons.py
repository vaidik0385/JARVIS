"""
JARVIS AI — Styled Interactive Buttons
Custom buttons with micro-interactions, gradient fills, and tooltips.
"""

from typing import Optional
from PySide6.QtWidgets import QPushButton, QWidget
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QIcon
from styles.palette import Palette
from styles.icons import get_icon

class PrimaryButton(QPushButton):
    def __init__(self, text: str, icon_name: Optional[str] = None, parent: Optional[QWidget] = None):
        super().__init__(text, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if icon_name:
            self.setIcon(get_icon(icon_name, color="#070A10", size=16))
            self.setIconSize(QSize(16, 16))

        self.setStyleSheet("""
            QPushButton {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00E5FF, stop:1 #3B82F6);
                color: #070A10;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-size: 13px;
                font-weight: 700;
                letter-spacing: 0.4px;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #38BDF8, stop:1 #60A5FA);
            }
            QPushButton:pressed {
                background-color: #00B4D8;
            }
        """)


class SecondaryButton(QPushButton):
    def __init__(self, text: str, icon_name: Optional[str] = None, parent: Optional[QWidget] = None):
        super().__init__(text, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if icon_name:
            self.setIcon(get_icon(icon_name, color=Palette.TEXT_PRIMARY, size=16))
            self.setIconSize(QSize(16, 16))

        self.setStyleSheet("""
            QPushButton {
                background-color: #172138;
                color: #F8FAFC;
                border: 1px solid #25334E;
                border-radius: 8px;
                padding: 8px 16px;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #1F2D4D;
                border: 1px solid #38BDF8;
            }
            QPushButton:pressed {
                background-color: #121A2E;
            }
        """)


class IconButton(QPushButton):
    def __init__(self, icon_name: str, tooltip: str = "", size: int = 36, icon_color: str = Palette.TEXT_SECONDARY, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(size, size)
        self.setToolTip(tooltip)
        self._icon_name = icon_name
        self.setIcon(get_icon(icon_name, color=icon_color, size=int(size * 0.55)))
        self.setIconSize(QSize(int(size * 0.55), int(size * 0.55)))

        self.setStyleSheet(f"""
            QPushButton {{
                background-color: #141B2D;
                border: 1px solid #202D45;
                border-radius: {size // 2}px;
                padding: 0px;
            }}
            QPushButton:hover {{
                background-color: #1D2842;
                border: 1px solid #00E5FF;
            }}
            QPushButton:pressed {{
                background-color: #0F1524;
            }}
        """)

    def set_icon_state(self, icon_name: str, color: str = Palette.TEXT_SECONDARY):
        size = self.width()
        self.setIcon(get_icon(icon_name, color=color, size=int(size * 0.55)))


class DangerButton(QPushButton):
    def __init__(self, text: str, icon_name: Optional[str] = None, parent: Optional[QWidget] = None):
        super().__init__(text, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if icon_name:
            self.setIcon(get_icon(icon_name, color="#EF4444", size=16))
            self.setIconSize(QSize(16, 16))

        self.setStyleSheet("""
            QPushButton {
                background-color: rgba(239, 68, 68, 0.12);
                color: #EF4444;
                border: 1px solid rgba(239, 68, 68, 0.35);
                border-radius: 8px;
                padding: 8px 16px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: rgba(239, 68, 68, 0.25);
                border: 1px solid #EF4444;
            }
        """)
