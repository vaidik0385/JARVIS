"""
JARVIS AI — Status & Privacy Indicators
Glowing status pills and privacy verification badges.
"""

from typing import Optional
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel
from PySide6.QtCore import Qt, QPointF
from PySide6.QtGui import QPainter, QColor, QBrush, QPen
from styles.palette import Palette

class GlowingDot(QWidget):
    def __init__(self, color: str = Palette.STATUS_ONLINE, size: int = 12, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._color = QColor(color)

    def set_color(self, color: str):
        self._color = QColor(color)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        s = min(self.width(), self.height())
        center = QPointF(s / 2.0, s / 2.0)

        # Outer faint halo
        halo_c = QColor(self._color.red(), self._color.green(), self._color.blue(), 50)
        painter.setBrush(QBrush(halo_c))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(center, s * 0.45, s * 0.45)

        # Inner solid dot
        painter.setBrush(QBrush(self._color))
        painter.drawEllipse(center, s * 0.25, s * 0.25)
        painter.end()


class StatusIndicatorWidget(QWidget):
    def __init__(self, label: str = "Ready", status_color: str = Palette.STATUS_ONLINE, parent: Optional[QWidget] = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 2, 6, 2)
        layout.setSpacing(8)

        self.dot = GlowingDot(color=status_color, size=14, parent=self)
        self.text_label = QLabel(label, self)
        self.text_label.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 600; letter-spacing: 0.5px;")

        layout.addWidget(self.dot)
        layout.addWidget(self.text_label)

    def set_status(self, label: str, color: str):
        self.text_label.setText(label)
        self.dot.set_color(color)


class PrivacyBadge(QWidget):
    """Visible privacy shield badge demonstrating offline local security."""
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)

        self.setStyleSheet("""
            QWidget {
                background-color: #12192A;
                border: 1px solid #1E2D4A;
                border-radius: 6px;
            }
        """)

        dot = GlowingDot(color="#10B981", size=10, parent=self)
        lbl = QLabel("SYSTEM SHIELD: ACTIVE & PRIVATE", self)
        lbl.setStyleSheet("color: #38BDF8; font-size: 10px; font-weight: 700; letter-spacing: 0.8px; border: none; background: transparent;")

        layout.addWidget(dot)
        layout.addWidget(lbl)
