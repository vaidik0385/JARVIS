"""
JARVIS AI — Elevated Surface Cards
Reusable glassmorphic cards, action trigger cards, and telemetry cards.
"""

from typing import Optional
from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel, QWidget
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QMouseEvent
from styles.palette import Palette
from styles.icons import get_pixmap

class GlassCard(QFrame):
    """Clean elevated surface card with modern border and padding."""
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("glassCard")
        self.setStyleSheet("""
            #glassCard {
                background-color: #121828;
                border: 1px solid #1C263B;
                border-radius: 12px;
            }
        """)

class ActionTriggerCard(QFrame):
    """
    Clickable quick-action card with icon, title, description, and hover border glow.
    Used for the 4 central welcome cards on Dashboard & Chat.
    """
    clicked = Signal()

    def __init__(self, icon_name: str, title: str, description: str, accent_color: str = Palette.ACCENT_CYAN, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._accent = accent_color

        self.setStyleSheet(f"""
            ActionTriggerCard {{
                background-color: #131B2E;
                border: 1px solid #202D47;
                border-radius: 12px;
                padding: 14px;
            }}
            ActionTriggerCard:hover {{
                background-color: #18233C;
                border: 1px solid {self._accent};
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(8)

        # Top icon row
        top_row = QHBoxLayout()
        top_row.setSpacing(10)

        self.icon_lbl = QLabel(self)
        self.icon_lbl.setPixmap(get_pixmap(icon_name, color=self._accent, size=24))
        self.icon_lbl.setStyleSheet("border: none; background: transparent;")

        self.title_lbl = QLabel(title, self)
        self.title_lbl.setStyleSheet(f"color: #F8FAFC; font-size: 14px; font-weight: 600; border: none; background: transparent;")

        top_row.addWidget(self.icon_lbl)
        top_row.addWidget(self.title_lbl)
        top_row.addStretch()

        self.desc_lbl = QLabel(description, self)
        self.desc_lbl.setWordWrap(True)
        self.desc_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; line-height: 14px; border: none; background: transparent;")

        layout.addLayout(top_row)
        layout.addWidget(self.desc_lbl)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)


class TelemetryCard(QFrame):
    """Metric display card for right system panel."""
    def __init__(self, icon_name: str, title: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setStyleSheet("""
            TelemetryCard {
                background-color: #121829;
                border: 1px solid #1C263B;
                border-radius: 10px;
            }
        """)

        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(12, 12, 12, 12)
        self.layout.setSpacing(8)

        # Header with icon and title
        header = QHBoxLayout()
        header.setSpacing(8)

        icon_lbl = QLabel(self)
        icon_lbl.setPixmap(get_pixmap(icon_name, color=Palette.ACCENT_CYAN, size=18))
        icon_lbl.setStyleSheet("border: none; background: transparent;")

        title_lbl = QLabel(title.upper(), self)
        title_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 700; letter-spacing: 1px; border: none; background: transparent;")

        header.addWidget(icon_lbl)
        header.addWidget(title_lbl)
        header.addStretch()

        self.layout.addLayout(header)

    def add_widget(self, widget: QWidget):
        self.layout.addWidget(widget)

    def add_layout(self, layout):
        self.layout.addLayout(layout)
