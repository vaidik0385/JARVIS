"""
JARVIS AI — Futuristic Animated Voice Orb
Multi-layered glowing plasma sphere with rotating orbital arcs,
breathing pulse, and reactive state transitions (Idle, Listening, Thinking, Speaking, Muted).
Built with pure QPainter and QTimer for silky-smooth 40 FPS performance.
"""

import math
from typing import Optional
from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
from PySide6.QtGui import (
    QPainter, QColor, QRadialGradient, QConicalGradient,
    QPen, QBrush, QPainterPath
)
from styles.palette import Palette

class VoiceOrbWidget(QWidget):
    def __init__(self, size: int = 220, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.orb_size = size
        self.setFixedSize(size, size)

        # State: "idle", "listening", "thinking", "speaking", "muted"
        self._state = "idle"
        self._angle = 0.0
        self._pulse_phase = 0.0
        self._amplitude = 0.2  # 0.0 to 1.0 (audio reactivity)

        # Timer for animation (~35-40 FPS)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start(25)

    def set_state(self, state: str):
        valid = ("idle", "listening", "thinking", "speaking", "muted")
        self._state = state if state in valid else "idle"
        self.update()

    def set_amplitude(self, amp: float):
        self._amplitude = max(0.0, min(1.0, amp))
        self.update()

    def _on_tick(self):
        # Update rotation angle
        speed = 1.0
        if self._state == "thinking":
            speed = 3.5
        elif self._state == "speaking":
            speed = 2.0
        elif self._state == "listening":
            speed = 1.5

        self._angle = (self._angle + speed) % 360.0
        self._pulse_phase = (self._pulse_phase + 0.05) % (2 * math.pi)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        center = QPointF(w / 2.0, h / 2.0)
        base_radius = min(w, h) * 0.36

        # Calculate breathing pulse scale
        pulse = math.sin(self._pulse_phase) * 0.08
        if self._state == "listening":
            pulse += self._amplitude * 0.15
        elif self._state == "speaking":
            pulse += (math.sin(self._pulse_phase * 2) * 0.12) + (self._amplitude * 0.2)

        orb_radius = base_radius * (1.0 + pulse)

        # Palette colors based on state
        if self._state == "muted":
            core_c1 = QColor("#EF4444")
            core_c2 = QColor("#7F1D1D")
            glow_c  = QColor(239, 68, 68, 40)
            ring_c  = QColor(239, 68, 68, 120)
        elif self._state == "thinking":
            core_c1 = QColor("#C084FC")
            core_c2 = QColor("#7C3AED")
            glow_c  = QColor(139, 92, 246, 50)
            ring_c  = QColor(168, 85, 247, 180)
        elif self._state == "speaking":
            core_c1 = QColor("#38BDF8")
            core_c2 = QColor("#8B5CF6")
            glow_c  = QColor(0, 229, 255, 70)
            ring_c  = QColor(56, 189, 248, 220)
        elif self._state == "listening":
            core_c1 = QColor("#00E5FF")
            core_c2 = QColor("#0284C7")
            glow_c  = QColor(0, 229, 255, 80)
            ring_c  = QColor(0, 229, 255, 200)
        else: # idle
            core_c1 = QColor("#00E5FF")
            core_c2 = QColor("#1E3A8A")
            glow_c  = QColor(0, 229, 255, 30)
            ring_c  = QColor(0, 229, 255, 90)

        # 1. Outer Ambient Glow Halo
        glow_rad = orb_radius * 1.65
        glow_grad = QRadialGradient(center, glow_rad)
        glow_grad.setColorAt(0.0, glow_c)
        glow_grad.setColorAt(0.5, QColor(glow_c.red(), glow_c.green(), glow_c.blue(), int(glow_c.alpha() * 0.4)))
        glow_grad.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setBrush(QBrush(glow_grad))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(center, glow_rad, glow_rad)

        # 2. Orbital Rotating Ring 1
        ring1_rad = orb_radius * 1.25
        painter.save()
        painter.translate(center)
        painter.rotate(self._angle)
        ring_pen1 = QPen(ring_c, 1.5, Qt.PenStyle.DashLine)
        ring_pen1.setDashPattern([12, 10, 4, 10])
        painter.setPen(ring_pen1)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QPointF(0, 0), ring1_rad, ring1_rad)
        painter.restore()

        # 3. Orbital Counter-Rotating Ring 2
        ring2_rad = orb_radius * 1.42
        painter.save()
        painter.translate(center)
        painter.rotate(-self._angle * 0.7)
        ring_pen2 = QPen(QColor(ring_c.red(), ring_c.green(), ring_c.blue(), int(ring_c.alpha() * 0.6)), 1.2, Qt.PenStyle.DotLine)
        painter.setPen(ring_pen2)
        painter.drawEllipse(QPointF(0, 0), ring2_rad, ring2_rad)
        painter.restore()

        # 4. Core Plasma Orb (Multi-stop Radial Gradient)
        core_grad = QRadialGradient(QPointF(center.x() - orb_radius * 0.25, center.y() - orb_radius * 0.25), orb_radius * 1.2)
        core_grad.setColorAt(0.0, QColor("#FFFFFF"))
        core_grad.setColorAt(0.2, core_c1)
        core_grad.setColorAt(0.65, core_c2)
        core_grad.setColorAt(0.95, QColor("#080D1A"))
        core_grad.setColorAt(1.0, QColor(8, 13, 26, 0))

        painter.setBrush(QBrush(core_grad))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(center, orb_radius, orb_radius)

        # 5. Inner Dynamic Ripple / Energy Arcs
        painter.save()
        painter.translate(center)
        painter.rotate(self._angle * 1.8)
        inner_pen = QPen(QColor(255, 255, 255, 120), 1.8)
        painter.setPen(inner_pen)
        inner_r = orb_radius * 0.55
        rect_inner = QRectF(-inner_r, -inner_r, inner_r * 2, inner_r * 2)
        painter.drawArc(rect_inner, 30 * 16, 120 * 16)
        painter.drawArc(rect_inner, 210 * 16, 100 * 16)
        painter.restore()

        # 6. Central Specular Highlight Reflection
        spec_center = QPointF(center.x() - orb_radius * 0.35, center.y() - orb_radius * 0.35)
        spec_grad = QRadialGradient(spec_center, orb_radius * 0.4)
        spec_grad.setColorAt(0.0, QColor(255, 255, 255, 140))
        spec_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.setBrush(QBrush(spec_grad))
        painter.drawEllipse(spec_center, orb_radius * 0.35, orb_radius * 0.35)

        painter.end()
