"""
JARVIS AI — Real System Monitoring Service
Runs in a background QThread to poll genuine laptop metrics via psutil and Windows APIs.
Safe, non-blocking, zero impact on UI responsiveness.
"""

import socket
import os
import shutil
from typing import Optional
from PySide6.QtCore import QThread, Signal, QObject
import psutil

from services.frontend_interfaces import SystemMetrics

class SystemMonitorWorker(QThread):
    metrics_ready = Signal(object)  # SystemMetrics
    network_status_changed = Signal(bool)

    def __init__(self, poll_interval_ms: int = 1500, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._poll_interval_s = poll_interval_ms / 1000.0
        self._running = True
        self._last_network_status = None
        self._network_check_counter = 0

    def run(self):
        # Prime psutil cpu measurement
        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass

        while self._running:
            try:
                metrics = self._collect_metrics()
                self.metrics_ready.emit(metrics)

                # Periodically test internet connectivity every ~6s (every 4 loops)
                self._network_check_counter += 1
                if self._network_check_counter >= 4 or self._last_network_status is None:
                    self._network_check_counter = 0
                    online = self._check_internet()
                    if online != self._last_network_status:
                        self._last_network_status = online
                        self.network_status_changed.emit(online)

            except Exception as e:
                print(f"[SystemMonitor] Error reading metrics: {e}")

            # Sleep in small increments for responsive stop
            sleep_step = 0.2
            elapsed = 0.0
            while self._running and elapsed < self._poll_interval_s:
                self.msleep(int(sleep_step * 1000))
                elapsed += sleep_step

    def stop(self):
        self._running = False
        self.wait(1000)

    def _collect_metrics(self) -> SystemMetrics:
        # CPU
        cpu_pct = psutil.cpu_percent(interval=None)

        # RAM
        vm = psutil.virtual_memory()
        ram_pct = vm.percent
        ram_used_gb = round(vm.used / (1024 ** 3), 1)
        ram_total_gb = round(vm.total / (1024 ** 3), 1)

        # Disk (Root drive C: on Windows or current working drive)
        drive_path = os.path.splitdrive(os.getcwd())[0] or "C:"
        if not drive_path.endswith("\\"):
            drive_path += "\\"
        try:
            disk = psutil.disk_usage(drive_path)
            disk_pct = disk.percent
        except Exception:
            total, used, free = shutil.disk_usage(os.getcwd())
            disk_pct = round((used / total) * 100, 1)

        # Battery
        battery_pct = 100
        is_charging = True
        battery_health = "AC Powered"
        try:
            battery = psutil.sensors_battery()
            if battery is not None:
                battery_pct = int(battery.percent)
                is_charging = bool(battery.power_plugged)
                battery_health = "Charging" if is_charging else "Discharging"
            else:
                battery_health = "Desktop (AC)"
        except Exception:
            pass

        # Mic & Speaker availability check
        mic_ok = True
        speaker_ok = True
        try:
            import sounddevice as sd
            devices = sd.query_devices()
            has_input = any(d.get('max_input_channels', 0) > 0 for d in devices)
            has_output = any(d.get('max_output_channels', 0) > 0 for d in devices)
            mic_ok = has_input
            speaker_ok = has_output
        except Exception:
            mic_ok = True
            speaker_ok = True

        return SystemMetrics(
            cpu_percent=cpu_pct,
            ram_percent=ram_pct,
            ram_used_gb=ram_used_gb,
            ram_total_gb=ram_total_gb,
            disk_percent=disk_pct,
            battery_percent=battery_pct,
            is_charging=is_charging,
            battery_health=battery_health,
            network_online=self._last_network_status if self._last_network_status is not None else True,
            ai_backend_connected=False,
            mic_available=mic_ok,
            speaker_available=speaker_ok
        )

    def _check_internet(self) -> bool:
        """Fast non-blocking socket probe to DNS server."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.6)
            s.connect(("8.8.8.8", 53))
            s.close()
            return True
        except Exception:
            return False
