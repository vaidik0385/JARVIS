"""
JARVIS AI — Real Application Launcher & Command Dispatcher
Executes genuine local Windows applications and browser workflows.
Provides natural command parsing and security confirmation hooks.
"""

import os
import subprocess
import webbrowser
import urllib.parse
import ctypes
from typing import Tuple, Optional
from PySide6.QtCore import QObject, Signal

class AppLauncher(QObject):
    action_completed = Signal(str, bool, str)  # action_name, success, message
    confirmation_requested = Signal(str, str, object)  # title, message, callback

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)

    def launch(self, action_id: str, prompt_confirmation: bool = True) -> Tuple[bool, str]:
        """Launch a pre-defined application or Windows action."""
        action_id = action_id.lower().strip()

        try:
            if action_id == "calculator":
                subprocess.Popen("calc.exe")
                msg = "Windows Calculator launched successfully."
                self.action_completed.emit("Calculator", True, msg)
                return True, msg

            elif action_id == "notepad":
                subprocess.Popen("notepad.exe")
                msg = "Notepad launched successfully."
                self.action_completed.emit("Notepad", True, msg)
                return True, msg

            elif action_id in ("explorer", "files"):
                subprocess.Popen("explorer.exe")
                msg = "File Explorer opened."
                self.action_completed.emit("File Explorer", True, msg)
                return True, msg

            elif action_id == "settings":
                subprocess.Popen(["cmd", "/c", "start", "ms-settings:"], shell=True)
                msg = "Windows Settings opened."
                self.action_completed.emit("Windows Settings", True, msg)
                return True, msg

            elif action_id == "chrome":
                opened = webbrowser.open("https://www.google.com")
                msg = "Web browser opened to Google." if opened else "Failed to open default browser."
                self.action_completed.emit("Google Chrome", opened, msg)
                return opened, msg

            elif action_id == "youtube":
                opened = webbrowser.open("https://www.youtube.com")
                msg = "YouTube opened." if opened else "Failed to open YouTube."
                self.action_completed.emit("YouTube", opened, msg)
                return opened, msg

            elif action_id == "google":
                opened = webbrowser.open("https://www.google.com")
                msg = "Google search opened."
                self.action_completed.emit("Google", opened, msg)
                return opened, msg

            elif action_id == "linkedin":
                opened = webbrowser.open("https://www.linkedin.com")
                msg = "LinkedIn opened."
                self.action_completed.emit("LinkedIn", opened, msg)
                return opened, msg

            elif action_id == "whatsapp":
                opened = webbrowser.open("https://web.whatsapp.com")
                msg = "WhatsApp Web opened."
                self.action_completed.emit("WhatsApp Web", opened, msg)
                return opened, msg

            elif action_id == "lock":
                if prompt_confirmation:
                    self.confirmation_requested.emit(
                        "Confirm System Action",
                        "Are you sure you want JARVIS to lock your Windows workstation?",
                        lambda: self._execute_lock()
                    )
                    return True, "Awaiting user confirmation..."
                else:
                    return self._execute_lock()

            else:
                msg = f"Unknown application action: '{action_id}'"
                self.action_completed.emit(action_id, False, msg)
                return False, msg

        except Exception as e:
            err_msg = f"Failed to execute action '{action_id}': {e}"
            self.action_completed.emit(action_id, False, err_msg)
            return False, err_msg

    def _execute_lock(self) -> Tuple[bool, str]:
        try:
            ctypes.windll.user32.LockWorkStation()
            msg = "Workstation locked."
            self.action_completed.emit("Lock Laptop", True, msg)
            return True, msg
        except Exception as e:
            msg = f"Failed to lock workstation: {e}"
            self.action_completed.emit("Lock Laptop", False, msg)
            return False, msg

    def parse_and_execute_command(self, command_text: str) -> Tuple[bool, str]:
        """Parses natural language commands like 'Open YouTube', 'Search Python on YouTube', etc."""
        text = command_text.strip().lower()
        if not text:
            return False, "Command cannot be empty."

        # Search commands
        if text.startswith("search youtube for ") or text.startswith("search ") and " on youtube" in text:
            query = text.replace("search youtube for ", "").replace(" on youtube", "").replace("search ", "").strip()
            encoded = urllib.parse.quote_plus(query)
            url = f"https://www.youtube.com/results?search_query={encoded}"
            webbrowser.open(url)
            msg = f"Searching YouTube for '{query}'"
            self.action_completed.emit("YouTube Search", True, msg)
            return True, msg

        if text.startswith("search google for ") or text.startswith("google ") or text.startswith("search "):
            query = text.replace("search google for ", "").replace("google ", "").replace("search ", "").strip()
            encoded = urllib.parse.quote_plus(query)
            url = f"https://www.google.com/search?q={encoded}"
            webbrowser.open(url)
            msg = f"Searching Google for '{query}'"
            self.action_completed.emit("Google Search", True, msg)
            return True, msg

        # App launches
        if "calculator" in text or "calc" in text:
            return self.launch("calculator")
        elif "notepad" in text or "note" in text:
            return self.launch("notepad")
        elif "explorer" in text or "files" in text or "folder" in text:
            return self.launch("explorer")
        elif "settings" in text:
            return self.launch("settings")
        elif "youtube" in text:
            return self.launch("youtube")
        elif "linkedin" in text:
            return self.launch("linkedin")
        elif "whatsapp" in text:
            return self.launch("whatsapp")
        elif "chrome" in text or "browser" in text:
            return self.launch("chrome")
        elif "lock" in text:
            return self.launch("lock")

        msg = f"Command recognized but no matching automation found for: '{command_text}'"
        self.action_completed.emit("Command Dispatcher", False, msg)
        return False, msg
