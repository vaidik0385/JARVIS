"""
JARVIS AI — Backend Integration Contracts & Interfaces
Defines clean abstract interfaces, Qt signals, and data structures.
Enables full frontend operation while exposing decoupled connection points
for the future AI, speech, and cloud backends.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from PySide6.QtCore import QObject, Signal

@dataclass
class ChatMessage:
    id: str
    role: str  # "user" or "assistant"
    content: str
    timestamp: str
    is_streaming: bool = False
    metadata: Optional[Dict[str, Any]] = None

@dataclass
class ConversationMeta:
    id: str
    title: str
    created_at: str
    updated_at: str
    message_count: int = 0

@dataclass
class WeatherData:
    location: str
    temperature_c: float
    condition: str
    humidity_percent: int
    wind_speed_kmh: float
    icon_name: str
    is_connected: bool = False
    source: str = "Unavailable"

@dataclass
class SystemMetrics:
    cpu_percent: float = 0.0
    ram_percent: float = 0.0
    ram_used_gb: float = 0.0
    ram_total_gb: float = 0.0
    disk_percent: float = 0.0
    battery_percent: int = 100
    is_charging: bool = True
    battery_health: str = "Good"
    network_online: bool = True
    ai_backend_connected: bool = False
    mic_available: bool = True
    speaker_available: bool = True


class AIServiceContract(QObject):
    """
    Contract for AI Chat and Reasoning backends.
    Future providers (Gemini, Local LLM, OpenAI) must implement this interface.
    """
    # Signals
    thinking_started = Signal()
    thinking_finished = Signal()
    chunk_received = Signal(str)  # partial stream token
    response_completed = Signal(str)  # full response
    generation_stopped = Signal()
    error_occurred = Signal(str)

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.is_connected = False
        self.provider_name = "Not Connected"
        self.current_model = "None"

    def send_prompt(self, prompt: str, conversation_history: Optional[List[Dict[str, str]]] = None) -> None:
        """Send a prompt to the AI backend. Emits chunk_received and response_completed."""
        raise NotImplementedError

    def stop_generation(self) -> None:
        """Interrupt active generation."""
        raise NotImplementedError

    def check_connection(self) -> bool:
        """Verify API keys / server reachability."""
        return self.is_connected


class VoiceServiceContract(QObject):
    """
    Contract for Speech Recognition (STT), Text-to-Speech (TTS),
    and Live Voice Conversational loops.
    """
    # Mode A: Dictation Signals
    dictation_started = Signal()
    dictation_audio_level = Signal(float)  # 0.0 to 1.0 for audio meter
    dictation_completed = Signal(str)      # Recognized transcript text
    dictation_error = Signal(str)

    # Mode B: Live Voice Conversation Signals
    voice_state_changed = Signal(str)      # "idle", "listening", "thinking", "speaking"
    audio_amplitude_updated = Signal(float) # for orb and waveform reactivity
    spectrum_data_updated = Signal(list)    # list of frequency bins [float]
    live_transcript_received = Signal(str, str) # role ("user" | "jarvis"), text
    session_started = Signal()
    session_ended = Signal()

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.is_mic_muted = False

    def start_dictation(self) -> None:
        """Begin listening for user dictation into chat input."""
        raise NotImplementedError

    def stop_dictation(self) -> None:
        """Stop listening and trigger speech-to-text conversion."""
        raise NotImplementedError

    def start_live_session(self) -> None:
        """Enter bidirectional live conversational mode."""
        raise NotImplementedError

    def stop_live_session(self) -> None:
        """Exit live voice mode."""
        raise NotImplementedError

    def toggle_mute(self) -> bool:
        """Toggle microphone mute."""
        self.is_mic_muted = not self.is_mic_muted
        return self.is_mic_muted

    def interrupt(self) -> None:
        """Barge-in / interrupt assistant speech."""
        raise NotImplementedError


class WeatherServiceContract(QObject):
    """Contract for live weather data retrieval."""
    weather_updated = Signal(object)  # WeatherData
    weather_error = Signal(str)

    def fetch_weather(self, location: Optional[str] = None) -> None:
        raise NotImplementedError
