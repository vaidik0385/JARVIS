"""
JARVIS AI — Conversation Persistence Manager
Manages real local storage for conversation sessions, message history,
and search indexing using structured JSON files.
"""

import os
import json
import uuid
from datetime import datetime
from typing import List, Optional, Dict
from services.frontend_interfaces import ChatMessage, ConversationMeta

# Local portable storage within application workspace
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORAGE_DIR = os.path.join(BASE_DIR, "data", "conversations")

class ConversationManager:
    def __init__(self, storage_dir: Optional[str] = None):
        self.storage_dir = storage_dir or STORAGE_DIR
        os.makedirs(self.storage_dir, exist_ok=True)
        self._ensure_sample_conversations_if_empty()

    def _ensure_sample_conversations_if_empty(self):
        """Seed initial clean welcome conversations if directory is brand new."""
        if not os.listdir(self.storage_dir):
            c1_id = self.create_conversation("Welcome to JARVIS AI")
            self.add_message(
                c1_id,
                role="assistant",
                content="**Welcome to JARVIS AI Desktop Assistant.**\n\nI am your intelligent personal desktop companion. I can assist you with system monitoring, launching applications, voice interactions, and complex tasks.\n\n```python\n# JARVIS AI System Initialized\nstatus = jarvis.diagnostics.run_self_check()\nprint(f'System Status: {status.state}')\n```\n\nHow may I assist you today, Sir?"
            )
            c2_id = self.create_conversation("System Diagnostics & Telemetry")
            self.add_message(
                c2_id,
                role="user",
                content="Run system telemetry check on CPU and RAM."
            )
            self.add_message(
                c2_id,
                role="assistant",
                content="Telemetry snapshot recorded:\n- **CPU**: Operating within nominal parameters.\n- **Memory**: Clean memory buffers allocated.\n- **Sensors**: Active and monitoring."
            )

    def get_all_conversations(self) -> List[ConversationMeta]:
        conversations = []
        try:
            for fname in os.listdir(self.storage_dir):
                if fname.endswith(".json"):
                    fpath = os.path.join(self.storage_dir, fname)
                    try:
                        with open(fpath, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            meta = ConversationMeta(
                                id=data.get("id", fname[:-5]),
                                title=data.get("title", "Untitled Conversation"),
                                created_at=data.get("created_at", ""),
                                updated_at=data.get("updated_at", ""),
                                message_count=len(data.get("messages", []))
                            )
                            conversations.append(meta)
                    except Exception as e:
                        print(f"Error reading {fname}: {e}")
        except Exception as e:
            print(f"Error listing storage dir: {e}")

        # Sort descending by updated_at
        conversations.sort(key=lambda c: c.updated_at or c.created_at, reverse=True)
        return conversations

    def create_conversation(self, title: str = "New Chat") -> str:
        cid = str(uuid.uuid4())[:8]
        now = datetime.now().isoformat()
        data = {
            "id": cid,
            "title": title,
            "created_at": now,
            "updated_at": now,
            "messages": []
        }
        self._write_file(cid, data)
        return cid

    def get_conversation_messages(self, cid: str) -> List[ChatMessage]:
        data = self._read_file(cid)
        if not data:
            return []
        messages = []
        for m in data.get("messages", []):
            messages.append(ChatMessage(
                id=m.get("id", str(uuid.uuid4())[:8]),
                role=m.get("role", "assistant"),
                content=m.get("content", ""),
                timestamp=m.get("timestamp", ""),
                metadata=m.get("metadata")
            ))
        return messages

    def add_message(self, cid: str, role: str, content: str, metadata: Optional[Dict] = None) -> ChatMessage:
        data = self._read_file(cid)
        if not data:
            # Create if doesn't exist
            now = datetime.now().isoformat()
            data = {"id": cid, "title": "New Chat", "created_at": now, "updated_at": now, "messages": []}

        msg_id = str(uuid.uuid4())[:8]
        now_ts = datetime.now().strftime("%I:%M %p")
        iso_now = datetime.now().isoformat()

        msg = {
            "id": msg_id,
            "role": role,
            "content": content,
            "timestamp": now_ts,
            "metadata": metadata or {}
        }
        data["messages"].append(msg)
        data["updated_at"] = iso_now

        # If title is default "New Chat" and this is the first user message, update title
        if data.get("title") in ("New Chat", "Untitled Conversation") and role == "user":
            snippet = content.strip().split("\n")[0][:30]
            if snippet:
                data["title"] = snippet + ("..." if len(content) > 30 else "")

        self._write_file(cid, data)
        return ChatMessage(id=msg_id, role=role, content=content, timestamp=now_ts, metadata=metadata)

    def update_title(self, cid: str, new_title: str):
        data = self._read_file(cid)
        if data:
            data["title"] = new_title
            data["updated_at"] = datetime.now().isoformat()
            self._write_file(cid, data)

    def delete_conversation(self, cid: str) -> bool:
        fpath = os.path.join(self.storage_dir, f"{cid}.json")
        if os.path.exists(fpath):
            try:
                os.remove(fpath)
                return True
            except Exception as e:
                print(f"Error deleting conversation {cid}: {e}")
        return False

    def clear_messages(self, cid: str):
        data = self._read_file(cid)
        if data:
            data["messages"] = []
            data["updated_at"] = datetime.now().isoformat()
            self._write_file(cid, data)

    def search_conversations(self, query: str) -> List[ConversationMeta]:
        query = query.strip().lower()
        if not query:
            return self.get_all_conversations()

        results = []
        for meta in self.get_all_conversations():
            if query in meta.title.lower():
                results.append(meta)
                continue
            # Also search message contents
            data = self._read_file(meta.id)
            if data:
                matched = False
                for m in data.get("messages", []):
                    if query in m.get("content", "").lower():
                        results.append(meta)
                        matched = True
                        break
                if matched:
                    continue
        return results

    def _read_file(self, cid: str) -> Optional[Dict]:
        fpath = os.path.join(self.storage_dir, f"{cid}.json")
        if not os.path.exists(fpath):
            return None
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading {fpath}: {e}")
            return None

    def _write_file(self, cid: str, data: Dict):
        fpath = os.path.join(self.storage_dir, f"{cid}.json")
        try:
            with open(fpath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving {fpath}: {e}")
