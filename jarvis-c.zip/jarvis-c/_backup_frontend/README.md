# JARVIS AI — Advanced Desktop Assistant (Frontend)

JARVIS AI is a professional, production-grade Windows desktop AI assistant frontend built with **Python 3.14** and **PySide6**. It combines ChatGPT conversational flow, Gemini-inspired multimodal capabilities, and an Iron Man JARVIS command center aesthetic.

Designed specifically for college project exhibitions and enterprise-grade demonstrations.

---

## 🚀 Key Features

### 1. Left Navigation Sidebar
- **Dynamic Logo & Subtitle**: Arc reactor branding with real-time status.
- **Collapsible Layout**: Smooth icon-only / full-width collapse (`Ctrl+B`).
- **New Conversation**: One-click session reset (`Ctrl+N`).
- **Live Search**: Instant filtering across conversation titles and message bodies.
- **Persistent Local History**: Conversations stored in local JSON format (`~/.jarvis_ai/conversations`).
- **Privacy Shield Indicator**: Direct visibility into local sandbox security.

### 2. Central Multi-View Interface
- **Dashboard View**:
  - Prominent 210px animated **Voice Orb** with breathing pulse, rotating orbital aura rings, and multi-state rendering (`idle`, `listening`, `thinking`, `speaking`, `muted`).
  - Dynamic **Waveform Visualizer** with sinusoidal motion and frequency bars.
  - Interactive state switcher.
  - Quick natural language command dispatcher.
  - Live hardware telemetry gauges.
- **Chat Assistant View**:
  - Time-based greeting banner with 4 starter cards.
  - User bubbles (right-aligned) and Assistant cards (left-aligned).
  - Full Markdown formatting and code blocks with syntax styling and one-click "Copy Code".
  - Typing / thinking pulsing indicator.
  - Multiline auto-expanding chat input with Enter-to-send (`Shift+Enter` for newline).
  - Mode A Voice Dictation: Dedicated recording indicator, live timer, stop button, and editable transcript populating the input box.
  - Attachment browser with file validation.
- **Mode B Live Voice Conversation View**:
  - Dedicated full-screen voice conversation HUD.
  - Massive 240px reactive voice orb.
  - Real-time subtitle transcript stream.
  - Barge-in interrupt button (*"Interrupt / Tap to Speak"*).
  - Mic mute/unmute control.
  - Multilingual support badge (English / Hindi / Hinglish).
- **Quick Actions & Windows Control**:
  - Launch Calculator, Notepad, File Explorer, and Windows Settings.
  - Web shortcuts for Google, YouTube, LinkedIn, and WhatsApp Web.
  - Security-guarded Lock Workstation with confirmation dialog.
  - Real-time dispatch activity log (no fake success messages).
- **Settings & Configuration**:
  - Multi-tabbed preferences: General, Appearance, Voice & Audio, AI Provider, Privacy & Security, Shortcuts, and About.
  - Clean separation of concerns with environment-variable API credential policy.

### 3. Right Telemetry Panel
- **Digital Clock**: Live HH:MM:SS AM/PM clock with date and day of the week.
- **Weather Telemetry**: Clearly marked pending integration state (never displays fake mock weather).
- **Laptop Performance (psutil)**: Real-time CPU %, RAM %, RAM used/total GB, Disk %, and Battery % with charging status.
- **System Status Subsystems**: Internet connectivity, AI backend, microphone, and speaker status.
- **Collapsible Toggle**: Single-click collapse (`Ctrl+T`).

---

## 🛠️ Project Structure

```
jarvis-c/
├── main.py                          # Application entry point & Qt event loop
├── requirements.txt                 # Dependencies (PySide6, psutil, requests)
├── README.md                        # Documentation and architecture guide
│
├── frontend/                        # UI View layer
│   ├── __init__.py
│   ├── main_window.py               # 3-panel coordinator, shortcuts & dialogs
│   ├── sidebar.py                   # Collapsible left navigation & history
│   ├── chat_view.py                 # Conversational chat with markdown
│   ├── chat_input.py                # Expanding input & Mode A voice dictation
│   ├── dashboard_view.py            # Centerpiece voice orb & telemetry view
│   ├── voice_view.py                # Mode B dedicated live voice HUD
│   ├── quick_actions_view.py        # Windows apps & command dispatcher
│   ├── system_panel.py              # Collapsible right telemetry & clock
│   ├── settings_view.py             # Multi-tab preferences suite
│   └── dialogs.py                   # Styled modals & confirmation popups
│
├── components/                      # Reusable Qt custom widgets
│   ├── __init__.py
│   ├── voice_orb.py                 # Multi-layered glowing plasma voice orb
│   ├── waveform.py                  # Dynamic sinusoidal & frequency bars
│   ├── metric_gauge.py              # Circular and bar gauges for CPU/RAM/Battery
│   ├── status_indicator.py          # Glowing status dots & privacy badges
│   ├── cards.py                     # Elevated surface cards & action cards
│   ├── buttons.py                   # Gradient, icon, and danger buttons
│   └── message_bubble.py            # Markdown bubbles & copyable code blocks
│
├── styles/                          # Design system & visual styling
│   ├── __init__.py
│   ├── palette.py                   # Color constants & hex definitions
│   ├── icons.py                     # High-DPI QPainter vector icon generator
│   └── theme.qss                    # Master Qt Style Sheet
│
└── services/                        # Service contracts & backend interfaces
    ├── __init__.py
    ├── frontend_interfaces.py       # Abstract interfaces & Qt signal contracts
    ├── system_monitor.py            # Non-blocking QThread polling psutil
    ├── conversation_manager.py      # Local JSON conversation persistence
    └── app_launcher.py              # Real Windows process & browser launcher
```

---

## 💻 Installation & Launch

### Prerequisites
- Windows 10 or 11
- Python 3.12, 3.13, or 3.14

### 1. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 2. Launch the Application
```powershell
python main.py
```

---

## ⌨️ Global Keyboard Shortcuts

| Shortcut | Action |
| :--- | :--- |
| **Enter** | Send message in Chat |
| **Shift + Enter** | Insert new line in Chat input |
| **Ctrl + N** | Start new conversation |
| **Ctrl + B** | Toggle Left Sidebar |
| **Ctrl + T** | Toggle Right Telemetry Panel |
| **Ctrl + 1** | Switch to Dashboard |
| **Ctrl + 2** | Switch to Chat Assistant |
| **Ctrl + 3** | Switch to Live Voice Call |
| **Ctrl + 4** | Switch to Quick Actions |
| **Ctrl + ,** | Open Settings |
| **F11** | Toggle Fullscreen |

---

## 🔌 Backend Integration Contracts

The frontend is completely decoupled from any specific AI provider or cloud service. All backend interaction points are defined in `services/frontend_interfaces.py`:

### 1. AI Chat Contract (`AIServiceContract`)
```python
class AIServiceContract(QObject):
    chunk_received = Signal(str)        # Partial token for streaming
    response_completed = Signal(str)    # Full synthesized text
    thinking_started = Signal()
    thinking_finished = Signal()
    error_occurred = Signal(str)

    def send_prompt(self, prompt: str, history: list = None) -> None:
        ...
    def stop_generation(self) -> None:
        ...
```

### 2. Voice Service Contract (`VoiceServiceContract`)
```python
class VoiceServiceContract(QObject):
    # Mode A Dictation
    dictation_started = Signal()
    dictation_audio_level = Signal(float)  # 0.0 to 1.0
    dictation_completed = Signal(str)      # Transcript text
    
    # Mode B Live Voice
    voice_state_changed = Signal(str)      # "idle" | "listening" | "thinking" | "speaking"
    live_transcript_received = Signal(str, str) # role, text
    audio_amplitude_updated = Signal(float)
```

To connect a backend (e.g. Gemini API, Faster-Whisper, Kokoro TTS, or Ollama), inherit from these classes and connect their signals directly to `MainWindow`. No frontend UI modifications are necessary.
