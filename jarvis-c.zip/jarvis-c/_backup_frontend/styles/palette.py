"""
JARVIS AI - Color Palette and Design System Constants
"""

class Palette:
    # Backgrounds
    BG_DARKEST = "#070A10"
    BG_MAIN = "#0B0F19"
    BG_SIDEBAR = "#0E1321"
    BG_CARD = "#141B2D"
    BG_CARD_HOVER = "#1B243B"
    BG_CARD_ACTIVE = "#222C47"
    BG_INPUT = "#0F1626"
    
    # Borders
    BORDER_SUBTLE = "#1C263B"
    BORDER_DEFAULT = "#25334E"
    BORDER_FOCUS = "#00E5FF"
    BORDER_HIGHLIGHT = "#38BDF8"
    
    # Accents
    ACCENT_CYAN = "#00E5FF"
    ACCENT_BLUE = "#3B82F6"
    ACCENT_PURPLE = "#8B5CF6"
    ACCENT_MAGENTA = "#D946EF"
    ACCENT_GLOW = "rgba(0, 229, 255, 0.25)"
    
    # Status Colors
    STATUS_ONLINE = "#10B981"
    STATUS_IDLE = "#F59E0B"
    STATUS_BUSY = "#EF4444"
    STATUS_MUTED = "#64748B"
    
    # Text
    TEXT_PRIMARY = "#F8FAFC"
    TEXT_SECONDARY = "#94A3B8"
    TEXT_MUTED = "#64748B"
    TEXT_DISABLED = "#475569"
    TEXT_ACCENT = "#00E5FF"
    
    # Gradients (CSS representation)
    GRADIENT_ORB = "radial-gradient(circle, #00E5FF 0%, #3B82F6 45%, #8B5CF6 80%, #0B0F19 100%)"
    GRADIENT_BUTTON = "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00E5FF, stop:1 #3B82F6)"
    GRADIENT_PURPLE = "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #8B5CF6, stop:1 #3B82F6)"
    GRADIENT_CARD = "qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #172138, stop:1 #111728)"
    
    # Fonts
    FONT_FAMILY = "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif"
    FONT_MONO = "Consolas, 'Cascadia Code', 'Courier New', monospace"
