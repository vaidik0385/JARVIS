from styles.palette import Palette
from styles.icons import get_icon, get_pixmap
