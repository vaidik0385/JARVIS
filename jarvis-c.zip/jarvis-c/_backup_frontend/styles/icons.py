"""
JARVIS AI - Vector Icon Generator
Renders crisp vector QIcons and QPixmaps dynamically using QPainter paths.
Ensures crisp high-DPI rendering without external asset dependencies.
"""

from PySide6.QtGui import QIcon, QPixmap, QPainter, QPainterPath, QColor, QPen, QBrush
from PySide6.QtCore import Qt, QRectF, QPointF
from styles.palette import Palette

_ICON_CACHE = {}

def get_pixmap(name: str, color: str = None, size: int = 24) -> QPixmap:
    cache_key = f"{name}_{color}_{size}"
    if cache_key in _ICON_CACHE:
        return _ICON_CACHE[cache_key]

    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

    pen_color = QColor(color or Palette.TEXT_SECONDARY)
    pen = QPen(pen_color, max(1.5, size / 14))
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)

    s = float(size)
    pad = s * 0.15
    w = s - 2 * pad
    h = s - 2 * pad

    if name == "logo":
        # Stylized glowing Arc Reactor / JARVIS crest
        center = QPointF(s / 2, s / 2)
        # Outer ring
        painter.drawEllipse(center, s * 0.42, s * 0.42)
        # Inner triangle/star core
        p1 = QPointF(center.x(), center.y() - s * 0.28)
        p2 = QPointF(center.x() + s * 0.25, center.y() + s * 0.18)
        p3 = QPointF(center.x() - s * 0.25, center.y() + s * 0.18)
        triangle = QPainterPath()
        triangle.moveTo(p1)
        triangle.lineTo(p2)
        triangle.lineTo(p3)
        triangle.closeSubpath()
        painter.strokePath(triangle, pen)
        # Center core dot
        painter.setBrush(QBrush(pen_color))
        painter.drawEllipse(center, s * 0.08, s * 0.08)

    elif name == "dashboard":
        # 4 rounded quadrants
        gap = s * 0.08
        hw = (w - gap) / 2
        painter.drawRoundedRect(QRectF(pad, pad, hw, hw), 2, 2)
        painter.drawRoundedRect(QRectF(pad + hw + gap, pad, hw, hw), 2, 2)
        painter.drawRoundedRect(QRectF(pad, pad + hw + gap, hw, hw), 2, 2)
        painter.drawRoundedRect(QRectF(pad + hw + gap, pad + hw + gap, hw, hw), 2, 2)

    elif name == "chat":
        # Speech bubble
        path = QPainterPath()
        path.moveTo(pad, pad + h * 0.7)
        path.lineTo(pad, pad + 3)
        path.quadTo(pad, pad, pad + 3, pad)
        path.lineTo(pad + w - 3, pad)
        path.quadTo(pad + w, pad, pad + w, pad + 3)
        path.lineTo(pad + w, pad + h * 0.7 - 3)
        path.quadTo(pad + w, pad + h * 0.7, pad + w - 3, pad + h * 0.7)
        path.lineTo(pad + w * 0.45, pad + h * 0.7)
        path.lineTo(pad + w * 0.2, pad + h)
        path.lineTo(pad + w * 0.25, pad + h * 0.7)
        path.closeSubpath()
        painter.drawPath(path)

    elif name in ("voice", "mic"):
        # Microphone
        mic_w = w * 0.4
        mic_h = h * 0.55
        painter.drawRoundedRect(QRectF((s - mic_w) / 2, pad, mic_w, mic_h), mic_w / 2, mic_w / 2)
        # Arc around mic
        arc_rect = QRectF(pad + w * 0.1, pad + h * 0.15, w * 0.8, h * 0.6)
        path = QPainterPath()
        path.arcMoveTo(arc_rect, 0)
        path.arcTo(arc_rect, 0, -180)
        painter.drawPath(path)
        # Stand
        painter.drawLine(QPointF(s / 2, pad + h * 0.75), QPointF(s / 2, pad + h))
        painter.drawLine(QPointF(pad + w * 0.3, pad + h), QPointF(pad + w * 0.7, pad + h))

    elif name == "mute":
        # Mic with strike
        mic_w = w * 0.4
        mic_h = h * 0.55
        painter.drawRoundedRect(QRectF((s - mic_w) / 2, pad, mic_w, mic_h), mic_w / 2, mic_w / 2)
        painter.drawLine(QPointF(pad, pad), QPointF(pad + w, pad + h))

    elif name == "actions":
        # Compass / Rocket / Lightning bolt
        path = QPainterPath()
        path.moveTo(pad + w * 0.55, pad)
        path.lineTo(pad + w * 0.15, pad + h * 0.55)
        path.lineTo(pad + w * 0.5, pad + h * 0.55)
        path.lineTo(pad + w * 0.45, pad + h)
        path.lineTo(pad + w * 0.85, pad + h * 0.45)
        path.lineTo(pad + w * 0.5, pad + h * 0.45)
        path.closeSubpath()
        painter.drawPath(path)

    elif name == "settings":
        # Gear icon
        center = QPointF(s / 2, s / 2)
        painter.drawEllipse(center, s * 0.15, s * 0.15)
        painter.drawEllipse(center, s * 0.35, s * 0.35)
        # 6 spokes
        for i in range(6):
            p = QPainterPath()
            angle = i * 60
            painter.save()
            painter.translate(center)
            painter.rotate(angle)
            painter.drawLine(0, -int(s * 0.35), 0, -int(s * 0.45))
            painter.restore()

    elif name in ("plus", "new_chat"):
        painter.drawLine(QPointF(s / 2, pad), QPointF(s / 2, pad + h))
        painter.drawLine(QPointF(pad, s / 2), QPointF(pad + w, s / 2))

    elif name == "search":
        r = w * 0.35
        painter.drawEllipse(QRectF(pad, pad, r * 2, r * 2))
        painter.drawLine(QPointF(pad + r * 1.7, pad + r * 1.7), QPointF(pad + w, pad + h))

    elif name == "send":
        # Paper airplane
        path = QPainterPath()
        path.moveTo(pad, pad + h)
        path.lineTo(pad + w, s / 2)
        path.lineTo(pad, pad)
        path.lineTo(pad + w * 0.35, s / 2)
        path.closeSubpath()
        painter.drawPath(path)

    elif name == "stop":
        painter.setBrush(QBrush(pen_color))
        painter.drawRoundedRect(QRectF(pad + w * 0.15, pad + h * 0.15, w * 0.7, h * 0.7), 3, 3)

    elif name == "copy":
        # Two overlapping rectangles
        offset = w * 0.25
        rw = w * 0.65
        rh = h * 0.65
        painter.drawRoundedRect(QRectF(pad, pad + offset, rw, rh), 2, 2)
        painter.drawRoundedRect(QRectF(pad + offset, pad, rw, rh), 2, 2)

    elif name == "refresh":
        rect = QRectF(pad, pad, w, h)
        path = QPainterPath()
        path.arcMoveTo(rect, 45)
        path.arcTo(rect, 45, 270)
        painter.drawPath(path)
        # Arrowhead
        painter.drawLine(QPointF(pad + w * 0.8, pad + h * 0.2), QPointF(pad + w * 0.8, pad + h * 0.45))
        painter.drawLine(QPointF(pad + w * 0.8, pad + h * 0.2), QPointF(pad + w * 0.55, pad + h * 0.2))

    elif name == "attach":
        # Paperclip
        path = QPainterPath()
        path.moveTo(pad + w * 0.3, pad + h * 0.4)
        path.lineTo(pad + w * 0.3, pad + h * 0.7)
        path.quadTo(pad + w * 0.3, pad + h, pad + w * 0.5, pad + h)
        path.quadTo(pad + w * 0.7, pad + h, pad + w * 0.7, pad + h * 0.7)
        path.lineTo(pad + w * 0.7, pad + h * 0.25)
        path.quadTo(pad + w * 0.7, pad, pad + w * 0.5, pad)
        path.quadTo(pad + w * 0.3, pad, pad + w * 0.3, pad + h * 0.25)
        path.lineTo(pad + w * 0.3, pad + h * 0.6)
        painter.drawPath(path)

    elif name == "sidebar_toggle":
        # 3 horizontal lines or panel sidebar icon
        painter.drawRoundedRect(QRectF(pad, pad, w, h), 3, 3)
        painter.drawLine(QPointF(pad + w * 0.35, pad), QPointF(pad + w * 0.35, pad + h))

    elif name == "panel_toggle":
        painter.drawRoundedRect(QRectF(pad, pad, w, h), 3, 3)
        painter.drawLine(QPointF(pad + w * 0.65, pad), QPointF(pad + w * 0.65, pad + h))

    elif name == "clock":
        painter.drawEllipse(QRectF(pad, pad, w, h))
        painter.drawLine(QPointF(s / 2, s / 2), QPointF(s / 2, pad + h * 0.25))
        painter.drawLine(QPointF(s / 2, s / 2), QPointF(pad + w * 0.75, s / 2))

    elif name == "weather":
        # Cloud with sun edge
        path = QPainterPath()
        path.moveTo(pad + w * 0.2, pad + h * 0.8)
        path.lineTo(pad + w * 0.8, pad + h * 0.8)
        path.quadTo(pad + w, pad + h * 0.8, pad + w * 0.9, pad + h * 0.55)
        path.quadTo(pad + w * 0.8, pad + h * 0.3, pad + w * 0.6, pad + h * 0.35)
        path.quadTo(pad + w * 0.45, pad + h * 0.15, pad + w * 0.3, pad + h * 0.35)
        path.quadTo(pad, pad + h * 0.45, pad + w * 0.2, pad + h * 0.8)
        painter.drawPath(path)

    elif name == "cpu":
        # Chip
        chip_pad = pad + w * 0.15
        chip_size = w * 0.7
        painter.drawRoundedRect(QRectF(chip_pad, chip_pad, chip_size, chip_size), 3, 3)
        # Pins
        for i in (0.3, 0.5, 0.7):
            painter.drawLine(QPointF(pad + w * i, pad), QPointF(pad + w * i, chip_pad))
            painter.drawLine(QPointF(pad + w * i, chip_pad + chip_size), QPointF(pad + w * i, pad + h))
            painter.drawLine(QPointF(pad, pad + h * i), QPointF(chip_pad, pad + h * i))
            painter.drawLine(QPointF(chip_pad + chip_size, pad + h * i), QPointF(pad + w, pad + h * i))

    elif name == "ram":
        # RAM stick
        painter.drawRoundedRect(QRectF(pad, pad + h * 0.25, w, h * 0.5), 2, 2)
        # notches
        for i in range(4):
            x = pad + w * 0.2 + i * (w * 0.18)
            painter.drawLine(QPointF(x, pad + h * 0.35), QPointF(x, pad + h * 0.65))

    elif name == "battery":
        # Battery body
        bw = w * 0.85
        bh = h * 0.55
        painter.drawRoundedRect(QRectF(pad, pad + (h - bh) / 2, bw, bh), 3, 3)
        # Terminal nub
        painter.drawLine(QPointF(pad + bw + 2, s / 2 - bh * 0.25), QPointF(pad + bw + 2, s / 2 + bh * 0.25))

    elif name in ("wifi", "network"):
        # Wifi signal arcs
        center = QPointF(s / 2, pad + h * 0.85)
        for rad in (h * 0.75, h * 0.5, h * 0.25):
            rect = QRectF(center.x() - rad, center.y() - rad, rad * 2, rad * 2)
            path = QPainterPath()
            path.arcMoveTo(rect, 45)
            path.arcTo(rect, 45, 90)
            painter.drawPath(path)
        painter.setBrush(QBrush(pen_color))
        painter.drawEllipse(center, 1.5, 1.5)

    elif name == "lock":
        # Padlock
        shackle_rect = QRectF(pad + w * 0.25, pad, w * 0.5, h * 0.5)
        path = QPainterPath()
        path.arcMoveTo(shackle_rect, 0)
        path.arcTo(shackle_rect, 0, 180)
        painter.drawPath(path)
        painter.drawRoundedRect(QRectF(pad + w * 0.15, pad + h * 0.45, w * 0.7, h * 0.55), 3, 3)

    elif name == "calculator":
        painter.drawRoundedRect(QRectF(pad, pad, w, h), 3, 3)
        painter.drawLine(QPointF(pad + w * 0.15, pad + h * 0.3), QPointF(pad + w * 0.85, pad + h * 0.3))
        # buttons
        for row in (0.5, 0.75):
            for col in (0.3, 0.5, 0.7):
                painter.drawPoint(QPointF(pad + w * col, pad + h * row))

    elif name == "notepad":
        painter.drawRoundedRect(QRectF(pad + w * 0.1, pad, w * 0.8, h), 2, 2)
        painter.drawLine(QPointF(pad + w * 0.25, pad + h * 0.3), QPointF(pad + w * 0.75, pad + h * 0.3))
        painter.drawLine(QPointF(pad + w * 0.25, pad + h * 0.5), QPointF(pad + w * 0.75, pad + h * 0.5))
        painter.drawLine(QPointF(pad + w * 0.25, pad + h * 0.7), QPointF(pad + w * 0.55, pad + h * 0.7))

    elif name == "folder":
        path = QPainterPath()
        path.moveTo(pad, pad + h * 0.3)
        path.lineTo(pad + w * 0.4, pad + h * 0.3)
        path.lineTo(pad + w * 0.5, pad + h * 0.45)
        path.lineTo(pad + w, pad + h * 0.45)
        path.lineTo(pad + w, pad + h)
        path.lineTo(pad, pad + h)
        path.closeSubpath()
        painter.drawPath(path)

    elif name == "sparkle":
        # 4-point star
        path = QPainterPath()
        path.moveTo(s / 2, pad)
        path.quadTo(s / 2, s / 2, pad + w, s / 2)
        path.quadTo(s / 2, s / 2, s / 2, pad + h)
        path.quadTo(s / 2, s / 2, pad, s / 2)
        path.quadTo(s / 2, s / 2, s / 2, pad)
        painter.drawPath(path)

    elif name == "phone_off":
        # Disconnect phone icon
        path = QPainterPath()
        path.moveTo(pad + w * 0.1, pad + h * 0.4)
        path.quadTo(s / 2, pad + h * 0.15, pad + w * 0.9, pad + h * 0.4)
        painter.drawPath(path)
        painter.drawLine(QPointF(pad + w * 0.1, pad + h * 0.8), QPointF(pad + w * 0.9, pad + h * 0.2))

    elif name == "check":
        path = QPainterPath()
        path.moveTo(pad + w * 0.1, pad + h * 0.5)
        path.lineTo(pad + w * 0.4, pad + h * 0.85)
        path.lineTo(pad + w * 0.9, pad + h * 0.15)
        painter.drawPath(path)

    elif name == "trash":
        painter.drawLine(QPointF(pad + w * 0.1, pad + h * 0.25), QPointF(pad + w * 0.9, pad + h * 0.25))
        painter.drawRoundedRect(QRectF(pad + w * 0.2, pad + h * 0.25, w * 0.6, h * 0.75), 2, 2)
        painter.drawLine(QPointF(pad + w * 0.4, pad + h * 0.4), QPointF(pad + w * 0.4, pad + h * 0.8))
        painter.drawLine(QPointF(pad + w * 0.6, pad + h * 0.4), QPointF(pad + w * 0.6, pad + h * 0.8))

    elif name == "help":
        painter.drawEllipse(QRectF(pad, pad, w, h))
        painter.drawText(QRectF(pad, pad, w, h), Qt.AlignmentFlag.AlignCenter, "?")

    else:
        # Default placeholder circle with dot
        painter.drawEllipse(QRectF(pad, pad, w, h))
        painter.drawPoint(QPointF(s / 2, s / 2))

    painter.end()
    _ICON_CACHE[cache_key] = pixmap
    return pixmap

def get_icon(name: str, color: str = None, size: int = 24) -> QIcon:
    return QIcon(get_pixmap(name, color, size))
