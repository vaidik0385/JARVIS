"""
JARVIS AI — Conversation Manager (SQLite Bridge)
Maintains 100% frontend API compatibility while routing persistence
directly into the high-performance SQLite database engine.
"""

from typing import List, Optional, Dict
from services.frontend_interfaces import ChatMessage, ConversationMeta

class ConversationManager:
    """Delegates persistence operations to backend SQLite database."""
    def __init__(self, db_instance=None):
        self._db = db_instance

    @property
    def db(self):
        if self._db is None:
            from backend.database import db
            self._db = db
        return self._db

    def get_all_conversations(self) -> List[ConversationMeta]:
        return self.db.get_all_conversations()

    def create_conversation(self, title: str = "New Chat") -> str:
        return self.db.create_conversation(title)

    def get_conversation_messages(self, cid: str) -> List[ChatMessage]:
        return self.db.get_conversation_messages(cid)

    def add_message(self, cid: str, role: str, content: str, metadata: Optional[Dict] = None) -> ChatMessage:
        return self.db.add_message(cid, role=role, content=content, metadata=metadata)

    def update_title(self, cid: str, new_title: str):
        self.db.update_title(cid, new_title)

    def delete_conversation(self, cid: str) -> bool:
        return self.db.delete_conversation(cid)

    def clear_messages(self, cid: str):
        self.db.clear_messages(cid)

    def search_conversations(self, query: str) -> List[ConversationMeta]:
        return self.db.search_conversations(query)
