"""
JARVIS AI — Application Launcher Bridge
Delegates execution to the safe command registry in backend.application_launcher.
"""

from backend.application_launcher import ApplicationLauncher, SafeAppRegistry

# Maintain backward compatibility alias
class AppLauncher(ApplicationLauncher):
    def launch(self, action_id: str, prompt_confirmation: bool = True):
        action_id = action_id.lower().strip()
        if action_id == "lock":
            return self.lock_workstation(prompt_confirmation=prompt_confirmation)
        elif action_id in SafeAppRegistry.SAFE_COMMANDS:
            return self.launch_app(action_id)
        elif action_id in SafeAppRegistry.SAFE_URLS:
            return self.open_web_portal(action_id)
        else:
            return self.launch_app(action_id)

    def parse_and_execute_command(self, command_text: str):
        from backend.tool_router import ToolRouter
        router = ToolRouter(self)
        res = router.try_direct_intent(command_text)
        if res is not None:
            return res
        return False, f"No matching safe automation found for: '{command_text}'"
