"""
JARVIS AI — System Monitor Service Bridge
Delegates hardware collection directly to the backend system monitor module.
"""

from backend.system_monitor import SystemMonitorWorker, ExtendedSystemMetrics
from services.frontend_interfaces import SystemMetrics
