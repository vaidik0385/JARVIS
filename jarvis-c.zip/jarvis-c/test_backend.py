"""
JARVIS AI — Comprehensive Backend Automated Test Suite
Verifies SQLite Database, Real Hardware Telemetry, Open-Meteo Weather,
Intent Matching, Safe Command Registry, and Subsystem Connections.
"""

import sys
import os
import time

def run_tests():
    print("=" * 60)
    print("JARVIS AI — BACKEND VERIFICATION & INTEGRATION TEST SUITE")
    print("=" * 60)

    # Test 1: Configuration & Credential Management
    print("\n[1/8] Testing Configuration & Credential Vault...")
    from backend.config import config
    print(f"  AI Model: {config.ai_model}")
    print(f"  Fallback Model: {config.ai_fallback_model}")
    print(f"  Groq Key Status: {config.mask_key(config.groq_api_key)}")
    print(f"  Gemini Key Status: {config.mask_key(config.gemini_api_key)}")
    print(f"  Weather Location: {config.weather_location}")
    print("  [OK] Config module functional.")

    # Test 2: SQLite Database Persistence
    print("\n[2/8] Testing SQLite Database Persistence...")
    from backend.database import db
    conv_id = db.create_conversation("Integration Test Session")
    assert conv_id, "Failed to create conversation."
    u_msg = db.add_message(conv_id, role="user", content="Hello JARVIS, test database persistence.")
    a_msg = db.add_message(conv_id, role="assistant", content="Database persistence operational with SQLite.")
    msgs = db.get_conversation_messages(conv_id)
    assert len(msgs) == 2, f"Expected 2 messages, got {len(msgs)}"
    search_results = db.search_conversations("persistence")
    assert len(search_results) > 0, "Full-text search failed."
    db.delete_conversation(conv_id)
    print(f"  [OK] SQLite database verified with {len(db.get_all_conversations())} conversations.")

    # Test 3: Open-Meteo Real Weather Service
    print("\n[3/8] Testing Open-Meteo Weather Service...")
    from backend.weather_service import WeatherWorker
    worker = WeatherWorker(location="New Delhi")
    # Run synchronously for test
    worker._geocode("New Delhi")
    lat, lon, resolved = worker._geocode("New Delhi")
    print(f"  Geocoding resolved: {resolved} -> Lat: {lat}, Lon: {lon}")
    assert lat is not None and lon is not None, "Geocoding failed."

    # Fetch live weather
    import urllib.request, json
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m"
    req = urllib.request.Request(url, headers={"User-Agent": "JARVIS-Test/2.4"})
    with urllib.request.urlopen(req, timeout=5) as resp:
        data = json.loads(resp.read().decode())
        curr = data["current"]
        print(f"  Live Weather: Temp={curr['temperature_2m']}C, Humidity={curr['relative_humidity_2m']}%, Wind={curr['wind_speed_10m']} km/h")
    print("  [OK] Open-Meteo real weather service verified.")

    # Test 4: Real Hardware Telemetry (psutil)
    print("\n[4/8] Testing Real Hardware Telemetry...")
    from backend.system_monitor import SystemMonitorWorker
    mon = SystemMonitorWorker()
    m = mon._gather_metrics()
    print(f"  Host: {m.computer_name} ({m.os_name})")
    print(f"  Processor: {m.processor_name} ({m.cpu_cores_physical} phys / {m.cpu_cores_logical} log cores)")
    print(f"  CPU Load: {m.cpu_percent}%")
    print(f"  RAM: {m.ram_used_gb} / {m.ram_total_gb} GB ({m.ram_percent}%)")
    print(f"  Disk: {m.disk_used_gb} / {m.disk_total_gb} GB ({m.disk_percent}%)")
    print(f"  Battery: {m.battery_percent}% ({m.battery_health})")
    print(f"  System Uptime: {m.uptime_str}")
    print("  [OK] Hardware telemetry verified.")

    # Test 5: Safe Application Launcher & Command Registry
    print("\n[5/8] Testing Safe Application Command Registry...")
    from backend.application_launcher import ApplicationLauncher, SafeAppRegistry
    launcher = ApplicationLauncher(dry_run=True)
    assert "calculator" in SafeAppRegistry.SAFE_COMMANDS
    assert "notepad" in SafeAppRegistry.SAFE_COMMANDS
    assert "youtube" in SafeAppRegistry.SAFE_URLS
    assert "whatsapp" in SafeAppRegistry.SAFE_URLS
    # Test blocked arbitrary command
    ok, msg = launcher.launch_app("malicious_rm_rf")
    assert not ok, "Unsafe command was not blocked!"
    print(f"  Safe allowlist enforced: '{msg}'")
    print("  [OK] Safe command registry verified.")

    # Test 6: Multilingual Intent Matcher (English, Hindi, Hinglish)
    print("\n[6/8] Testing Multilingual Intent Matcher...")
    from backend.tool_router import ToolRouter
    router = ToolRouter(launcher)

    # Test English intent
    res_en = router.try_direct_intent("open calculator")
    assert res_en is not None and res_en[0] is True, "English calculator intent failed."
    print("  Intent 'open calculator' -> Handled successfully.")

    # Test Hinglish intent
    res_hi = router.try_direct_intent("notepad kholo")
    assert res_hi is not None and res_hi[0] is True, "Hinglish notepad intent failed."
    print("  Intent 'notepad kholo' -> Handled successfully.")

    # Test YouTube Search intent
    res_yt = router.try_direct_intent("search Python tutorials on youtube")
    assert res_yt is not None and res_yt[0] is True, "YouTube search intent failed."
    print("  Intent 'search Python tutorials on youtube' -> Handled successfully.")

    # Test Google Search in Hinglish
    res_g = router.try_direct_intent("google pe machine learning search karo")
    assert res_g is not None and res_g[0] is True, "Hinglish Google search intent failed."
    print("  Intent 'google pe machine learning search karo' -> Handled successfully.")
    print("  [OK] Multilingual intent router verified.")

    # Test 7: Subsystem Connection Probes
    print("\n[7/8] Testing Subsystem Connection Probes...")
    from backend.connection_manager import HealthCheckWorker
    hc = HealthCheckWorker()
    net = hc._check_internet()
    mic = hc._check_microphone()
    spk = hc._check_speaker()
    weather_net = hc._check_weather()
    print(f"  Internet Probe: {'ONLINE' if net else 'OFFLINE'}")
    print(f"  Microphone Hardware: {'DETECTED' if mic else 'NOT FOUND'}")
    print(f"  Audio Output Hardware: {'DETECTED' if spk else 'NOT FOUND'}")
    print(f"  Weather API Endpoint: {'REACHABLE' if weather_net else 'UNREACHABLE'}")
    print("  [OK] Connection probes verified.")

    # Test 8: SAPI5 TTS Engine
    print("\n[8/8] Testing Windows Local Text-to-Speech Engine...")
    import pyttsx3
    eng = pyttsx3.init()
    voices = eng.getProperty("voices")
    print(f"  Detected {len(voices)} Windows SAPI5 voices:")
    for v in voices:
        print(f"   - {v.name}")
    eng.stop()
    print("  [OK] Text-to-Speech engine verified.")

    print("\n" + "=" * 60)
    print("ALL 8 BACKEND INTEGRATION TESTS PASSED SUCCESSFULLY!")
    print("=" * 60)

if __name__ == "__main__":
    run_tests()
