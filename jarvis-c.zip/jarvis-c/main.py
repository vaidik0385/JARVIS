"""
JARVIS AI — Advanced Desktop Assistant
Master Application Entry Point with Robust Windows GUI Initialization & Startup Diagnostics
"""

import sys
import os
import time
import datetime
import traceback
import ctypes
from ctypes import wintypes
from pathlib import Path

# Base directories
BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "startup.log"

def log_msg(msg: str):
    """Outputs to both console (unbuffered) and startup.log."""
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    entry = f"[{ts}] {msg}"
    print(entry, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(entry + "\n")
    except Exception:
        pass

def handle_exception(exc_type, exc_value, exc_traceback):
    """Global exception hook ensuring no startup error is silently swallowed."""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    err_str = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    log_msg(f"[FATAL UNCAUGHT EXCEPTION]\n{err_str}")
    try:
        ctypes.windll.user32.MessageBoxW(
            0,
            f"JARVIS AI encountered an unexpected error:\n\n{exc_value}\n\nSee startup.log for details.",
            "JARVIS AI Error",
            0x10  # MB_ICONERROR
        )
    except Exception:
        pass

sys.excepthook = handle_exception

# Initialize fresh startup.log
try:
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        f.write(f"=== JARVIS AI STARTUP LOG — {datetime.datetime.now().isoformat()} ===\n")
except Exception:
    pass

log_msg(f"System: OS={os.name}, Platform={sys.platform}, Python={sys.version.split()[0]}")
log_msg(f"Executable: {sys.executable}")
log_msg(f"Working Directory: {BASE_DIR}")

# 0. Attach thread to Windows interactive physical desktop ("Default")
# This ensures that when launched from IDE terminals, language servers, or sandboxed consoles,
# the window is created directly on the physical display visible to the user.
try:
    user32 = ctypes.windll.user32
    h_desk_default = user32.OpenDesktopW("default", 0, False, 0x10000000)
    if h_desk_default:
        res = user32.SetThreadDesktop(h_desk_default)
        log_msg(f"Attached thread to Windows interactive 'Default' desktop (status: {res})")
    else:
        log_msg("Notice: Default desktop handle was not returned, continuing with current desktop.")
except Exception as e:
    log_msg(f"Notice attaching to interactive desktop: {e}")

# 1. Set Windows Application User Model ID for proper taskbar icon & grouping
try:
    myappid = "jarvis.ai.desktop.assistant.v2"
    shell32 = ctypes.windll.shell32
    shell32.SetCurrentProcessExplicitAppUserModelID.argtypes = [ctypes.c_wchar_p]
    shell32.SetCurrentProcessExplicitAppUserModelID.restype = ctypes.HRESULT
    hr = shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    log_msg(f"Windows AppUserModelID registered (HRESULT: {hr})")
except Exception as e:
    log_msg(f"AppUserModelID registration notice: {e}")

# Import PySide6
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QFont, QScreen
    log_msg("PySide6 Qt libraries imported successfully.")
except Exception as e:
    log_msg(f"CRITICAL: Failed to import PySide6: {e}")
    traceback.print_exc()
    sys.exit(1)

def load_stylesheet(app: QApplication):
    """Loads and applies the master dark theme QSS."""
    qss_path = BASE_DIR / "styles" / "theme.qss"
    if qss_path.exists():
        try:
            with open(qss_path, "r", encoding="utf-8") as f:
                stylesheet = f.read()
                app.setStyleSheet(stylesheet)
            log_msg(f"Master stylesheet applied ({len(stylesheet)} bytes from {qss_path.name}).")
        except Exception as e:
            log_msg(f"Warning: Stylesheet read error: {e}")
    else:
        log_msg(f"Warning: Stylesheet not found at {qss_path}")

def main():
    log_msg("Starting QApplication initialization...")

    # High DPI Scaling Policy
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("JARVIS AI")
    app.setApplicationDisplayName("JARVIS AI Desktop Assistant")
    app.setOrganizationName("JARVIS Systems")
    app.setQuitOnLastWindowClosed(True)

    # Global Font Setup
    font = QFont("Segoe UI", 10)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    app.setFont(font)

    # Master Stylesheet
    load_stylesheet(app)

    # Query Monitor & Display Geometry
    primary_screen = app.primaryScreen()
    if primary_screen:
        s_geo = primary_screen.geometry()
        s_avail = primary_screen.availableGeometry()
        log_msg(f"Display detected: {primary_screen.name()} [Total: {s_geo.width()}x{s_geo.height()}, Available: {s_avail.width()}x{s_avail.height()}, DPR: {primary_screen.devicePixelRatio()}]")
    else:
        log_msg("Warning: Primary screen could not be identified.")

    # Import and Instantiate MainWindow
    log_msg("Instantiating MainWindow and constructing UI...")
    t_start = time.time()
    try:
        from frontend.main_window import MainWindow
        window = MainWindow()
        log_msg(f"MainWindow instantiated successfully in {round(time.time() - t_start, 3)}s.")
    except Exception as e:
        log_msg(f"CRITICAL: Failed to instantiate MainWindow: {e}")
        traceback.print_exc()
        raise

    # Adaptively Position Window on Primary Display
    try:
        if primary_screen:
            avail = primary_screen.availableGeometry()
            # 88% of available desktop space clamped between min and ideal size
            target_w = min(1260, max(960, int(avail.width() * 0.88)))
            target_h = min(780, max(600, int(avail.height() * 0.88)))
            window.resize(target_w, target_h)

            x = avail.x() + (avail.width() - target_w) // 2
            y = avail.y() + (avail.height() - target_h) // 2
            window.move(x, y)
            log_msg(f"Calculated centered window geometry: x={x}, y={y}, w={target_w}, h={target_h}")
        else:
            window.resize(1200, 750)
    except Exception as e:
        log_msg(f"Window sizing notice: {e}")

    # Show and bring window to front
    window.show()
    window.showNormal()
    window.raise_()
    window.activateWindow()
    log_msg("Window shown (isVisible=True).")

    # Native Win32 focus elevation & temporary topmost priority via SetWindowPos
    # Avoids Qt setWindowFlags() which recreates the HWND and causes window hiding
    try:
        hwnd = int(window.winId())
        user32 = ctypes.windll.user32
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.BringWindowToTop.argtypes = [wintypes.HWND]
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]

        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)

        HWND_TOPMOST = -1
        HWND_NOTOPMOST = -2
        SWP_NOSIZE = 0x0001
        SWP_NOMOVE = 0x0002
        SWP_SHOWWINDOW = 0x0040

        user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
        log_msg(f"Native Win32 HWND {hex(hwnd)} elevated to foreground with topmost priority.")

        def _restore_standard_window():
            try:
                user32.SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                log_msg("Topmost flag released via SetWindowPos. Standard desktop z-order active.")
            except Exception as e:
                log_msg(f"Notice releasing topmost: {e}")

        QTimer.singleShot(800, _restore_standard_window)
    except Exception as e:
        log_msg(f"Win32 foreground elevation notice: {e}")

    log_msg("============================================================")
    log_msg(">> JARVIS AI APPLICATION WINDOW IS ACTIVE ON YOUR SCREEN <<")
    log_msg(">> Press Ctrl+C in this terminal or close the window to exit. <<")
    log_msg("============================================================")

    # Execute Qt Event Loop
    ret = app.exec()
    log_msg(f"QApplication event loop finished with code: {ret}")
    sys.exit(ret)

if __name__ == "__main__":
    main()
