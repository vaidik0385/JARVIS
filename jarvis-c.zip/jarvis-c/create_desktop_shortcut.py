"""
Creates 'JARVIS AI' desktop shortcut pointing directly to START_JARVIS.bat
"""

import os
import subprocess

def create_shortcut():
    desktop_dirs = [
        os.path.join(os.environ.get("USERPROFILE", ""), "Desktop"),
        os.path.join(os.environ.get("HOMEDRIVE", "C:"), os.environ.get("HOMEPATH", ""), "Desktop"),
        os.path.expanduser("~/Desktop")
    ]
    desktop = None
    for d in desktop_dirs:
        if d and os.path.exists(d):
            desktop = d
            break

    if not desktop:
        desktop = os.path.join(os.environ.get("USERPROFILE", "C:\\Users\\varun"), "Desktop")

    target_bat = os.path.abspath("START_JARVIS.bat")
    work_dir = os.path.abspath(".")
    shortcut_path = os.path.join(desktop, "JARVIS AI.lnk")

    ps_script = f'''
    $ws = New-Object -ComObject WScript.Shell
    $s = $ws.CreateShortcut("{shortcut_path}")
    $s.TargetPath = "{target_bat}"
    $s.WorkingDirectory = "{work_dir}"
    $s.Description = "JARVIS AI Desktop Assistant"
    $s.Save()
    '''

    try:
        res = subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], capture_output=True, text=True)
        if os.path.exists(shortcut_path):
            print(f"[SUCCESS] Desktop shortcut created: {shortcut_path}")
            return True, shortcut_path
        else:
            print(f"[FAIL] Shortcut was not created: {res.stderr}")
            return False, res.stderr
    except Exception as e:
        print(f"[ERROR] {e}")
        return False, str(e)

if __name__ == "__main__":
    create_shortcut()
