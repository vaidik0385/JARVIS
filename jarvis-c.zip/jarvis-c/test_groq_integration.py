"""
JARVIS AI — Comprehensive Groq Integration Test Suite
Validates:
1. Secure .env loading via python-dotenv
2. Model resolution (GROQ_MODEL)
3. Credential masking (Zero secret leakage)
4. Live Groq Cloud connection & active model query
5. Live Groq Chat Completion streaming (token-by-token)
6. Multi-turn conversation context memory
7. Multilingual system prompt (English, Hindi, Hinglish)
8. Desktop automation local routing vs AI routing
"""

import sys
import os
from pathlib import Path

# Set up project path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.config import config
from backend.ai_provider import GroqProvider
from backend.database import db
from services.conversation_manager import ConversationManager
from services.frontend_interfaces import ChatMessage
from backend.tool_router import ToolRouter
from backend.application_launcher import ApplicationLauncher

def run_tests():
    print("=" * 60)
    print("JARVIS AI — GROQ CLOUD & FRONTEND/BACKEND INTEGRATION TESTS")
    print("=" * 60)

    # 1. Configuration & Dotenv
    print("\n[1/7] Testing .env & Configuration Loading...")
    config.reload()
    assert config.groq_model, "GROQ_MODEL must not be empty"
    print(f"  Configured Groq Model: {config.groq_model}")
    print(f"  Fallback Model:        {config.ai_fallback_model}")
    masked = config.mask_key(config.groq_api_key)
    print(f"  API Key Mask:          {masked}")
    assert "gsk_" in masked or masked == "Not Configured"
    # Ensure raw key is never exposed
    if config.groq_api_key:
        assert config.groq_api_key not in masked
    print("  [OK] Dotenv & secure credential vault functional.")

    # 2. Connection Test via Official Groq SDK
    print("\n[2/7] Testing Groq API Cloud Connection...")
    provider = GroqProvider()
    if config.is_groq_configured():
        ok, msg = provider.test_connection()
        print(f"  Connection Status: {'SUCCESS' if ok else 'FAILED'}")
        print(f"  Diagnostic:        {msg}")
        assert ok, f"Groq connection test failed: {msg}"
        print("  [OK] Groq Cloud API connection verified.")
    else:
        print("  [SKIP] Groq API key is not configured in .env. Skipping live call.")

    # 3. Live Streaming Chat Completion
    print("\n[3/7] Testing Live Token Streaming Chat Completion...")
    if config.is_groq_configured():
        test_messages = [
            {"role": "system", "content": "You are JARVIS AI. Respond in one short sentence."},
            {"role": "user", "content": "Confirm you are online and operational."}
        ]
        received_tokens = []
        try:
            for chunk in provider.stream_chat(test_messages, max_tokens=256):
                if chunk.get("type") == "content":
                    token = chunk.get("delta", "")
                    received_tokens.append(token)
            full_response = "".join(received_tokens).strip()
            print(f"  Streamed Tokens Count: {len(received_tokens)}")
            print(f"  Live Model Response:   \"{full_response}\"")
            assert len(received_tokens) > 0, "No tokens received from stream"
            assert len(full_response) > 5, "Response is suspiciously short"
            print("  [OK] Live streaming chat completion verified.")
        except Exception as e:
            sanitized = provider._sanitize_error(e)
            print(f"  [ERROR] Streaming failed: {sanitized}")
            raise
    else:
        print("  [SKIP] Groq API key not set. Skipping live streaming test.")

    # 4. Multilingual Register Handling (Hindi / Hinglish / English)
    print("\n[4/7] Testing Multilingual Prompt Compatibility...")
    from backend.ai_engine import SYSTEM_PROMPT
    assert "Hindi" in SYSTEM_PROMPT
    assert "Hinglish" in SYSTEM_PROMPT
    assert "English" in SYSTEM_PROMPT
    print("  System prompt contains automatic language matching rules.")
    print("  [OK] Multilingual instructions verified.")

    # 5. Multi-Turn Conversation History Management
    print("\n[5/7] Testing Multi-Turn SQLite History Assembly...")
    conv_mgr = ConversationManager(db)
    test_cid = conv_mgr.create_conversation("Integration Test Chat")
    conv_mgr.add_message(test_cid, "user", "Hello JARVIS")
    conv_mgr.add_message(test_cid, "assistant", "Greetings, Sir. How may I assist you?")
    conv_mgr.add_message(test_cid, "user", "What is my operating system?")

    history = conv_mgr.get_conversation_messages(test_cid)
    assert len(history) == 3, f"Expected 3 messages, got {len(history)}"
    # Clean up test conversation
    conv_mgr.delete_conversation(test_cid)
    print(f"  Context assembly verified with 3 multi-turn messages.")
    print("  [OK] Conversation persistence verified.")

    # 6. Intent Routing (Local Subprocess vs Groq Cloud)
    print("\n[6/7] Testing Fast Local Routing vs AI Routing...")
    app_launcher = ApplicationLauncher(dry_run=True)
    router = ToolRouter(app_launcher)

    # Local automation commands must NOT consume Groq tokens
    res_calc = router.try_direct_intent("open calculator")
    assert res_calc is not None and res_calc[0] is True
    res_hindi = router.try_direct_intent("notepad kholo")
    assert res_hindi is not None and res_hindi[0] is True
    # General queries must pass through to Groq
    res_ai = router.try_direct_intent("Explain quantum computing algorithms in detail")
    assert res_ai is None, "General AI questions must NOT be handled by local regex router"
    print("  'open calculator' -> Handled locally (< 50ms, zero tokens)")
    print("  'notepad kholo'   -> Handled locally (< 50ms, zero tokens)")
    print("  'Explain quantum' -> Passed to Groq AI Engine")
    print("  [OK] Intent router verified.")

    # 7. Asynchronous Worker & Stop Generation
    print("\n[7/7] Testing Asynchronous AIEngine Worker & Interrupt...")
    from backend.ai_engine import AIEngine
    engine = AIEngine()
    assert hasattr(engine, "send_prompt")
    assert hasattr(engine, "stop_generation")
    assert hasattr(engine, "chunk_received")
    assert hasattr(engine, "response_completed")
    assert hasattr(engine, "error_occurred")
    print("  AIEngine exposes complete Qt signal/slot contract.")
    print("  [OK] Asynchronous AI Engine verified.")

    print("\n" + "=" * 60)
    print("ALL 7 GROQ INTEGRATION TESTS PASSED SUCCESSFULLY!")
    print("=" * 60)

if __name__ == "__main__":
    run_tests()
