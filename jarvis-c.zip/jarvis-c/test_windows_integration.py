"""
JARVIS AI — Comprehensive Windows Integration & Feature Test Suite
Exhaustively validates:
A. Websites in Default Chrome (Google, YouTube, LinkedIn, WhatsApp Web, GitHub, Gmail, ChatGPT, Google Search, YouTube Search, Arbitrary URL)
B. Application Control (Chrome, VS Code with folder, Explorer with folder, WhatsApp Desktop, Notepad, Calculator, Task Manager, Settings)
C. Windows Hardware Controls (Brightness increase/decrease/set, Volume increase/decrease/set, mute/unmute)
D. Indian Market Support (BTC INR, ETH INR, SOL INR, NIFTY 50, SENSEX, NSE Reliance/TCS)
E. Launcher & Desktop Integration (START_JARVIS.bat, START_JARVIS_HIDDEN.vbs, JARVIS AI.lnk)
"""

import sys
import os
import time

# Ensure UTF-8 output
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from PySide6.QtWidgets import QApplication
app = QApplication.instance() or QApplication(sys.argv)

from backend.config import config
from backend.application_launcher import ApplicationLauncher, SafeAppRegistry
from backend.windows_hardware import WindowsHardwareController
from backend.tool_router import ToolRouter
from backend.crypto_service import CryptoMarketService
from backend.stock_service import StockMarketService

RESULTS = {}

def record_test(category: str, name: str, passed: bool, details: str):
    key = f"[{category}] {name}"
    status = "PASS" if passed else "FAIL"
    RESULTS[key] = (status, details)
    print(f"[{status}] {key}: {details}")

print("=" * 75)
print("  JARVIS AI — COMPREHENSIVE WINDOWS INTEGRATION & FEATURE TEST SUITE")
print("=" * 75)

launcher = ApplicationLauncher(dry_run=True)
hardware = WindowsHardwareController()
crypto_svc = CryptoMarketService()
stock_svc = StockMarketService()
router = ToolRouter(launcher=launcher, crypto_service=crypto_svc, stock_service=stock_svc, hardware_controller=hardware)

# -------------------------------------------------------------
# A. WEBSITES IN DEFAULT CHROME
# -------------------------------------------------------------
print("\n--- SECTION A: WEBSITES IN DEFAULT CHROME ---")

# 1. Chrome Default Browser Check
is_def, def_msg = launcher.is_chrome_default_browser()
record_test("A. Websites", "Chrome Default Browser Verification", is_def, def_msg)

# 2. Google Home
ok, msg = launcher.open_web_portal("google")
record_test("A. Websites", "Open Google", ok, msg)

# 3. YouTube Home
ok, msg = launcher.open_web_portal("youtube")
record_test("A. Websites", "Open YouTube", ok, msg)

# 4. LinkedIn
ok, msg = launcher.open_web_portal("linkedin")
record_test("A. Websites", "Open LinkedIn", ok, msg)

# 5. WhatsApp Web
ok, msg = launcher.open_web_portal("whatsapp")
record_test("A. Websites", "Open WhatsApp Web", ok, msg)

# 6. GitHub
ok, msg = launcher.open_web_portal("github")
record_test("A. Websites", "Open GitHub", ok, msg)

# 7. Gmail
ok, msg = launcher.open_web_portal("gmail")
record_test("A. Websites", "Open Gmail", ok, msg)

# 8. ChatGPT
ok, msg = launcher.open_web_portal("chatgpt")
record_test("A. Websites", "Open ChatGPT", ok, msg)

# 9. Google Search for Python programming
ok, msg = launcher.search_google("Python programming")
record_test("A. Websites", "Search Google for Python programming", ok, msg)

# 10. YouTube Search for Java tutorials
ok, msg = launcher.search_youtube("Java tutorials")
record_test("A. Websites", "Search YouTube for Java tutorials", ok, msg)

# 11. Arbitrary Spoken Website URL
ok, msg = launcher.open_custom_website("reddit.com")
record_test("A. Websites", "Open Spoken Custom URL (reddit.com)", ok, msg)

# 12. Natural Language Chrome Commands
commands_to_test = [
    ("Jarvis, open YouTube.", "YouTube"),
    ("Open LinkedIn in Chrome.", "LinkedIn"),
    ("Search Google for machine learning", "Google"),
    ("Open WhatsApp Web.", "WhatsApp"),
    ("Open chrome and search for artificial intelligence", "Google")
]
nl_ok = True
nl_notes = []
for cmd, exp in commands_to_test:
    res = router.try_direct_intent(cmd)
    if res and res[0]:
        nl_notes.append(f"'{cmd[:22]}...': OK")
    else:
        nl_ok = False
        nl_notes.append(f"'{cmd[:22]}...': FAIL")
record_test("A. Websites", "Natural Language Web Commands", nl_ok, ", ".join(nl_notes))


# -------------------------------------------------------------
# B. WINDOWS APPLICATION CONTROL
# -------------------------------------------------------------
print("\n--- SECTION B: WINDOWS APPLICATION CONTROL ---")

# 1. Google Chrome
ok, msg = launcher.launch("chrome")
record_test("B. Applications", "Google Chrome Launcher", ok, msg)

# 2. VS Code (Standard)
ok, msg = launcher.launch_vscode()
record_test("B. Applications", "Visual Studio Code Launcher", ok, msg)

# 3. VS Code (Folder parameter)
cwd = os.path.abspath(".")
ok, msg = launcher.launch_vscode(folder_path=cwd)
record_test("B. Applications", "Visual Studio Code with Target Folder", ok, msg)

# 4. File Explorer (Standard)
ok, msg = launcher.open_file_explorer()
record_test("B. Applications", "File Explorer Launcher", ok, msg)

# 5. File Explorer (Folder parameter)
ok, msg = launcher.open_file_explorer(folder_path=cwd)
record_test("B. Applications", "File Explorer with Target Folder", ok, msg)

# 6. WhatsApp Desktop (with web fallback)
ok, msg = launcher.launch_whatsapp()
record_test("B. Applications", "WhatsApp Desktop / Web Launcher", ok, msg)

# 7. Notepad
ok, msg = launcher.launch("notepad")
record_test("B. Applications", "Notepad Launcher", ok, msg)

# 8. Calculator
ok, msg = launcher.launch("calculator")
record_test("B. Applications", "Calculator Launcher", ok, msg)

# 9. Task Manager
ok, msg = launcher.launch("taskmanager")
record_test("B. Applications", "Task Manager Launcher", ok, msg)

# 10. Windows Settings
ok, msg = launcher.launch("settings")
record_test("B. Applications", "Windows Settings Launcher", ok, msg)


# -------------------------------------------------------------
# C. REAL WINDOWS HARDWARE CONTROLS
# -------------------------------------------------------------
print("\n--- SECTION C: REAL WINDOWS HARDWARE CONTROLS ---")

# 1. Read Current Brightness
b_ok, b_cur, b_msg = hardware.get_brightness()
record_test("C. Hardware", "Read Current Display Brightness", b_ok, f"{b_cur}% ({b_msg})")

# 2. Set Brightness
set_b_ok, set_b_msg = hardware.set_brightness(b_cur)
record_test("C. Hardware", "Set Brightness Percentage", set_b_ok, set_b_msg)

# 3. Increase Brightness Command
inc_b_res = router.try_direct_intent("increase brightness")
record_test("C. Hardware", "Command: 'Increase brightness'", inc_b_res is not None and inc_b_res[0], inc_b_res[1] if inc_b_res else "No match")

# 4. Decrease Brightness Command
dec_b_res = router.try_direct_intent("decrease brightness")
record_test("C. Hardware", "Command: 'Decrease brightness'", dec_b_res is not None and dec_b_res[0], dec_b_res[1] if dec_b_res else "No match")

# 5. Exact Brightness Command
set70_res = router.try_direct_intent("set brightness to 70 percent")
record_test("C. Hardware", "Command: 'Set brightness to 70 percent'", set70_res is not None and set70_res[0], set70_res[1] if set70_res else "No match")
# Restore original brightness
hardware.set_brightness(b_cur)

# 6. Read Master Volume
v_ok, v_cur, v_muted, v_dev = hardware.get_volume()
record_test("C. Hardware", "Read Master System Volume", v_ok, f"{v_cur}% (Muted: {v_muted}, Device: '{v_dev}')")

# 7. Set Master Volume
set_v_ok, set_v_msg = hardware.set_volume(v_cur)
record_test("C. Hardware", "Set Volume Percentage", set_v_ok, set_v_msg)

# 8. Increase Volume Command
inc_v_res = router.try_direct_intent("increase volume")
record_test("C. Hardware", "Command: 'Increase volume'", inc_v_res is not None and inc_v_res[0], inc_v_res[1] if inc_v_res else "No match")

# 9. Decrease Volume Command
dec_v_res = router.try_direct_intent("decrease volume")
record_test("C. Hardware", "Command: 'Decrease volume'", dec_v_res is not None and dec_v_res[0], dec_v_res[1] if dec_v_res else "No match")

# 10. Mute / Unmute Commands
mute_res = router.try_direct_intent("mute my laptop")
record_test("C. Hardware", "Command: 'Mute my laptop'", mute_res is not None and mute_res[0], mute_res[1] if mute_res else "No match")

unmute_res = router.try_direct_intent("unmute")
record_test("C. Hardware", "Command: 'Unmute'", unmute_res is not None and unmute_res[0], unmute_res[1] if unmute_res else "No match")
# Restore volume & mute state
hardware.set_volume(v_cur)
hardware.set_mute(v_muted)


# -------------------------------------------------------------
# D. INDIAN MARKET SUPPORT (CRYPTO & EQUITIES)
# -------------------------------------------------------------
print("\n--- SECTION D: INDIAN MARKET SUPPORT ---")

# 1. Crypto in INR (CoinGecko + WazirX Indian Spot)
c_data = crypto_svc.get_prices(["bitcoin", "ethereum", "solana"])
coins = c_data.get("coins", {})

btc = coins.get("bitcoin", {})
btc_inr = btc.get("inr_price", 0)
btc_wazirx = btc.get("inr_spot_exchange", 0)
record_test("D. Indian Markets", "BTC Price in INR (WazirX Spot & CoinGecko)", btc_inr > 1000000, f"Spot: ₹{btc_wazirx:,.2f} | Global: ₹{btc_inr:,.2f}")

eth = coins.get("ethereum", {})
eth_inr = eth.get("inr_price", 0)
record_test("D. Indian Markets", "ETH Price in INR", eth_inr > 50000, f"₹{eth_inr:,.2f} INR")

sol = coins.get("solana", {})
sol_inr = sol.get("inr_price", 0)
record_test("D. Indian Markets", "SOL Price in INR", sol_inr > 1000, f"₹{sol_inr:,.2f} INR")

# 2. NIFTY 50 Index
stock_svc._cache.clear()
nifty = stock_svc.get_quote("nifty")
n_price = nifty.get("price", 0)
n_chg = nifty.get("change") or 0.0
record_test("D. Indian Markets", "NIFTY 50 Index", n_price > 10000, f"₹{n_price:,.2f} INR ({n_chg:+,.2f}) [{nifty.get('market_status')}]")

# 3. S&P BSE SENSEX Index
sensex = stock_svc.get_quote("sensex")
s_price = sensex.get("price", 0)
s_chg = sensex.get("change") or 0.0
record_test("D. Indian Markets", "S&P BSE SENSEX Index", s_price > 40000, f"₹{s_price:,.2f} INR ({s_chg:+,.2f}) [{sensex.get('market_status')}]")

# 4. Top NSE Company (Reliance Industries)
reliance = stock_svc.get_quote("reliance")
r_price = reliance.get("price", 0)
r_chg = reliance.get("change") or 0.0
record_test("D. Indian Markets", "NSE Listed Stock: Reliance Industries", r_price > 500, f"₹{r_price:,.2f} INR ({r_chg:+,.2f})")

# 5. Top NSE Company (TCS)
tcs = stock_svc.get_quote("tcs")
t_price = tcs.get("price", 0)
t_chg = tcs.get("change") or 0.0
record_test("D. Indian Markets", "NSE Listed Stock: TCS", t_price > 1000, f"₹{t_price:,.2f} INR ({t_chg:+,.2f})")

# 6. Direct Market Commands in Router
router_btc = router.try_direct_intent("what's bitcoin price in inr")
record_test("D. Indian Markets", "Command: 'What's Bitcoin's price in INR?'", router_btc is not None and "₹" in router_btc[1], "Report formatted with ₹ symbol")

router_nifty = router.try_direct_intent("what is the current nifty 50 value")
record_test("D. Indian Markets", "Command: 'What is the current NIFTY 50 value?'", router_nifty is not None and "NIFTY" in router_nifty[1], "NIFTY quote formatted")


# -------------------------------------------------------------
# E. LAUNCHER & DESKTOP INTEGRATION
# -------------------------------------------------------------
print("\n--- SECTION E: ONE-CLICK LAUNCHER & SHORTCUTS ---")

# 1. START_JARVIS.bat existence & contents
bat_path = os.path.abspath("START_JARVIS.bat")
bat_ok = os.path.exists(bat_path) and os.path.getsize(bat_path) > 100
record_test("E. Launcher", "START_JARVIS.bat Verification", bat_ok, f"Path: {bat_path} ({os.path.getsize(bat_path) if bat_ok else 0} bytes)")

# 2. START_JARVIS_HIDDEN.vbs existence
vbs_path = os.path.abspath("START_JARVIS_HIDDEN.vbs")
vbs_ok = os.path.exists(vbs_path) and os.path.getsize(vbs_path) > 50
record_test("E. Launcher", "START_JARVIS_HIDDEN.vbs Verification", vbs_ok, f"Path: {vbs_path}")

# 3. Desktop Shortcut JARVIS AI.lnk
desktop = os.path.join(os.environ.get("USERPROFILE", ""), "Desktop")
lnk_path = os.path.join(desktop, "JARVIS AI.lnk")
lnk_ok = os.path.exists(lnk_path)
record_test("E. Launcher", "JARVIS AI Desktop Shortcut", lnk_ok, f"Path: {lnk_path}")

print("\n" + "=" * 75)
total = len(RESULTS)
passed = sum(1 for s, _ in RESULTS.values() if s == "PASS")
print(f"TEST RUN COMPLETE: {passed}/{total} TESTS PASSED ({(passed/total)*100:.1f}%)")
print("=" * 75)

sys.exit(0 if passed == total else 1)
